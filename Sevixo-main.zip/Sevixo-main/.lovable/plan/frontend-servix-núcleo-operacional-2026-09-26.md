# Frontend ServiX — núcleo operacional

## Objetivo
Construir uma primeira versão navegável e responsiva da plataforma, com dados demonstrativos realistas e foco no painel da imobiliária.

## Entrega
- Criar uma identidade visual premium e tecnológica, com azul profundo, superfícies claras, estados semânticos e tipografia moderna.
- Montar a estrutura principal com barra lateral no desktop, navegação inferior no celular, busca, notificações e perfil.
- Implementar o painel da imobiliária com indicadores, gráficos, chamados recentes, agenda e atividades.
- Criar navegação funcional para Imóveis, Chamados, Profissionais e Financeiro, mantendo o contexto do aplicativo.
- Implementar o fluxo principal de “Novo chamado” em etapas, incluindo categoria, imóvel, descrição, prioridade e confirmação.
- Adicionar detalhes de chamado e interações demonstrativas relevantes, como filtros, status e feedback visual.
- Garantir adaptação para desktop, tablet e celular, além de metadados próprios da aplicação.

## Detalhes técnicos
- Os dados serão centralizados em uma camada mockada para futura substituição pela Lovable Cloud.
- A entrega será somente frontend; autenticação, banco, arquivos e pagamentos reais não serão conectados nesta etapa.
- Os componentes e tokens visuais serão reutilizáveis para os próximos módulos do produto.
