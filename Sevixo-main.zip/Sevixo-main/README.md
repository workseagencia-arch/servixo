# ServiX

Marketplace de serviços para clientes, profissionais e empresas. Este repositório contém o código-fonte completo da aplicação web, preparado para publicação na Vercel.

## Rodar localmente

Requer Node.js 20.19 ou superior (ou 22.12 ou superior) e pnpm. A compilação de produção está configurada para Node.js 24 na Vercel.

```sh
pnpm install
pnpm dev
```

Abra o endereço local exibido pelo Vite. Para validar a compilação de produção:

```sh
pnpm build
```

## Publicar na Vercel pelo GitHub

1. Extraia o ZIP e crie um repositório vazio no GitHub.
2. Abra um terminal na pasta extraída e envie o conteúdo para o repositório:

   ```sh
   git init -b main
   git add .
   git commit -m "Preparar ServiX para publicação"
   git remote add origin https://github.com/SEU-USUARIO/SEU-REPOSITORIO.git
   git push -u origin main
   ```

3. Na Vercel, escolha **Add New → Project**, importe esse repositório e mantenha a raiz como `.`.
4. Use o comando de build `pnpm build`. O adaptador Nitro está configurado para Vercel; não publique as pastas `node_modules` ou `.output`.
5. Faça o deploy. A cada push para a branch conectada, a Vercel poderá criar uma nova implantação.

As variáveis de ambiente devem ser configuradas no painel da Vercel para cada ambiente. O arquivo `.env.example` contém apenas nomes e valores vazios; nunca coloque chaves privadas no GitHub.

## Atualizar um repositório existente

1. Extraia o ZIP atualizado. Os arquivos do projeto estão dentro da pasta `ServiX`.
2. Copie o conteúdo dessa pasta para a raiz do repositório que já está conectado à Vercel, substituindo os arquivos anteriores. `package.json`, `pnpm-lock.yaml`, `vite.config.ts` e a pasta `src` devem continuar na raiz; não crie uma subpasta `ServiX` no repositório.
3. Preserve a pasta `.git` e as suas variáveis de ambiente locais. Dependências, caches, builds e credenciais não fazem parte do ZIP.
4. Envie as alterações em um novo commit. No terminal da pasta do repositório:

   ```sh
   git add .
   git commit -m "Atualizar layout e fluxos dos painéis ServiX"
   git push
   ```

   Pelo site do GitHub, use **Add file → Upload files**, envie os arquivos e pastas extraídos e confirme o commit. Se houver conflito com trabalho feito depois desta entrega, revise as diferenças antes de substituir os arquivos.

5. A Vercel fará uma nova implantação se o deploy automático estiver habilitado para a branch conectada. Confira o resultado no painel da Vercel.

O ZIP contém código-fonte editável, assets, configurações, lockfile e os arquivos SQL/instruções do Supabase. Os dados salvos no navegador não são incluídos. O estado das integrações com Supabase e pagamentos é descrito abaixo.

## Supabase

O esquema inicial de banco e as instruções para configurar Supabase e Vercel estão em [`supabase/SETUP.md`](supabase/SETUP.md) e [`supabase/schema.sql`](supabase/schema.sql). Eles preparam tabelas, Storage e políticas RLS para o marketplace.

O frontend ainda **não está conectado ao Supabase**: login, anúncios, mensagens, pedidos e avaliações permanecem nos stores de `localStorage`. Configurar variáveis e executar o SQL não muda isso por si só; é necessário integrar o SDK, a autenticação e os repositórios da aplicação antes de usar dados reais. Não publique a versão atual como operação real com pagamentos ou dados pessoais até concluir e testar essa integração. Os dados de demonstração ficam centralizados em `src/lib/demo-data.ts`.
