# Roadmap

- [x] Definir o design system e a estrutura responsiva
- [x] Criar painel da imobiliária com indicadores, gráficos e agenda
- [x] Criar telas de imóveis, chamados, profissionais e financeiro
- [x] Implementar fluxo demonstrativo de novo chamado
- [x] Adicionar navegação desktop e mobile
- [x] Preparar dados mockados para substituição futura
- [x] Fluxo de contratação: Contratar → Agora/Agendar → endereço → resumo → confirmar → Meus serviços
- [x] Detalhe da contratação com status e botão Conversar
- [x] Serviços profissionais em múltiplas categorias, com busca e oportunidades compatíveis
- [x] Campanhas patrocinadas para profissionais e empresas com formatos, preços e moderação demonstrativa
- [x] Avaliações persistidas após serviços concluídos e exibidas nos perfis profissionais
- [x] Central administrativa com indicadores, denúncias, controle de acesso e trilha de auditoria demonstrativa
- [x] Anúncios pagos por canal em início, busca, serviços, mensagens, perfil e notificações
- [x] Busca reorganizada com mapa horizontal e resultados em grade responsiva
