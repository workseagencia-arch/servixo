import { Check } from "lucide-react";
import { adChannelLabels, customerAdChannels, type AdChannel } from "@/lib/demo-data";

export function AdChannelPicker({
  value,
  onChange,
}: {
  value: AdChannel[];
  onChange: (channels: AdChannel[]) => void;
}) {
  const toggle = (channel: AdChannel) =>
    onChange(
      value.includes(channel) ? value.filter((item) => item !== channel) : [...value, channel],
    );
  return (
    <fieldset className="space-y-2 rounded-2xl border p-3.5 sm:col-span-2">
      <legend className="px-1 text-sm font-semibold">Canais de exibição</legend>
      <p className="text-xs text-muted-foreground">
        Escolha onde sua imagem aparecerá. Cada peça vem identificada como publicidade; a faixa de
        preço cresce a cada grupo de 3 canais.
      </p>
      <div className="grid gap-2 sm:grid-cols-3 xl:grid-cols-4">
        {customerAdChannels.map((channel) => {
          const checked = value.includes(channel);
          return (
            <button
              key={channel}
              type="button"
              aria-pressed={checked}
              onClick={() => toggle(channel)}
              className={`flex items-center gap-2 rounded-xl border px-3 py-2.5 text-left text-xs font-semibold transition ${checked ? "border-primary/40 bg-accent text-accent-foreground" : "text-muted-foreground hover:bg-muted"}`}
            >
              <span
                className={`grid h-4 w-4 shrink-0 place-items-center rounded border ${checked ? "border-primary bg-primary text-primary-foreground" : ""}`}
              >
                {checked && <Check className="h-3 w-3" />}
              </span>
              {adChannelLabels[channel]}
            </button>
          );
        })}
      </div>
      {!value.length && (
        <p className="text-xs font-semibold text-destructive">Selecione pelo menos um canal.</p>
      )}
    </fieldset>
  );
}
