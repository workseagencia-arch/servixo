import { useEffect, useMemo, useRef, useState } from "react";
import { Link } from "@tanstack/react-router";
import { ArrowLeft, ArrowRight, ArrowUpRight, Megaphone } from "lucide-react";
import { Avatar, Rating, ResilientImage } from "@/components/app/ui-bits";
import { categoryName, type AdCampaign, type AdChannel, type CategorySlug } from "@/lib/demo-data";
import { campaignTargetsChannel, isCampaignDeliverable, readAdCampaigns, recordAdClick, recordAdImpression, subscribeToAdCampaigns } from "@/lib/advertising-store";
import { distanceBetweenKm, readDeviceLocation, subscribeToLocation, type DeviceLocation } from "@/lib/location-store";
import { getClientFacingProfessionalById } from "@/lib/professional-store";
import { cn } from "@/lib/utils";
import homeHeroImage from "@/assets/hero-pro.jpg";

export function AdPlacement({ channel, category, compact = false, className }: { channel: AdChannel; category?: CategorySlug; compact?: boolean; className?: string }) {
  const [campaigns, setCampaigns] = useState<AdCampaign[]>(readAdCampaigns);
  const [location, setLocation] = useState(() => readDeviceLocation("cliente"));
  const lastImpression = useRef("");

  useEffect(() => {
    const refresh = () => setCampaigns(readAdCampaigns());
    refresh();
    return subscribeToAdCampaigns(refresh);
  }, []);

  useEffect(() => {
    const refresh = () => setLocation(readDeviceLocation("cliente"));
    return subscribeToLocation(refresh);
  }, []);

  const campaign = useMemo(() => campaigns.find((item) => {
    if (!isCampaignDeliverable(item) || !campaignTargetsChannel(item, channel)) return false;
    if (category && item.category && item.category !== category) return false;
    if (location && distanceBetweenKm(location, { latitude: item.latitude, longitude: item.longitude }) > item.radiusKm) return false;
    if (item.advertiserType === "profissional") return !!item.advertiserId && !!getClientFacingProfessionalById(item.advertiserId);
    return item.format !== "destaque_profissional";
  }), [campaigns, category, channel, location]);
  const campaignId = campaign?.id;

  useEffect(() => {
    if (!campaignId || lastImpression.current === campaignId) return;
    lastImpression.current = campaignId;
    recordAdImpression(campaignId);
  }, [campaignId]);

  if (!campaign) return null;
  const profile = campaign.advertiserType === "profissional" && campaign.advertiserId
    ? getClientFacingProfessionalById(campaign.advertiserId)
    : undefined;
  const href = campaign.advertiserType === "profissional" && profile
    ? `/profissional/${profile.id}`
    : campaign.href.startsWith("/") && !campaign.href.startsWith("//") || /^https:\/\//i.test(campaign.href)
      ? campaign.href
      : "/empresas";
  const click = () => recordAdClick(campaign.id);
  const body = (
    <>
      <div className={cn("relative min-w-0 flex-1", compact ? "p-4 sm:p-5" : "p-5 sm:p-7")}>
        <span className="inline-flex items-center gap-1.5 rounded-full border border-current/15 bg-background/75 px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-[0.12em] text-foreground backdrop-blur"><Megaphone className="h-3 w-3" />Publicidade</span>
        <p className="mt-3 break-words text-xs font-bold uppercase tracking-wide text-primary">{campaign.advertiserName}{campaign.category ? ` · ${categoryName(campaign.category)}` : ""}</p>
        <h2 className={cn("mt-1 max-w-2xl break-words font-display font-extrabold leading-tight", compact ? "text-lg sm:text-xl" : "text-xl sm:text-2xl")}>{campaign.headline}</h2>
        <p className="mt-1 max-w-2xl break-words text-sm leading-relaxed text-muted-foreground">{campaign.description}</p>
        <span className="mt-4 inline-flex items-center gap-1.5 text-sm font-extrabold text-primary">Conhecer oferta <ArrowUpRight className="h-4 w-4" /></span>
      </div>
      <div className={cn("relative overflow-hidden bg-muted", compact ? "h-32 sm:h-36 sm:w-56" : "h-44 sm:h-52 sm:w-[38%]")}>
        <ResilientImage src={campaign.imageUrl} alt="" fallbackLabel="Criativo indisponível" className="h-full w-full object-cover object-center transition duration-500 group-hover:scale-[1.03]" />
        {profile && <div className="absolute inset-x-3 bottom-3 flex items-center gap-2 rounded-2xl bg-background/95 p-2.5 shadow-sm backdrop-blur"><Avatar pro={profile} size="sm" /><span className="min-w-0"><span className="block truncate text-xs font-bold">{profile.name}</span><span className="mt-0.5 block"><Rating value={profile.rating} count={profile.reviews} className="text-[10px]" /></span></span></div>}
      </div>
    </>
  );
  const classes = cn("surface group flex min-w-0 flex-col overflow-hidden transition hover:-translate-y-0.5 hover:shadow-md sm:flex-row", className);

  return href.startsWith("/")
    ? <Link to={href as never} onClick={click} aria-label={`Publicidade de ${campaign.advertiserName}: ${campaign.headline}`} className={classes}>{body}</Link>
    : <a href={href} target="_blank" rel="noopener noreferrer" onClick={click} aria-label={`Publicidade de ${campaign.advertiserName}: ${campaign.headline}`} className={classes}>{body}</a>;
}

export function HomeBannerCarousel() {
  const [campaigns, setCampaigns] = useState<AdCampaign[]>([]);
  const [location, setLocation] = useState<DeviceLocation | null>(null);
  const [clientReady, setClientReady] = useState(false);
  const [activeIndex, setActiveIndex] = useState(0);
  const [paused, setPaused] = useState(false);
  const [failedCampaignImage, setFailedCampaignImage] = useState(false);
  const impressions = useRef(new Set<string>());

  useEffect(() => {
    const refreshCampaigns = () => setCampaigns(readAdCampaigns());
    const refreshLocation = () => setLocation(readDeviceLocation("cliente"));
    refreshCampaigns();
    refreshLocation();
    setClientReady(true);
    const unsubscribeCampaigns = subscribeToAdCampaigns(refreshCampaigns);
    const unsubscribeLocation = subscribeToLocation(refreshLocation);
    return () => {
      unsubscribeCampaigns();
      unsubscribeLocation();
    };
  }, []);

  const slides = useMemo(() => {
    return campaigns.filter((item) => {
      if (!isCampaignDeliverable(item) || !campaignTargetsChannel(item, "inicio")) return false;
      if (location && distanceBetweenKm(location, { latitude: item.latitude, longitude: item.longitude }) > item.radiusKm) return false;
      if (item.advertiserType === "profissional") {
        return !!item.advertiserId && (!clientReady || !!getClientFacingProfessionalById(item.advertiserId));
      }
      return item.format !== "destaque_profissional";
    });
  }, [campaigns, clientReady, location]);

  useEffect(() => {
    if (activeIndex >= slides.length) setActiveIndex(0);
  }, [activeIndex, slides.length]);

  useEffect(() => {
    if (
      slides.length < 2 ||
      paused ||
      window.matchMedia("(prefers-reduced-motion: reduce)").matches
    )
      return;
    const timer = window.setInterval(() => setActiveIndex((index) => (index + 1) % slides.length), 7000);
    return () => window.clearInterval(timer);
  }, [slides.length, paused, activeIndex]);

  const campaign = slides[activeIndex];
  const campaignId = campaign?.id;
  useEffect(() => setFailedCampaignImage(false), [campaignId]);
  useEffect(() => {
    if (!campaignId || impressions.current.has(campaignId)) return;
    impressions.current.add(campaignId);
    recordAdImpression(campaignId);
  }, [campaignId]);

  if (!campaign) {
    return (
      <section
        role="region"
        aria-label="Apresentação ServiX"
          className="relative isolate min-w-0 overflow-hidden rounded-md bg-primary shadow-card"
        >
        <img src={homeHeroImage} alt="Profissional realizando um serviço de montagem" className="absolute inset-0 h-full w-full object-cover object-[center_37%] opacity-45 md:inset-y-0 md:left-auto md:right-0 md:w-[57%] md:opacity-100" fetchPriority="high" />
        <div className="absolute inset-0 bg-gradient-to-t from-[#06271b] via-[#06271b]/90 to-[#06271b]/30 md:bg-gradient-to-r md:from-[#06271b] md:via-[#06271b]/95 md:via-55% md:to-[#06271b]/10" />
        <div className="relative z-10 flex min-h-[330px] items-end sm:min-h-[360px] md:min-h-[340px] md:items-center lg:min-h-[390px]">
          <div className="min-w-0 max-w-3xl px-5 pb-8 pt-24 sm:px-9 sm:pb-10 md:px-10 md:py-12 lg:px-12">
            <p className="inline-flex items-center gap-2 border-l-2 border-brand pl-2.5 text-[11px] font-extrabold uppercase tracking-[0.16em] text-brand sm:text-xs">ServiX · profissionais da sua região</p>
            <h1 className="mt-4 max-w-2xl break-words font-display text-[clamp(1.9rem,5vw,3.2rem)] font-extrabold leading-[1.06] tracking-[-0.04em] text-white">
              Encontre quem <span className="text-brand">resolve</span> o que você precisa.
            </h1>
            <p className="mt-3 max-w-xl text-sm leading-relaxed text-white/80 sm:text-base">
              Compare profissionais, serviços e avaliações. Escolha com clareza e converse antes de contratar.
            </p>
            <Link
              to="/profissionais"
              className="mt-6 inline-flex min-h-11 items-center gap-2 rounded-sm bg-brand px-5 py-3 text-sm font-extrabold text-brand-foreground transition hover:brightness-95"
            >
              Encontrar profissionais <ArrowUpRight className="h-4 w-4" />
            </Link>
            <div className="mt-6 flex flex-wrap gap-x-5 gap-y-2 text-[11px] font-semibold text-white/75 sm:text-xs">
              <span>Perfis e serviços em um só lugar</span>
              <span>Conversa direta pelo sistema</span>
            </div>
          </div>
        </div>
      </section>
    );
  }
  const profile = campaign.advertiserType === "profissional" && campaign.advertiserId
    ? getClientFacingProfessionalById(campaign.advertiserId)
    : undefined;
  const href = campaign.advertiserType === "profissional" && profile
    ? `/profissional/${profile.id}`
    : campaign.href.startsWith("/") && !campaign.href.startsWith("//") || /^https:\/\//i.test(campaign.href)
      ? campaign.href
      : "/empresas";
  const click = () => recordAdClick(campaign.id);
  const label = `Publicidade de ${campaign.advertiserName}: ${campaign.headline}`;

  const slideContent = (
    <div
      key={campaign.id}
      aria-live="polite"
      className="servix-banner-enter relative flex min-h-[350px] items-end overflow-hidden bg-hero sm:min-h-[360px] lg:min-h-[400px] xl:min-h-[420px]"
    >
      {!failedCampaignImage && (
        <img
          src={campaign.imageUrl}
          alt=""
          className="absolute inset-0 z-0 h-full w-full object-cover object-center"
          fetchPriority="high"
          decoding="async"
          onError={() => setFailedCampaignImage(true)}
        />
      )}
      <div className="absolute inset-0 z-[1] bg-gradient-to-r from-slate-950/90 via-slate-950/65 to-slate-950/25" />
      <div className="absolute inset-0 z-[1] bg-gradient-to-t from-slate-950/45 via-transparent to-slate-950/10" />
      <div className="relative z-10 w-full px-4 pb-16 pt-20 text-white sm:px-9 sm:pb-14 sm:pt-16 lg:px-12 lg:pb-16">
        <div className="min-w-0 max-w-[min(100%,48rem)] pr-2 sm:pr-20">
          <span className="inline-flex max-w-full items-center gap-1.5 rounded-sm border border-white/25 bg-black/25 px-3 py-1.5 text-[10px] font-extrabold uppercase tracking-[0.14em] backdrop-blur">
            <Megaphone className="h-3.5 w-3.5 shrink-0" />
            <span className="truncate">Publicidade · {campaign.advertiserName}</span>
          </span>
          <h1 className="mt-4 break-words font-display text-[clamp(1.85rem,5vw,3rem)] font-extrabold leading-tight">
            {campaign.headline}
          </h1>
          <p className="mt-3 max-w-xl break-words text-sm leading-relaxed text-white/85 sm:text-base">
            {campaign.description}
          </p>
          <span className="mt-6 inline-flex min-h-11 items-center gap-2 rounded-sm bg-brand px-5 py-3 text-sm font-extrabold text-brand-foreground transition group-hover:brightness-95">
            Conhecer anúncio <ArrowUpRight className="h-4 w-4" />
          </span>
        </div>
      </div>
    </div>
  );

  return (
    <section
      role="region"
      aria-roledescription="carrossel"
      aria-label="Anúncios em destaque"
      onMouseEnter={() => setPaused(true)}
      onMouseLeave={() => setPaused(false)}
      onFocusCapture={() => setPaused(true)}
      onBlurCapture={(event) => {
        const nextTarget = event.relatedTarget;
        if (!(nextTarget instanceof Node) || !event.currentTarget.contains(nextTarget)) setPaused(false);
      }}
      className="relative overflow-hidden rounded-lg bg-hero shadow-sm"
    >
      {href.startsWith("/") ? (
        <Link
          to={href as never}
          onClick={click}
          aria-label={label}
          className="group block focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
        >
          {slideContent}
        </Link>
      ) : (
        <a
          href={href}
          target="_blank"
          rel="noopener noreferrer"
          onClick={click}
          aria-label={label}
          className="group block focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-primary"
        >
          {slideContent}
        </a>
      )}

      {slides.length > 1 && (
        <>
          <div className="absolute right-3 top-3 z-10 flex gap-2 sm:right-4 sm:top-4">
            <button
              type="button"
              onClick={() => setActiveIndex((index) => (index - 1 + slides.length) % slides.length)}
              aria-label="Banner anterior"
              className="grid h-10 w-10 place-items-center rounded-sm border border-white/35 bg-black/40 text-white backdrop-blur transition hover:bg-black/65 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
            >
              <ArrowLeft className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => setActiveIndex((index) => (index + 1) % slides.length)}
              aria-label="Próximo banner"
              className="grid h-10 w-10 place-items-center rounded-sm border border-white/35 bg-black/40 text-white backdrop-blur transition hover:bg-black/65 focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white"
            >
              <ArrowRight className="h-4 w-4" />
            </button>
          </div>
          <div className="absolute bottom-4 right-4 z-10 flex max-w-[calc(100%-2rem)] items-center gap-2 rounded-sm bg-black/30 px-2.5 py-2 backdrop-blur" aria-label="Selecionar anúncio">
            <span className="mr-1 text-[10px] font-semibold text-white/80">
              {activeIndex + 1}/{slides.length}
            </span>
            {slides.map((item, index) => (
              <button
                key={item.id}
                type="button"
                onClick={() => setActiveIndex(index)}
                aria-label={`Mostrar anúncio ${index + 1}`}
                aria-current={activeIndex === index ? "true" : undefined}
                className={cn(
                  "h-2 rounded-full transition-all focus-visible:outline focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-white",
                  activeIndex === index ? "w-6 bg-white" : "w-2 bg-white/55 hover:bg-white",
                )}
              />
            ))}
          </div>
        </>
      )}
    </section>
  );
}
