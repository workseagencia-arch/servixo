import { Link, useNavigate, useRouterState } from "@tanstack/react-router";
import {
  Home,
  Megaphone,
  UserRound,
  BriefcaseBusiness,
  Search,
  LocateFixed,
  Bell,
  ClipboardCheck,
  ShieldCheck,
  LayoutDashboard,
  CheckCheck,
  LogOut,
  Moon,
  Sun,
  Settings2,
  Wrench,
  Wallet,
  Inbox,
  CalendarDays,
  ChevronDown,
  Trash2,
} from "lucide-react";
import { useEffect, useMemo, useRef, useState, type FormEvent, type ReactNode } from "react";
import { Logo } from "./brand";
import { cn } from "@/lib/utils";
import {
  clearSession,
  hasProfessionalAccess,
  readSession,
  subscribeToSession,
  type AuthSession,
  type AccountRole,
} from "@/lib/auth-store";
import {
  getNotificationsForRoles,
  deleteNotification,
  markAllNotificationsReadForRoles,
  markNotificationRead,
  subscribeToNotifications,
  type ServixNotification,
} from "@/lib/notification-store";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  DropdownMenu,
  DropdownMenuCheckboxItem,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { readClientProfile, subscribeToClientProfile } from "@/lib/client-profile-store";
import { readProfessionalProfile, subscribeToProfessionalProfile } from "@/lib/professional-store";
import {
  applyThemeMode,
  readThemeMode,
  setThemeMode,
  subscribeToTheme,
  type ThemeMode,
} from "@/lib/theme-store";
import { isEmailAccountSuspended, subscribeToSecurityState } from "@/lib/security-store";
import {
  readDeviceLocation,
  subscribeToLocation,
  watchDeviceLocation,
  type DeviceLocation,
} from "@/lib/location-store";
import { toast } from "sonner";

const customerNav = [
  { to: "/", label: "Início", icon: Home },
  { to: "/anuncios-servicos", label: "Anúncios/Serviços", icon: Megaphone },
  { to: "/profissionais", label: "Profissionais", icon: UserRound },
  { to: "/vagas", label: "Vagas", icon: ClipboardCheck },
  { to: "/preco-fechado", label: "Preço fechado", icon: BriefcaseBusiness },
] as const;

const professionalTools = [
  { to: "/pro", label: "Painel profissional", icon: LayoutDashboard },
  { to: "/pro/agenda", label: "Agenda e serviços", icon: CalendarDays },
  { to: "/pro/servicos", label: "Meus anúncios", icon: Wrench },
  { to: "/pro/divulgacao", label: "Impulsionar perfil", icon: Megaphone },
  { to: "/pro/ganhos", label: "Ganhos", icon: Wallet },
] as const;

const managementNav = [
  { to: "/gestao", label: "Visão geral", icon: LayoutDashboard },
  { to: "/gestao/seguranca", label: "Controle e segurança", icon: ShieldCheck },
  { to: "/gestao/anuncios", label: "Anúncios da plataforma", icon: Megaphone },
] as const;

export function AppShell({ children }: { children: ReactNode }) {
  const path = useRouterState({ select: (state) => state.location.pathname });
  const navigate = useNavigate();
  const isProfessionalWorkspace = path === "/pro" || path.startsWith("/pro/");
  const isManagement = path === "/gestao" || path.startsWith("/gestao/");
  const nav = isManagement ? managementNav : customerNav;
  const isActive = (to: string) =>
    to === "/" ? path === "/" : path === to || path.startsWith(`${to}/`);
  const [session, setSession] = useState<AuthSession | null>(null);
  const notificationRoleKey = isManagement
    ? "moderador"
    : hasProfessionalAccess(session)
      ? "cliente,profissional"
      : "cliente";
  const notificationRoles = useMemo(
    () => notificationRoleKey.split(",") as AccountRole[],
    [notificationRoleKey],
  );
  const [sessionReady, setSessionReady] = useState(false);
  const [notifications, setNotifications] = useState<ServixNotification[]>([]);
  const [notificationsOpen, setNotificationsOpen] = useState(false);
  const [profilePhoto, setProfilePhoto] = useState("");
  const [theme, setTheme] = useState<ThemeMode>("light");
  const [searchText, setSearchText] = useState("");
  const [location, setLocation] = useState<DeviceLocation | null>(null);
  const [locating, setLocating] = useState(false);
  const locationWatch = useRef<(() => void) | null>(null);

  useEffect(() => {
    const refresh = () => {
      setSession(readSession());
      setSessionReady(true);
    };
    refresh();
    return subscribeToSession(refresh);
  }, []);

  useEffect(() => {
    const verifyAccess = () => {
      const current = readSession();
      if (current && current.role !== "moderador" && isEmailAccountSuspended(current.email)) {
        clearSession();
        toast.error("Este acesso foi suspenso pela equipe ServiX.");
        navigate({ to: "/entrar", search: { perfil: "cliente" } });
      }
    };
    verifyAccess();
    return subscribeToSecurityState(verifyAccess);
  }, [navigate]);

  useEffect(() => {
    if (isProfessionalWorkspace && sessionReady && !hasProfessionalAccess(session)) {
      navigate({ to: "/entrar", search: { perfil: "cliente" } });
    }
    if (isManagement && sessionReady && session?.role !== "moderador") {
      navigate({ to: "/entrar", search: { perfil: "moderador" } });
    }
  }, [isProfessionalWorkspace, isManagement, sessionReady, session, navigate]);

  useEffect(() => {
    const refresh = () => setNotifications(getNotificationsForRoles(notificationRoles));
    refresh();
    return subscribeToNotifications(refresh);
  }, [notificationRoles]);

  useEffect(() => {
    const refresh = () => {
      const currentSession = readSession();
      setProfilePhoto(
        isManagement
          ? ""
          : (hasProfessionalAccess(currentSession) && readProfessionalProfile().photoUrl) ||
              readClientProfile().photoUrl,
      );
    };
    refresh();
    const offClient = subscribeToClientProfile(refresh);
    const offPro = subscribeToProfessionalProfile(refresh);
    const offSession = subscribeToSession(refresh);
    return () => {
      offClient();
      offPro();
      offSession();
    };
  }, [isManagement, session, isProfessionalWorkspace]);

  useEffect(() => {
    const refresh = () => {
      const mode = readThemeMode();
      setTheme(mode);
      applyThemeMode(mode);
    };
    refresh();
    return subscribeToTheme(refresh);
  }, []);

  useEffect(() => {
    const refresh = () => {
      setLocation(readDeviceLocation("cliente"));
      setLocating(false);
    };
    refresh();
    const off = subscribeToLocation(refresh);
    return () => {
      off();
      locationWatch.current?.();
    };
  }, []);

  const unread = notifications.filter((item) => !item.read).length;
  const enableProfessionalProfile = () => {
    if (!session) {
      navigate({ to: "/entrar", search: { perfil: "cliente" } });
      return;
    }
    navigate({ to: "/ativar-profissional" });
  };
  const signOut = () => {
    clearSession();
    navigate({ to: "/entrar", search: { perfil: isManagement ? "moderador" : "cliente" } });
  };
  const searchSubmit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    navigate({ to: "/anuncios-servicos", search: { q: searchText.trim() || undefined } });
  };
  const locate = () => {
    locationWatch.current?.();
    setLocating(true);
    locationWatch.current = watchDeviceLocation(
      isProfessionalWorkspace ? "profissional" : "cliente",
      (message) => {
        setLocating(false);
        toast.error(message);
      },
    );
    toast.message("Aguardando a localização deste aparelho…");
  };

  return (
    <div className="min-h-screen">
      <header className="servix-header sticky top-0 z-40 shadow-lg">
        <div className="hidden border-b border-primary/10 bg-brand text-brand-foreground sm:block">
          <div className="mx-auto flex h-8 w-full max-w-[1440px] items-center justify-between px-4 text-[10px] font-bold tracking-wide sm:px-6 lg:px-8 2xl:px-10">
            <span>ServiX · serviços para o que importa</span>
            <span className="hidden md:inline">Encontre profissionais e resolva com mais confiança</span>
          </div>
        </div>
        <div className="mx-auto w-full max-w-[1440px] px-4 sm:px-6 lg:px-8 2xl:px-10">
          <div className="flex min-h-[4.5rem] items-center justify-between gap-3 sm:justify-center md:gap-5">
            <Logo to={isManagement ? "/gestao" : "/"} />
            <form
              onSubmit={searchSubmit}
              className="hidden h-11 min-w-0 max-w-2xl flex-1 items-center gap-2 rounded-md border border-white/70 bg-white px-3 shadow-sm transition-[border-color,box-shadow] focus-within:border-brand focus-within:ring-2 focus-within:ring-brand/45 sm:flex"
            >
              <Search className="h-4 w-4 shrink-0 text-primary/70" />
              <input
                value={searchText}
                onChange={(event) => setSearchText(event.target.value)}
                placeholder="Qual serviço você procura hoje?"
                aria-label="Pesquisar serviços"
                className="min-w-0 flex-1 bg-transparent text-sm text-slate-900 outline-none placeholder:text-slate-500"
              />
              <button
                aria-label="Pesquisar"
                className="h-8 rounded-sm bg-primary px-4 text-xs font-bold text-primary-foreground transition-colors hover:bg-primary/90"
              >
                Buscar
              </button>
            </form>
            <button
              type="button"
              onClick={locate}
              className="hidden shrink-0 items-center gap-2.5 rounded-md px-1.5 py-1.5 text-left text-white transition-colors hover:bg-white/10 lg:flex"
              title="Compartilhada entre suas áreas de cliente e profissional"
            >
              <span className="grid h-9 w-9 shrink-0 place-items-center rounded-sm bg-white/10">
                <LocateFixed className={cn("h-4 w-4", location ? "text-brand" : "text-white")} />
              </span>
              <span className="block min-w-0">
                <span className="block text-[11px] font-medium text-white/65">
                  Sua localização
                </span>
                <span className="mt-0.5 block text-xs font-semibold text-white">
                  {locating ? "Localizando…" : location ? "Localização ativa" : "Definir localização"}
                </span>
              </span>
              <ChevronDown className="h-3.5 w-3.5 shrink-0 text-white/65" />
            </button>

            <button
              type="button"
              onClick={locate}
              className="hidden h-10 w-10 shrink-0 place-items-center rounded-md border border-white/20 text-white transition-colors hover:bg-white/10 sm:grid lg:hidden"
              title={location ? "Localização ativa" : "Definir localização"}
              aria-label={location ? "Atualizar localização" : "Definir localização"}
            >
              <LocateFixed className={cn("h-4 w-4", location ? "text-brand" : "text-white")} />
            </button>

            <div className="flex min-w-0 items-center gap-1.5 sm:ml-0 sm:shrink-0 sm:gap-2">
              <Popover open={notificationsOpen} onOpenChange={setNotificationsOpen}>
                <PopoverTrigger asChild>
                  <button
                    className="relative grid h-10 w-10 shrink-0 place-items-center rounded-md text-white transition-colors hover:bg-white/10"
                    aria-label={`Notificações${unread ? `, ${unread} não lidas` : ""}`}
                  >
                    <Bell className="h-5 w-5" />
                    {unread > 0 && (
                      <span className="absolute right-1.5 top-1.5 grid h-[18px] min-w-[18px] place-items-center rounded-full bg-destructive px-1 text-[10px] font-bold text-white">
                        {unread}
                      </span>
                    )}
                  </button>
                </PopoverTrigger>
                <PopoverContent
                  align="end"
                  className="w-[min(22rem,calc(100vw-2rem))] overflow-hidden rounded-xl p-0"
                >
                  <div className="flex items-center justify-between border-b p-4">
                    <div>
                      <p className="font-display font-bold">Notificações</p>
                      <p className="text-xs text-muted-foreground">
                        {unread ? `${unread} atualização(ões) não lida(s)` : "Tudo em dia"}
                      </p>
                    </div>
                    {unread > 0 && (
                      <button
                        onClick={() => markAllNotificationsReadForRoles(notificationRoles)}
                        className="inline-flex items-center gap-1 text-xs font-bold text-primary hover:underline"
                      >
                        <CheckCheck className="h-3.5 w-3.5" />
                        Marcar lidas
                      </button>
                    )}
                  </div>
                  <div className="max-h-[min(65vh,24rem)] overflow-y-auto">
                    {notifications.length ? (
                      notifications.slice(0, 5).map((item) => (
                        <div
                          key={item.id}
                          className={cn(
                            "flex items-start gap-2 border-b p-3 last:border-0",
                            !item.read && "bg-accent/30",
                          )}
                        >
                          <Link
                            to={
                              (item.href ?? (isProfessionalWorkspace ? "/pro" : "/perfil")) as never
                            }
                            onClick={() => {
                              markNotificationRead(item.id);
                              setNotificationsOpen(false);
                            }}
                            className="flex min-w-0 flex-1 items-start gap-3 rounded-md p-1 hover:bg-muted/70"
                          >
                            <span
                              className={cn(
                                "mt-1.5 h-2 w-2 shrink-0 rounded-full",
                                item.read ? "bg-transparent" : "bg-primary",
                              )}
                            />
                            <span className="min-w-0 flex-1">
                              <span className="flex items-center justify-between gap-2">
                                <span className="line-clamp-1 text-sm font-bold">{item.title}</span>
                                <span className="shrink-0 text-[10px] text-muted-foreground">
                                  {item.time}
                                </span>
                              </span>
                              <span className="mt-1 line-clamp-2 text-xs leading-relaxed text-muted-foreground">
                                {item.detail}
                              </span>
                            </span>
                          </Link>
                          <button
                            type="button"
                            onClick={() => deleteNotification(item.id)}
                            className="grid h-8 w-8 shrink-0 place-items-center rounded-md text-muted-foreground transition hover:bg-destructive/10 hover:text-destructive"
                            aria-label={`Excluir notificação: ${item.title}`}
                            title="Excluir notificação"
                          >
                            <Trash2 className="h-4 w-4" />
                          </button>
                        </div>
                      ))
                    ) : (
                      <p className="p-6 text-center text-sm text-muted-foreground">
                        Nenhuma notificação por enquanto.
                      </p>
                    )}
                  </div>
                  <div className="border-t p-3">
                    <Link
                      to={isManagement ? "/gestao" : ("/notificacoes" as never)}
                      onClick={() => setNotificationsOpen(false)}
                      className="block rounded-md py-2 text-center text-sm font-bold text-primary hover:bg-muted"
                    >
                      Ver central completa · {notifications.length}
                    </Link>
                  </div>
                </PopoverContent>
              </Popover>

              {session ? (
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <button
                      className="group flex h-11 min-w-0 max-w-[min(17rem,52vw)] items-center gap-2 rounded-md border border-white/15 px-2 text-white transition-colors hover:border-white/35 hover:bg-white/10 sm:gap-2.5 sm:px-2.5"
                      aria-label={`Abrir perfil e configurações de ${session.name}`}
                      title="Perfil e configurações"
                    >
                <span className="grid h-9 w-9 shrink-0 place-items-center overflow-hidden rounded-full border border-brand bg-white/10 text-[11px] font-bold text-white ring-2 ring-brand/20">
                        {profilePhoto ? (
                          <img src={profilePhoto} alt="" className="h-full w-full object-cover" />
                        ) : (
                          session.name
                            .split(" ")
                            .map((part) => part[0])
                            .slice(0, 2)
                            .join("")
                            .toUpperCase()
                        )}
                      </span>
                      <span className="min-w-0 flex-1 text-left">
                        <span className="block truncate text-xs font-semibold sm:max-w-40 sm:text-sm">
                          <span className="sm:hidden">{session.name.trim().split(/\s+/)[0]}</span>
                          <span className="hidden sm:inline">{session.name}</span>
                        </span>
                        <span className="mt-0.5 block text-[10px] font-medium text-white/65">
                          Minha conta
                        </span>
                      </span>
                      <ChevronDown className="h-3.5 w-3.5 shrink-0 text-white/65 transition group-hover:text-white" />
                    </button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent
                    align="end"
                    className="w-[min(19rem,calc(100vw-1rem))] rounded-xl p-2"
                  >
                    <DropdownMenuLabel className="px-3 py-2.5">
                      <span className="flex min-w-0 items-center gap-3">
                        <span className="grid h-11 w-11 shrink-0 place-items-center overflow-hidden rounded-full bg-accent text-xs font-extrabold text-accent-foreground ring-1 ring-border">
                          {profilePhoto ? (
                            <img src={profilePhoto} alt="" className="h-full w-full object-cover" />
                          ) : (
                            session.name.split(" ").map((part) => part[0]).slice(0, 2).join("").toUpperCase()
                          )}
                        </span>
                        <span className="min-w-0 flex-1">
                          <span className="block truncate text-sm font-bold text-foreground">{session.name}</span>
                          <span className="mt-0.5 block truncate text-xs font-normal text-muted-foreground">{session.email}</span>
                        </span>
                      </span>
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    {!isManagement && (
                      <DropdownMenuItem asChild className="cursor-pointer rounded-md py-2.5">
                        <Link to="/perfil">
                          <Settings2 />
                          <span>Perfil e configurações</span>
                        </Link>
                      </DropdownMenuItem>
                    )}
                    {!isManagement && (
                      <DropdownMenuItem asChild className="cursor-pointer rounded-md py-2.5">
                        <Link to="/meus-servicos">
                          <ClipboardCheck />
                          <span>Meus serviços</span>
                        </Link>
                      </DropdownMenuItem>
                    )}
                    {!isManagement && (
                      <DropdownMenuItem asChild className="cursor-pointer rounded-md py-2.5">
                        <Link to="/mensagens">
                          <Inbox />
                          <span>Mensagens</span>
                        </Link>
                      </DropdownMenuItem>
                    )}
                    {!isManagement && (
                      <DropdownMenuItem asChild className="cursor-pointer rounded-md py-2.5">
                        <Link to="/notificacoes">
                          <Bell />
                          <span>Central de notificações</span>
                        </Link>
                      </DropdownMenuItem>
                    )}
                    {!isManagement && hasProfessionalAccess(session)
                      ? professionalTools.map((item) => (
                          <DropdownMenuItem
                            key={item.to}
                            asChild
                            className="cursor-pointer rounded-md py-2.5"
                          >
                            <Link to={item.to}>
                              <item.icon />
                              <span>{item.label}</span>
                            </Link>
                          </DropdownMenuItem>
                        ))
                      : !isManagement && (
                          <DropdownMenuItem
                            onSelect={enableProfessionalProfile}
                            className="cursor-pointer rounded-md py-2.5"
                          >
                            <BriefcaseBusiness />
                            <span>Ativar perfil profissional</span>
                          </DropdownMenuItem>
                        )}
                    <DropdownMenuCheckboxItem
                      checked={theme === "dark"}
                      onCheckedChange={(checked) => setThemeMode(checked ? "dark" : "light")}
                      className="cursor-pointer rounded-md py-2.5"
                    >
                      <span className="inline-flex items-center gap-2">
                        {theme === "dark" ? <Moon /> : <Sun />}Tema escuro
                      </span>
                    </DropdownMenuCheckboxItem>
                    <DropdownMenuSeparator />
                    {isManagement && (
                      <DropdownMenuItem asChild className="cursor-pointer rounded-md py-2.5">
                        <Link to="/">
                          <Home />
                          <span>Ir para a plataforma</span>
                        </Link>
                      </DropdownMenuItem>
                    )}
                    <DropdownMenuItem
                      onSelect={signOut}
                      className="cursor-pointer rounded-md py-2.5 text-destructive focus:text-destructive"
                    >
                      <LogOut />
                      <span>Sair da conta</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              ) : (
                <Link
                  to="/entrar"
                  search={{ perfil: "cliente" }}
                  className="inline-flex rounded-sm bg-brand px-4 py-2.5 text-xs font-extrabold text-brand-foreground transition-colors hover:brightness-95"
                >
                  Entrar
                </Link>
              )}
            </div>
          </div>

          <div className="flex items-center gap-2 py-2 sm:hidden">
            <form
              onSubmit={searchSubmit}
              className="flex min-w-0 flex-1 items-center gap-2 rounded-md border border-white/70 bg-white px-3 py-1.5 shadow-sm focus-within:border-brand"
            >
              <Search className="h-4 w-4 shrink-0 text-primary/70" />
              <input
                value={searchText}
                onChange={(event) => setSearchText(event.target.value)}
                placeholder="Qual serviço você procura hoje?"
                aria-label="Pesquisar serviços"
                className="min-w-0 flex-1 bg-transparent text-xs text-slate-900 outline-none placeholder:text-slate-500"
              />
              <button
                aria-label="Pesquisar"
                className="rounded-sm bg-primary px-3 py-2 text-[10px] font-bold text-primary-foreground"
              >
                Buscar
              </button>
            </form>
            <button
              type="button"
              onClick={locate}
              className="grid h-10 w-10 shrink-0 place-items-center rounded-md border border-white/20 text-white transition-colors hover:bg-white/10"
              title={location ? "Localização ativa" : "Definir localização"}
              aria-label={location ? "Atualizar localização" : "Definir localização"}
            >
              <LocateFixed
                className={cn("h-4 w-4", location ? "text-status-success" : "text-primary")}
              />
            </button>
          </div>

          <nav
            aria-label="Navegação principal"
            className="no-scrollbar overflow-x-auto border-t border-white/15 py-1.5"
          >
            <div className="mx-auto flex w-max min-w-full justify-center gap-1">
              {nav.map((item) => (
                <Link
                  key={item.to}
                  to={item.to}
                  aria-current={isActive(item.to) ? "page" : undefined}
                  className={cn(
                    "inline-flex shrink-0 items-center gap-2 rounded-none border-b border-transparent px-3.5 py-3 text-sm font-semibold transition-colors",
                    isActive(item.to)
                      ? "border-brand text-brand"
                      : "text-white/70 hover:border-white/30 hover:text-white",
                  )}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </Link>
              ))}
            </div>
          </nav>
        </div>
      </header>

      <main className="servix-page-frame mx-auto w-full max-w-[1440px] px-4 pb-10 pt-6 sm:px-6 lg:px-8 2xl:px-10 md:pb-16">
        {isProfessionalWorkspace && (!sessionReady || !hasProfessionalAccess(session)) ? (
          <div className="surface mx-auto max-w-lg p-8 text-center">
            <p className="font-display text-lg font-bold">Verificando acesso profissional…</p>
            <p className="mt-1 text-sm text-muted-foreground">
              Você será direcionado ao cadastro do perfil profissional.
            </p>
          </div>
        ) : (
          children
        )}
      </main>
    </div>
  );
}
