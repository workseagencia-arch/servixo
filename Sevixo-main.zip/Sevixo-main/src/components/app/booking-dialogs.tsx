import { useEffect, useRef, useState } from "react";
import { useNavigate } from "@tanstack/react-router";
import { toast } from "sonner";
import {
  ArrowUpRight,
  BadgeCheck,
  Check,
  Clock3,
  ImagePlus,
  MapPin,
  MessageCircle,
  UserRound,
} from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  brl,
  categories,
  categoryName,
  addQuoteRequest,
  type CategorySlug,
  type Professional,
} from "@/lib/demo-data";
import { cn } from "@/lib/utils";
import { readSession } from "@/lib/auth-store";
import { readDeviceLocation } from "@/lib/location-store";
import { startProfessionalChat } from "@/lib/message-store";
import { Avatar, Rating } from "@/components/app/ui-bits";
import { prepareCampaignImage } from "@/lib/campaign-image";

const input =
  "w-full rounded-xl border bg-background px-3.5 py-3 text-sm outline-none focus:ring-2 focus:ring-ring";

type ServiceDetail = {
  name: string;
  price: number | null;
  duration: string;
  description?: string;
  category?: string;
};

export function HireDialog({
  pro,
  service,
  open,
  onOpenChange,
}: {
  pro: Professional;
  service: ServiceDetail | null;
  open: boolean;
  onOpenChange: (o: boolean) => void;
}) {
  const navigate = useNavigate();
  const openChat = () => {
    const session = readSession();
    if (!session) {
      onOpenChange(false);
      void navigate({ to: "/entrar", search: { perfil: "cliente" } });
      return;
    }
    const sender = session?.role === "profissional" ? "profissional" : "cliente";
    const thread = startProfessionalChat({
      proId: pro.id,
      service: service?.name ?? "Conversa sobre serviços",
      clientName: session.name,
      professionalName: pro.name,
      ...(pro.photoUrl ? { professionalPhotoUrl: pro.photoUrl } : {}),
      ...(service?.price !== undefined ? { price: service.price } : {}),
      ...(service?.duration !== undefined ? { duration: service.duration } : {}),
      sender,
    });
    onOpenChange(false);
    toast.success("Conversa aberta. Escreva sua mensagem quando quiser.");
    void navigate({
      to: sender === "profissional" ? "/pro/mensagens" : "/mensagens",
      search: { thread: thread.id },
    });
  };
  const viewProfile = () => {
    onOpenChange(false);
    void navigate({ to: "/profissional/$id", params: { id: pro.id } });
  };
  const category = service?.category ?? pro.category;

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent className="max-h-[90dvh] max-w-2xl overflow-y-auto p-0 sm:rounded-lg">
        <div className="border-b bg-muted/35 px-5 pb-5 pt-6 sm:px-7">
          <DialogHeader>
            <p className="text-xs font-bold uppercase tracking-[0.14em] text-primary">
              Detalhes do serviço
            </p>
            <DialogTitle className="font-display mt-2 pr-7 text-2xl font-extrabold sm:text-3xl">
              {service?.name ?? "Serviços do profissional"}
            </DialogTitle>
            <DialogDescription className="mt-1">
              Confira as informações e escolha se quer conhecer o perfil completo ou conversar.
            </DialogDescription>
          </DialogHeader>
        </div>
        <div className="space-y-5 px-5 py-5 sm:px-7 sm:py-6">
          <div className="flex min-w-0 items-center gap-3 border-b pb-5">
            <Avatar pro={pro} size="md" />
            <div className="min-w-0 flex-1">
              <p className="flex items-center gap-1.5 truncate font-display font-bold">
                {pro.name}
                {pro.verified && <BadgeCheck className="h-4 w-4 shrink-0 text-status-success" />}
              </p>
              <p className="mt-0.5 truncate text-xs text-muted-foreground">
                {pro.role} · {pro.neighborhood}
              </p>
              <Rating value={pro.rating} count={pro.reviews} className="mt-1 text-xs" />
            </div>
            {pro.verified && (
              <span className="hidden items-center gap-1 rounded-sm bg-accent px-2.5 py-1.5 text-[11px] font-bold text-accent-foreground sm:inline-flex">
                <UserRound className="h-3.5 w-3.5" /> Perfil verificado
              </span>
            )}
          </div>

          <div className="grid gap-3 sm:grid-cols-3">
            <div className="rounded-sm border p-4">
              <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
                Categoria
              </p>
              <p className="mt-1 font-semibold">{categoryName(category)}</p>
            </div>
            <div className="rounded-sm border p-4">
              <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
                Valor anunciado
              </p>
              <p className="mt-1 font-display text-lg font-extrabold">
                {service?.price == null ? "A combinar" : brl(service.price)}
              </p>
            </div>
            <div className="rounded-sm border p-4">
              <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
                Duração estimada
              </p>
              <p className="mt-1 flex items-center gap-1.5 font-semibold">
                <Clock3 className="h-4 w-4 text-primary" />
                {service?.duration ?? "A combinar"}
              </p>
            </div>
          </div>

          <div>
            <h3 className="text-sm font-bold">Sobre este serviço</h3>
            <p className="mt-1.5 whitespace-pre-line text-sm leading-relaxed text-muted-foreground">
              {service?.description || pro.bio}
            </p>
            {service?.price == null && service && (
              <p className="mt-3 rounded-sm bg-muted px-3.5 py-3 text-xs leading-relaxed text-muted-foreground">
                O valor será combinado diretamente com o profissional antes da confirmação.
              </p>
            )}
          </div>

          <div className="grid gap-2 border-t pt-4 sm:grid-cols-2">
            <button
              type="button"
              onClick={viewProfile}
              className="inline-flex min-h-11 items-center justify-center gap-2 rounded-sm border px-4 py-3 text-sm font-bold transition hover:bg-muted"
            >
              Ver perfil completo <ArrowUpRight className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={openChat}
              className="inline-flex min-h-11 items-center justify-center gap-2 rounded-sm bg-primary px-4 py-3 text-sm font-bold text-primary-foreground transition hover:bg-primary/90"
            >
              <MessageCircle className="h-4 w-4" /> Conversar no chat
            </button>
          </div>
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function QuoteDialog({
  pro,
  open,
  onOpenChange,
  defaultText = "",
  defaultCategory,
  referencePrice,
  sourceService,
  returnTo = "/meus-servicos",
}: {
  pro?: Professional;
  open: boolean;
  onOpenChange: (o: boolean) => void;
  defaultText?: string;
  defaultCategory?: CategorySlug | undefined;
  referencePrice?: number | undefined;
  sourceService?: string | undefined;
  returnTo?: "/meus-servicos" | "/vagas";
}) {
  const [description, setDescription] = useState(defaultText);
  const [category, setCategory] = useState<string>(pro?.category ?? defaultCategory ?? "reformas");
  const [when, setWhen] = useState<"asap" | "semana" | "data">("asap");
  const [date, setDate] = useState("");
  const [cep, setCep] = useState("");
  const [address, setAddress] = useState("");
  const [number, setNumber] = useState("");
  const [complement, setComplement] = useState("");
  const [photos, setPhotos] = useState<string[]>([]);
  const [uploadingPhotos, setUploadingPhotos] = useState(false);
  const photoUploadRef = useRef(0);
  const [sent, setSent] = useState(false);
  const navigate = useNavigate();

  useEffect(() => {
    if (open) {
      setDescription(defaultText);
      setCategory(pro?.category ?? defaultCategory ?? "reformas");
      setWhen("asap");
      setDate("");
      setCep("");
      setAddress("");
      setNumber("");
      setComplement("");
      setPhotos([]);
      setUploadingPhotos(false);
      setSent(false);
    }
    return () => {
      photoUploadRef.current += 1;
    };
  }, [open, pro?.category, defaultCategory, defaultText]);

  const canSend = !!description.trim() && !uploadingPhotos;

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!canSend) return;
    if (!readSession()) {
      onOpenChange(false);
      void navigate({ to: "/entrar", search: { perfil: "cliente" } });
      return;
    }
    if (pro) {
      const session = readSession();
      if (!session) {
        onOpenChange(false);
        void navigate({ to: "/entrar", search: { perfil: "cliente" } });
        return;
      }
      const sender = session?.role === "profissional" ? "profissional" : "cliente";
      const thread = startProfessionalChat({
        proId: pro.id,
        service: `Orçamento · ${categoryName(category)}`,
        clientName: session?.name ?? "Cliente",
        professionalName: pro.name,
        ...(pro.photoUrl ? { professionalPhotoUrl: pro.photoUrl } : {}),
        sender,
      });
      onOpenChange(false);
      toast.success("Conversa aberta. Escreva sua mensagem para alinhar o orçamento.");
      void navigate({
        to: sender === "profissional" ? "/pro/mensagens" : "/mensagens",
        search: { thread: thread.id },
      });
      return;
    }
    const location = readDeviceLocation("cliente");
    const ownerEmail = readSession()?.email;
    addQuoteRequest({
      description: description.trim(),
      category,
      ...(ownerEmail ? { ownerEmail } : {}),
      ...(location ? { latitude: location.latitude, longitude: location.longitude } : {}),
      when,
      ...(when === "data" ? { date } : {}),
      cep,
      address,
      number,
      complement,
      photos,
      ...(referencePrice !== undefined ? { referencePrice } : {}),
      ...(sourceService ? { sourceService } : {}),
    });
    setSent(true);
  };

  const finish = () => {
    onOpenChange(false);
    if (returnTo === "/vagas") navigate({ to: "/vagas" });
    else navigate({ to: "/meus-servicos", search: { tab: "Orçamentos" } });
  };

  const whenOpts = [
    ["asap", "O quanto antes"],
    ["semana", "Esta semana"],
    ["data", "Escolher uma data"],
  ] as const;

  return (
    <Dialog open={open} onOpenChange={(o) => (sent && !o ? finish() : onOpenChange(o))}>
      <DialogContent className="max-h-[calc(100dvh-1rem)] w-[calc(100vw-1rem)] max-w-md overflow-y-auto rounded-3xl">
        {sent ? (
          <div className="py-4 text-center">
            <span className="mx-auto grid h-14 w-14 place-items-center rounded-full bg-accent text-accent-foreground">
              <Check className="h-7 w-7" />
            </span>
            <DialogTitle className="font-display mt-4 text-2xl">Solicitação enviada!</DialogTitle>
            <DialogDescription className="mt-2">
              Profissionais compatíveis poderão analisar seu pedido e enviar propostas.
            </DialogDescription>
            <button
              onClick={finish}
              className="mt-6 w-full rounded-full bg-primary py-3.5 font-bold text-primary-foreground hover:bg-primary/90"
            >
              {returnTo === "/vagas" ? "Ver minhas vagas" : "Ver meus orçamentos"}
            </button>
          </div>
        ) : (
          <>
            <DialogHeader>
              <DialogTitle className="font-display text-2xl">
                {pro
                  ? "Solicitar orçamento"
                  : referencePrice !== undefined
                    ? "Encontrar profissional para este serviço"
                    : "Solicitar orçamento"}
              </DialogTitle>
              <DialogDescription>
                {pro
                  ? `Uma conversa com ${pro.name} será aberta quando você escolher continuar.`
                  : "Profissionais compatíveis com a categoria poderão ver o pedido e enviar propostas."}
              </DialogDescription>
            </DialogHeader>
            <form className="space-y-4" onSubmit={submit}>
              {referencePrice !== undefined && (
                <div className="flex flex-wrap items-center justify-between gap-2 rounded-sm border border-primary/20 bg-accent/50 px-4 py-3">
                  <span className="min-w-0">
                    <span className="block text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
                      Serviço selecionado
                    </span>
                    <span className="mt-0.5 block truncate text-sm font-bold">
                      {sourceService ?? "Preço fechado"}
                    </span>
                  </span>
                  <span className="font-display text-lg font-extrabold">{brl(referencePrice)}</span>
                </div>
              )}
              <div>
                <p className="mb-2 text-sm font-semibold">
                  {referencePrice !== undefined
                    ? "Informações para os profissionais"
                    : "1. O que você precisa?"}
                </p>
                <textarea
                  aria-label="Descreva o serviço"
                  required
                  rows={4}
                  value={description}
                  onChange={(e) => setDescription(e.target.value)}
                  className={input}
                  placeholder="Descreva detalhes importantes do serviço..."
                />
              </div>
              <div>
                <p className="mb-2 text-sm font-semibold">2. Categoria</p>
                {pro ? (
                  <p className="rounded-xl bg-muted px-3.5 py-3 text-sm font-semibold">
                    {categoryName(category)}
                  </p>
                ) : (
                  <select
                    className={input}
                    value={category}
                    onChange={(e) => setCategory(e.target.value)}
                    aria-label="Categoria"
                  >
                    {categories.map((c) => (
                      <option key={c.slug} value={c.slug}>
                        {c.name}
                      </option>
                    ))}
                  </select>
                )}
              </div>
              {!pro && (
                <div>
                  <p className="mb-2 text-sm font-semibold">3. Quando você precisa?</p>
                  <div className="grid grid-cols-3 gap-2">
                    {whenOpts.map(([v, l]) => (
                      <button
                        key={v}
                        type="button"
                        onClick={() => setWhen(v)}
                        className={cn(
                          "rounded-xl border p-2.5 text-xs font-semibold",
                          when === v && "border-primary bg-accent",
                        )}
                      >
                        {l}
                      </button>
                    ))}
                  </div>
                  {when === "data" && (
                    <input
                      required
                      type="date"
                      value={date}
                      onChange={(e) => setDate(e.target.value)}
                      className={cn(input, "mt-2")}
                      aria-label="Data"
                    />
                  )}
                </div>
              )}
              {!pro && (
                <div className="space-y-2">
                  <p className="flex items-center gap-1.5 text-sm font-semibold">
                    <MapPin className="h-4 w-4" />
                    4. Local do serviço
                  </p>
                  <input
                    required
                    inputMode="numeric"
                    autoComplete="postal-code"
                    aria-label="CEP do serviço"
                    value={cep}
                    onChange={(e) => setCep(e.target.value)}
                    placeholder="CEP *"
                    className={input}
                  />
                  <input
                    required
                    autoComplete="street-address"
                    aria-label="Endereço do serviço"
                    value={address}
                    onChange={(e) => setAddress(e.target.value)}
                    placeholder="Endereço *"
                    className={input}
                  />
                  <div className="grid grid-cols-2 gap-2">
                    <input
                      required
                      aria-label="Número do local do serviço"
                      value={number}
                      onChange={(e) => setNumber(e.target.value)}
                      placeholder="Número *"
                      className={input}
                    />
                    <input
                      value={complement}
                      onChange={(e) => setComplement(e.target.value)}
                      placeholder="Complemento"
                      className={input}
                    />
                  </div>
                  <p className="text-xs leading-relaxed text-muted-foreground">
                    Informe CEP, endereço e número para que profissionais da região possam avaliar o
                    pedido.
                  </p>
                </div>
              )}
              {!pro && (
                <div>
                  <p className="mb-2 text-sm font-semibold">5. Fotos</p>
                  {photos.length > 0 && (
                    <div className="mb-2 grid grid-cols-4 gap-2">
                      {photos.map((u, i) => (
                        <img
                          key={u}
                          src={u}
                          alt={`Foto ${i + 1}`}
                          className="aspect-square w-full rounded-lg object-cover"
                        />
                      ))}
                    </div>
                  )}
                  <label className="flex w-full cursor-pointer items-center justify-center gap-2 rounded-xl border border-dashed py-4 text-sm font-semibold text-muted-foreground hover:bg-muted">
                    <ImagePlus className="h-4 w-4" />{" "}
                    {photos.length
                      ? `${photos.length} foto(s) · adicionar mais`
                      : "Adicionar fotos"}
                    <input
                      type="file"
                      accept="image/jpeg,image/png,image/webp"
                      multiple
                      className="hidden"
                      disabled={uploadingPhotos}
                      aria-label="Fotos de referência do serviço"
                      onChange={async (e) => {
                        const files = Array.from(e.target.files ?? []).slice(0, 5 - photos.length);
                        e.target.value = "";
                        if (!files.length) {
                          toast.error("Você pode anexar até 5 imagens.");
                          return;
                        }
                        const generation = photoUploadRef.current;
                        setUploadingPhotos(true);
                        const results = await Promise.allSettled(files.map(prepareCampaignImage));
                        if (generation !== photoUploadRef.current) return;
                        const images = results.flatMap((result) =>
                          result.status === "fulfilled" ? [result.value] : [],
                        );
                        setPhotos((current) => [...current, ...images].slice(0, 5));
                        setUploadingPhotos(false);
                        const rejected = results.find((result) => result.status === "rejected");
                        if (rejected?.status === "rejected")
                          toast.error(
                            rejected.reason instanceof Error
                              ? rejected.reason.message
                              : "Não foi possível preparar uma das imagens.",
                          );
                      }}
                    />
                  </label>
                  <p role="status" className="mt-2 text-xs text-muted-foreground">
                    {uploadingPhotos
                      ? "Preparando imagens…"
                      : "Até 5 fotos em JPG, PNG ou WebP. Até 8 MB por imagem."}
                  </p>
                </div>
              )}
              {pro && (
                <p className="rounded-xl bg-muted p-3 text-xs leading-relaxed text-muted-foreground">
                  A conversa ficará pronta para você escrever. Nenhuma mensagem será enviada
                  automaticamente.
                </p>
              )}
              <button
                disabled={!canSend}
                className="w-full rounded-sm bg-primary py-3.5 font-bold text-primary-foreground hover:bg-primary/90 disabled:opacity-50"
              >
                {pro
                  ? "Abrir conversa"
                  : referencePrice !== undefined
                    ? "Publicar pedido para profissionais"
                    : "Enviar solicitação"}
              </button>
            </form>
          </>
        )}
      </DialogContent>
    </Dialog>
  );
}
