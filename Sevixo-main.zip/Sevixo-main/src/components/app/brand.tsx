import { Link } from "@tanstack/react-router";
import { cn } from "@/lib/utils";

/** ServiX logo: two crossing tool strokes forming an X, one in brand lime. */
export function LogoMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 40 40" className={cn("h-9 w-9", className)} aria-hidden="true">
      <rect width="40" height="40" rx="9" className="fill-[#06271b]" />
      <path
        d="M12 12 L28 28"
        strokeWidth="6"
        strokeLinecap="round"
        className="stroke-white"
      />
      <path d="M28 12 L12 28" strokeWidth="6" strokeLinecap="round" className="stroke-brand" />
      <circle cx="28" cy="12" r="3.2" className="fill-brand" />
    </svg>
  );
}

export function Logo({
  className,
  to = "/",
}: {
  className?: string;
  to?: "/" | "/pro" | "/gestao" | "/gestao/anuncios";
}) {
  return (
    <Link
      to={to}
      className={cn("flex items-center gap-2.5", className)}
      aria-label="ServiX — início"
    >
      <LogoMark />
      <span className="font-display text-[1.35rem] font-extrabold leading-none text-white">
        servi
        <span className="relative">
          x<span className="absolute -bottom-0.5 left-0 h-1 w-full rounded-full bg-brand" />
        </span>
      </span>
    </Link>
  );
}
