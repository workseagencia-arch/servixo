import { useState, type FormEvent } from "react";
import { Check, ChevronDown, Search, SlidersHorizontal, Wrench, ArrowRight } from "lucide-react";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import { categories, type CategorySlug } from "@/lib/demo-data";
import { CategoryIcon } from "./ui-bits";

import { normalizeSearch } from "@/lib/search";

export function CategoryPicker({
  selected,
  onSelect,
}: {
  selected: CategorySlug | undefined;
  onSelect: (category?: CategorySlug) => void;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const category = categories.find((item) => item.slug === selected);
  const terms = normalizeSearch(query.trim()).split(/\s+/).filter(Boolean);
  const list = categories.filter((item) =>
    terms.every((term) => normalizeSearch(item.name).includes(term)),
  );
  const select = (slug?: CategorySlug) => {
    onSelect(slug);
    setOpen(false);
    setQuery("");
  };
  return (
    <Dialog
      open={open}
      onOpenChange={(next) => {
        setOpen(next);
        if (!next) setQuery("");
      }}
    >
      <DialogTrigger asChild>
        <button
          type="button"
          aria-label={`Escolher categoria: ${category?.name ?? "Todas as categorias"}`}
          className="flex min-w-0 items-center gap-3 rounded-lg border border-primary-foreground/30 bg-primary-foreground/5 px-4 py-3 text-left text-primary-foreground hover:bg-primary-foreground/10"
        >
          <SlidersHorizontal className="h-5 w-5 shrink-0 text-brand" />
          <span className="min-w-0 flex-1">
            <span className="block text-[11px] text-primary-foreground/65">
              Filtrar por categoria
            </span>
            <span className="mt-0.5 block truncate text-sm font-semibold">
              {category?.name ?? "Todas as categorias"}
            </span>
          </span>
          <ChevronDown className="h-4 w-4 shrink-0" />
        </button>
      </DialogTrigger>
      <DialogContent className="flex max-h-[min(88dvh,44rem)] w-[calc(100%-2rem)] flex-col gap-0 overflow-hidden rounded-xl bg-card p-0 sm:max-w-2xl">
        <DialogHeader className="shrink-0 border-b p-5 pr-12 text-left sm:p-6">
          <DialogTitle className="text-xl font-bold">Qual categoria você procura?</DialogTitle>
          <DialogDescription className="pt-1">
            Escolha uma opção para ver os resultados correspondentes.
          </DialogDescription>
        </DialogHeader>
        <div className="shrink-0 px-5 pt-5 sm:px-6">
          <div className="flex items-center gap-3 rounded-lg border bg-background px-3 focus-within:ring-2 focus-within:ring-primary/10">
            <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
            <input
              type="search"
              aria-label="Pesquisar categoria"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Pesquisar uma categoria"
              className="min-w-0 flex-1 bg-transparent py-3 text-sm outline-none"
            />
          </div>
        </div>
        <div className="min-h-0 overflow-y-auto overscroll-contain p-5 sm:p-6">
          {!query.trim() && (
            <button
              type="button"
              aria-pressed={!selected}
              onClick={() => select()}
              className={`mb-3 flex w-full items-center gap-3 rounded-lg border p-3 text-left ${!selected ? "border-primary/35 bg-secondary/60" : "hover:bg-muted"}`}
            >
              <Wrench className="h-5 w-5 shrink-0 text-primary" />
              <span className="flex-1 text-sm font-semibold">Todas as categorias</span>
              {!selected && <Check className="h-4 w-4 text-primary" />}
            </button>
          )}
          <div className="grid min-w-0 gap-2 sm:grid-cols-2">
            {list.map((item) => (
              <button
                key={item.slug}
                type="button"
                aria-pressed={selected === item.slug}
                onClick={() => select(item.slug)}
                className={`flex min-h-16 min-w-0 items-center gap-3 rounded-lg border p-3 text-left ${selected === item.slug ? "border-primary/35 bg-secondary/60" : "hover:border-primary/30 hover:bg-muted/50"}`}
              >
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-muted text-primary">
                  <CategoryIcon slug={item.slug} className="h-4 w-4" />
                </span>
                <span className="min-w-0 flex-1 text-sm font-semibold">{item.name}</span>
                {selected === item.slug && <Check className="h-4 w-4 shrink-0 text-primary" />}
              </button>
            ))}
          </div>
          {!list.length && (
            <p role="status" className="py-8 text-center text-sm text-muted-foreground">
              Nenhuma categoria encontrada. Tente outro termo.
            </p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

export function CatalogSearch({
  title,
  description,
  value,
  onChange,
  onSubmit,
  category,
  onCategory,
  placeholder,
  label,
}: {
  title: string;
  description: string;
  value: string;
  onChange: (value: string) => void;
  onSubmit: (event: FormEvent<HTMLFormElement>) => void;
  category: CategorySlug | undefined;
  onCategory: (slug?: CategorySlug) => void;
  placeholder: string;
  label: string;
}) {
  return (
    <section
      aria-label="Busca e filtros"
      className="overflow-hidden rounded-xl bg-primary p-5 text-primary-foreground sm:p-7 lg:p-8"
    >
      <div className="mb-5 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
        <h2 className="max-w-xl text-2xl font-bold tracking-tight sm:text-3xl">{title}</h2>
        <p className="max-w-sm text-sm leading-relaxed text-primary-foreground/75">{description}</p>
      </div>
      <div className="grid min-w-0 gap-3 lg:grid-cols-[minmax(0,1fr)_18rem]">
        <form
          onSubmit={onSubmit}
          className="flex min-w-0 items-center gap-2 rounded-lg bg-card p-1.5 text-card-foreground focus-within:ring-2 focus-within:ring-brand"
        >
          <Search className="ml-2 h-5 w-5 shrink-0 text-muted-foreground" />
          <input
            type="search"
            aria-label={label}
            value={value}
            onChange={(event) => onChange(event.target.value)}
            placeholder={placeholder}
            className="min-w-0 flex-1 bg-transparent py-3 text-sm outline-none sm:text-base"
          />
          <button
            type="submit"
            className="inline-flex shrink-0 items-center gap-2 rounded-md bg-brand px-3 py-3 text-sm font-bold text-brand-foreground hover:bg-brand/85 sm:px-5"
          >
            Buscar <ArrowRight className="hidden h-4 w-4 sm:block" />
          </button>
        </form>
        <CategoryPicker selected={category} onSelect={onCategory} />
      </div>
    </section>
  );
}
