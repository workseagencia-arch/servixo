import { useEffect, useRef, useState, type ChangeEvent } from "react";
import { Link, useNavigate } from "@tanstack/react-router";
import {
  ArrowLeft,
  BriefcaseBusiness,
  Check,
  CheckCheck,
  MessageCircle,
  Mic,
  Paperclip,
  Search,
  Send,
  Square,
  Trash2,
} from "lucide-react";
import { toast } from "sonner";
import { Avatar, PageTitle } from "@/components/app/ui-bits";
import { conversations, findPro, proMe, type Message } from "@/lib/demo-data";
import { readSession, type AccountRole } from "@/lib/auth-store";
import {
  appendChatMessage,
  confirmChatService,
  readChatThread,
  readManagedChatThreads,
  subscribeToChatMessages,
  type ChatMessage,
  type ManagedChatThread,
} from "@/lib/message-store";
import { cn } from "@/lib/utils";
import { AdPlacement } from "@/components/app/ad-placement";
import { getClientFacingProfessionalById } from "@/lib/professional-store";
import { EmptyState, secondaryActionClass } from "@/components/app/workspace-ui";

const initials = (name: string) =>
  name
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();
const threadIdFor = (index: number) =>
  `${conversations[index]!.proId}:${conversations[index]!.order}`;
const currentTime = () =>
  new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" });

type DisplayThread = {
  id: string;
  proId: string;
  order: string;
  unread: number;
  last: ChatMessage;
  staticIndex?: number;
  managed?: ManagedChatThread;
};

function blobToDataUrl(blob: Blob) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () =>
      typeof reader.result === "string"
        ? resolve(reader.result)
        : reject(new Error("Arquivo inválido"));
    reader.onerror = () => reject(new Error("Não foi possível ler o arquivo"));
    reader.readAsDataURL(blob);
  });
}

export function MessagesPage({
  role,
  initialThread,
}: {
  role: AccountRole;
  initialThread?: string | undefined;
}) {
  const isPro = role === "profissional";
  const [active, setActive] = useState<string | null>(initialThread ?? null);
  const navigate = useNavigate();
  const activeRef = useRef(active);
  activeRef.current = active;
  const selectThread = (thread: string | null) => {
    setActive(thread);
    navigate({
      to: isPro ? "/pro/mensagens" : "/mensagens",
      search: thread ? { thread } : {},
      replace: true,
    });
  };
  const [search, setSearch] = useState("");
  const [text, setText] = useState("");
  const [recording, setRecording] = useState(false);
  const [threads, setThreads] = useState<ChatMessage[][]>(() =>
    conversations.map((conversation, index) =>
      readChatThread(threadIdFor(index), conversation.messages),
    ),
  );
  const [managedThreads, setManagedThreads] = useState<ManagedChatThread[]>([]);
  const messagesEndRef = useRef<HTMLDivElement>(null);
  const cancelAudioRef = useRef(false);
  const mountedRef = useRef(true);
  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<BlobPart[]>([]);
  const recordingThreadRef = useRef<string | null>(null);

  useEffect(() => {
    setActive(initialThread ?? null);
  }, [initialThread]);

  useEffect(() => {
    const refresh = () => {
      setManagedThreads(readManagedChatThreads());
      setThreads(
        conversations.map((conversation, index) =>
          readChatThread(threadIdFor(index), conversation.messages),
        ),
      );
    };
    refresh();
    return subscribeToChatMessages(refresh);
  }, []);

  useEffect(() => {
    mountedRef.current = true;
    return () => {
      mountedRef.current = false;
      cancelAudioRef.current = true;
      if (recorderRef.current?.state === "recording") recorderRef.current.stop();
      streamRef.current?.getTracks().forEach((track) => track.stop());
    };
  }, []);

  const staticItems: DisplayThread[] = conversations.map((conversation, index) => ({
    id: threadIdFor(index),
    proId: conversation.proId,
    order: conversation.order,
    unread: conversation.unread,
    last:
      threads[index]?.at(-1) ??
      ({ from: "them", text: "", time: "", id: "empty", sender: "profissional" } as ChatMessage),
    staticIndex: index,
  }));
  const managedItems: DisplayThread[] = managedThreads
    .filter((thread) =>
      isPro
        ? thread.proId === proMe.id
        : !thread.clientEmail ||
          thread.clientEmail.toLocaleLowerCase("pt-BR") ===
            readSession()?.email.toLocaleLowerCase("pt-BR"),
    )
    .map((thread) => ({
      id: thread.id,
      proId: thread.proId,
      order: thread.order,
      unread: 0,
      last:
        readChatThread(thread.id, []).at(-1) ??
        ({
          from: "them",
          text: "Conversa pronta para começar",
          time: "",
          id: "empty",
          sender: "cliente",
        } as ChatMessage),
      managed: thread,
    }));
  const allThreads = [...managedItems, ...staticItems];
  const titleFor = (item: DisplayThread) =>
    item.managed
      ? isPro
        ? item.managed.clientName
        : (item.managed.professionalName ??
          getClientFacingProfessionalById(item.proId)?.name ??
          findPro(item.proId)?.name ??
          "Profissional")
      : isPro
        ? "Cliente ServiX"
        : (getClientFacingProfessionalById(item.proId)?.name ??
          findPro(item.proId)?.name ??
          "Profissional");
  const avatarFor = (item: DisplayThread) => {
    const base = findPro(item.proId) ?? getClientFacingProfessionalById(item.proId) ?? proMe;
    return isPro
      ? {
          ...base,
          name: titleFor(item),
          initials: initials(titleFor(item)),
          online: false,
          photoUrl: "",
        }
      : {
          ...base,
          initials: initials(titleFor(item)),
          photoUrl: item.managed?.professionalPhotoUrl ?? base.photoUrl ?? "",
        };
  };
  const threadItems = allThreads
    .filter((item) =>
      `${titleFor(item)} ${item.order}`
        .toLocaleLowerCase("pt-BR")
        .includes(search.toLocaleLowerCase("pt-BR")),
    )
    .sort((a, b) => (b.managed?.createdAt ?? "").localeCompare(a.managed?.createdAt ?? ""));
  const currentThread = active ? allThreads.find((item) => item.id === active) : undefined;
  const currentMessages = currentThread
    ? currentThread.managed
      ? readChatThread(currentThread.id, [])
      : (threads[currentThread.staticIndex!] ?? [])
    : [];
  const activePro = currentThread
    ? (getClientFacingProfessionalById(currentThread.proId) ?? findPro(currentThread.proId))
    : undefined;

  useEffect(() => {
    setText("");
    cancelAudioRef.current = true;
    if (recorderRef.current?.state === "recording") recorderRef.current.stop();
    setRecording(false);
  }, [active]);
  useEffect(() => {
    messagesEndRef.current?.scrollIntoView({ block: "end" });
  }, [active, currentMessages.length]);

  const addMessage = (message: Message, threadId = active) => {
    if (!threadId) return false;
    const item = allThreads.find((candidate) => candidate.id === threadId);
    const initialMessages =
      item?.staticIndex === undefined ? [] : conversations[item.staticIndex]!.messages;
    try {
      appendChatMessage(threadId, initialMessages, role, message);
      setManagedThreads(readManagedChatThreads());
      setThreads(
        conversations.map((conversation, index) =>
          readChatThread(threadIdFor(index), conversation.messages),
        ),
      );
      return true;
    } catch {
      toast.error(
        "Não foi possível salvar a mensagem. Libere espaço no navegador e tente novamente.",
      );
      return false;
    }
  };

  const sendText = () => {
    if (!text.trim() || active === null) return;
    if (addMessage({ from: "me", text: text.trim(), time: currentTime() })) setText("");
  };
  const attachFile = async (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    const threadId = active;
    event.currentTarget.value = "";
    if (!threadId) {
      toast.error("Selecione uma conversa antes de anexar um arquivo.");
      return;
    }
    if (file.size > 1.5 * 1024 * 1024) {
      toast.error("Para manter o chat leve, o arquivo deve ter até 1,5 MB.");
      return;
    }
    try {
      const url = await blobToDataUrl(file);
      addMessage(
        {
          from: "me",
          text: file.type.startsWith("image/") ? "Imagem anexada" : file.name,
          time: currentTime(),
          ...(file.type.startsWith("audio/")
            ? { audioUrl: url }
            : { attachmentUrl: url, attachmentName: file.name, attachmentType: file.type }),
        },
        threadId,
      );
    } catch {
      toast.error("Não foi possível abrir esse arquivo.");
    }
  };
  const startRecording = async () => {
    if (!navigator.mediaDevices?.getUserMedia || typeof MediaRecorder === "undefined") {
      toast.error("Este navegador não oferece gravação de áudio.");
      return;
    }
    if (active === null) {
      toast.error("Selecione uma conversa antes de gravar um áudio.");
      return;
    }
    const requestedThread = active;
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ audio: true });
      if (!mountedRef.current || activeRef.current !== requestedThread) {
        stream.getTracks().forEach((track) => track.stop());
        return;
      }
      cancelAudioRef.current = false;
      streamRef.current = stream;
      recordingThreadRef.current = active;
      const recorder = new MediaRecorder(stream);
      recorderRef.current = recorder;
      chunksRef.current = [];
      recorder.ondataavailable = (event) => {
        if (event.data.size) chunksRef.current.push(event.data);
      };
      recorder.onstop = async () => {
        const blob = new Blob(chunksRef.current, { type: recorder.mimeType || "audio/webm" });
        stream.getTracks().forEach((track) => track.stop());
        streamRef.current = null;
        setRecording(false);
        if (cancelAudioRef.current || !mountedRef.current) return;
        if (!blob.size) return;
        if (blob.size > 1.5 * 1024 * 1024) {
          toast.error("O áudio ficou grande demais. Grave uma mensagem mais curta.");
          return;
        }
        try {
          const audioUrl = await blobToDataUrl(blob);
          if (
            cancelAudioRef.current ||
            !mountedRef.current ||
            activeRef.current !== recordingThreadRef.current
          )
            return;
          addMessage(
            { from: "me", text: "Mensagem de voz", time: currentTime(), audioUrl },
            recordingThreadRef.current,
          );
        } catch {
          toast.error("Não foi possível salvar o áudio.");
        }
      };
      recorder.start();
      setRecording(true);
    } catch {
      toast.error("Permita o acesso ao microfone para gravar uma mensagem.");
    }
  };
  const stopRecording = () => {
    if (recorderRef.current?.state === "recording") recorderRef.current.stop();
    setRecording(false);
  };
  const confirmService = () => {
    if (!currentThread?.managed || (role !== "cliente" && role !== "profissional")) return;
    confirmChatService(currentThread.id, role);
    setManagedThreads(readManagedChatThreads());
    toast.success("Sua confirmação foi registrada nesta conversa.");
  };
  const bothConfirmed =
    !!currentThread?.managed?.confirmations.cliente &&
    !!currentThread.managed.confirmations.profissional;
  const myConfirmation =
    role === "cliente" || role === "profissional"
      ? currentThread?.managed?.confirmations[role]
      : false;

  return (
    <div className="servix-workspace min-w-0">
      <PageTitle
        {...(isPro ? { eyebrow: "Área profissional" } : {})}
        title="Mensagens"
        subtitle={
          isPro
            ? "Converse com clientes e acompanhe cada trabalho."
            : "Converse com os profissionais dos seus serviços."
        }
      />
      <div className="grid h-[max(32rem,calc(100dvh-19rem))] max-h-[52rem] min-w-0 grid-cols-1 overflow-hidden rounded-xl border bg-card md:grid-cols-[minmax(14rem,18rem)_minmax(0,1fr)]">
        <aside
          className={cn(
            "min-h-0 min-w-0 flex-col border-r",
            currentThread ? "hidden md:flex" : "flex",
          )}
        >
          <div className="border-b p-3">
            <label className="flex items-center gap-2 rounded-xl bg-muted px-3 py-2">
              <Search className="h-4 w-4 text-muted-foreground" />
              <input
                aria-label="Buscar conversa"
                value={search}
                onChange={(event) => setSearch(event.target.value)}
                placeholder="Buscar conversa"
                className="min-w-0 flex-1 bg-transparent text-sm outline-none"
              />
            </label>
            <div className="mt-3 flex items-center justify-between text-xs">
              <span className="font-bold">Conversas</span>
              <span className="text-muted-foreground">{threadItems.length} ativas</span>
            </div>
          </div>
          <div className="min-h-0 flex-1 overflow-y-auto">
            {threadItems.map((item) => (
              <button
                key={item.id}
                onClick={() => selectThread(item.id)}
                className={cn(
                  "flex w-full items-center gap-3 border-b p-3 text-left transition hover:bg-muted",
                  active === item.id && "bg-muted",
                )}
              >
                <Avatar pro={avatarFor(item)} size="sm" />
                <span className="min-w-0 flex-1">
                  <span className="flex items-center justify-between gap-2">
                    <span className="truncate text-sm font-bold">{titleFor(item)}</span>
                    <span className="shrink-0 text-[10px] text-muted-foreground">
                      {item.last.time}
                    </span>
                  </span>
                  <span className="mt-0.5 flex min-w-0 items-center gap-1 text-[10px] text-primary">
                    <BriefcaseBusiness className="h-3 w-3 shrink-0" />
                    <span className="truncate">{item.order}</span>
                  </span>
                  <span className="mt-1 block truncate text-xs text-muted-foreground">
                    {item.last.audioUrl ? "Mensagem de voz" : item.last.text}
                  </span>
                </span>
                {!isPro && item.unread > 0 && active !== item.id && (
                  <span className="grid h-5 w-5 place-items-center rounded-full bg-brand text-[11px] font-bold text-brand-foreground">
                    {item.unread}
                  </span>
                )}
              </button>
            ))}
            {!threadItems.length && (
              <div className="p-3">
                <EmptyState
                  icon={MessageCircle}
                  title={search ? "Nenhuma conversa encontrada" : "Suas conversas começam aqui"}
                  description={
                    search
                      ? "Tente buscar por outro nome ou serviço."
                      : "Entre em contato pelo perfil de um profissional ou pelos detalhes de um serviço."
                  }
                >
                  {!search && !isPro && (
                    <Link to="/profissionais" className={secondaryActionClass}>
                      Ver profissionais
                    </Link>
                  )}
                </EmptyState>
              </div>
            )}
          </div>
        </aside>
        <section
          className={cn("min-h-0 min-w-0 flex-col", !currentThread ? "hidden md:flex" : "flex")}
        >
          {currentThread ? (
            <>
              <header className="flex items-center gap-3 border-b p-3">
                <button
                  onClick={() => selectThread(null)}
                  className="grid h-9 w-9 place-items-center rounded-full hover:bg-muted md:hidden"
                  aria-label="Voltar às conversas"
                >
                  <ArrowLeft className="h-5 w-5" />
                </button>
                <Avatar pro={avatarFor(currentThread)} size="sm" />
                <div className="min-w-0 flex-1">
                  <p className="truncate font-semibold">{titleFor(currentThread)}</p>
                  <p className="truncate text-xs text-muted-foreground">{currentThread.order}</p>
                </div>
                <span className="hidden rounded-full bg-accent px-2.5 py-1 text-[10px] font-bold text-accent-foreground sm:inline">
                  {currentThread.managed
                    ? bothConfirmed
                      ? "Confirmado"
                      : "Em negociação"
                    : isPro
                      ? "Atendimento"
                      : "Serviço ativo"}
                </span>
              </header>
              {currentThread.managed && (
                <div className="border-b bg-card px-4 py-3">
                  <div className="flex flex-wrap items-center justify-between gap-3">
                    <div>
                      <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
                        Confirmação do serviço
                      </p>
                      <p className="mt-1 text-sm font-semibold">
                        {currentThread.order}
                        {currentThread.managed.price !== null
                          ? ` · R$ ${currentThread.managed.price.toLocaleString("pt-BR")}`
                          : " · valor a combinar"}
                      </p>
                      <p className="mt-0.5 text-xs text-muted-foreground">
                        Alinhem os detalhes pelo chat. O serviço só fica confirmado quando os dois
                        lados aceitarem.
                      </p>
                    </div>
                    {bothConfirmed ? (
                      <span className="inline-flex items-center gap-1.5 rounded-full bg-emerald-50 px-3 py-2 text-xs font-bold text-emerald-800">
                        <CheckCheck className="h-4 w-4" />
                        Confirmado pelas duas partes
                      </span>
                    ) : (
                      <button
                        onClick={confirmService}
                        disabled={
                          !!myConfirmation || (role !== "cliente" && role !== "profissional")
                        }
                        className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2.5 text-xs font-bold text-primary-foreground disabled:opacity-60"
                      >
                        <Check className="h-4 w-4" />
                        {myConfirmation ? "Aguardando outra parte" : "Confirmar serviço"}
                      </button>
                    )}
                  </div>
                  {activePro && (
                    <p className="mt-1 text-[11px] text-muted-foreground">
                      Profissional: {activePro.name}
                      {currentThread.managed.duration ? ` · ${currentThread.managed.duration}` : ""}
                    </p>
                  )}
                </div>
              )}
              <div className="min-h-0 min-w-0 flex-1 overflow-y-auto overscroll-contain bg-muted/35 p-3 sm:p-5">
                {currentMessages.length ? (
                  <div className="space-y-3">
                    {currentMessages.map((message) => (
                      <div
                        key={message.id}
                        className={cn(
                          "w-fit max-w-[90%] break-words rounded-lg px-3.5 py-2.5 text-sm [overflow-wrap:anywhere] sm:max-w-[76%]",
                          message.sender === role
                            ? "ml-auto rounded-br-sm bg-primary text-primary-foreground"
                            : "rounded-bl-sm border border-border bg-card",
                        )}
                      >
                        {message.audioUrl && (
                          <audio controls src={message.audioUrl} className="my-1 max-w-full" />
                        )}
                        {message.attachmentUrl &&
                          (message.attachmentType?.startsWith("image/") ? (
                            <img
                              src={message.attachmentUrl}
                              alt="Imagem enviada"
                              className="h-auto max-h-56 max-w-full rounded-md object-contain"
                            />
                          ) : (
                            <a
                              href={message.attachmentUrl}
                              download={message.attachmentName}
                              className="underline"
                            >
                              {message.attachmentName ?? "Arquivo anexado"}
                            </a>
                          ))}
                        {message.text && (
                          <span className="block whitespace-pre-wrap">{message.text}</span>
                        )}
                        <span className="mt-1 block text-right text-[10px] opacity-60">
                          {message.time}
                        </span>
                      </div>
                    ))}
                  </div>
                ) : (
                  <div className="grid min-h-full place-items-center p-6 text-center">
                    <div className="max-w-sm">
                      <span className="mx-auto grid h-12 w-12 place-items-center rounded-sm bg-card text-primary shadow-sm">
                        <MessageCircle className="h-5 w-5" />
                      </span>
                      <p className="mt-3 font-semibold">Conversa pronta para começar</p>
                      <p className="mt-1 text-sm text-muted-foreground">
                        Nenhuma mensagem foi enviada. Escreva abaixo para alinhar detalhes, prazo e
                        disponibilidade.
                      </p>
                    </div>
                  </div>
                )}
                <div ref={messagesEndRef} />
              </div>
              <div className="border-t bg-card p-3">
                <form
                  onSubmit={(event) => {
                    event.preventDefault();
                    sendText();
                  }}
                  className="flex min-w-0 items-center gap-1.5 sm:gap-2"
                >
                  <label
                    className="grid h-10 w-10 shrink-0 cursor-pointer place-items-center rounded-full hover:bg-muted"
                    aria-label="Anexar arquivo"
                  >
                    <Paperclip className="h-5 w-5" />
                    <input
                      type="file"
                      accept="image/*,audio/*,.pdf"
                      className="sr-only"
                      onChange={attachFile}
                    />
                  </label>
                  <input
                    aria-label="Escreva uma mensagem"
                    value={text}
                    maxLength={4000}
                    onChange={(event) => setText(event.target.value)}
                    placeholder="Escreva uma mensagem"
                    className="min-w-0 flex-1 rounded-md border bg-background px-3 py-2.5 text-sm outline-none focus:ring-2 focus:ring-ring/20"
                  />
                  <button
                    type="button"
                    onClick={recording ? stopRecording : startRecording}
                    className={cn(
                      "grid h-10 w-10 shrink-0 place-items-center rounded-full border",
                      recording ? "border-destructive bg-destructive text-white" : "hover:bg-muted",
                    )}
                    aria-label={recording ? "Parar gravação" : "Gravar áudio"}
                  >
                    {recording ? (
                      <Square className="h-4 w-4 fill-current" />
                    ) : (
                      <Mic className="h-5 w-5" />
                    )}
                  </button>
                  <button
                    disabled={!text.trim()}
                    className="grid h-10 w-10 shrink-0 place-items-center rounded-full bg-primary text-primary-foreground disabled:opacity-50"
                    aria-label="Enviar mensagem"
                  >
                    <Send className="h-4 w-4" />
                  </button>
                </form>
                {recording && (
                  <button
                    onClick={() => {
                      cancelAudioRef.current = true;
                      stopRecording();
                    }}
                    className="mt-2 inline-flex items-center gap-1 text-xs font-bold text-destructive"
                  >
                    <Trash2 className="h-3.5 w-3.5" />
                    Cancelar gravação
                  </button>
                )}
              </div>
            </>
          ) : (
            <div className="grid flex-1 place-items-center p-6 text-center text-muted-foreground">
              <div>
                <BriefcaseBusiness className="mx-auto h-8 w-8" />
                <p className="mt-3 font-semibold">Selecione uma conversa</p>
                <p className="mt-1 text-sm">Mensagens organizadas pelos serviços associados.</p>
              </div>
            </div>
          )}
        </section>
      </div>
      {!isPro && <AdPlacement channel="mensagens" compact className="mt-4" />}
    </div>
  );
}
