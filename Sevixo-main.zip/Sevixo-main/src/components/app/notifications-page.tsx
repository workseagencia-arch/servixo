import { useEffect, useMemo, useState } from "react";
import {
  Bell,
  CheckCheck,
  CircleCheck,
  ClipboardList,
  MessageCircle,
  Trash2,
  Wallet,
} from "lucide-react";
import { Link } from "@tanstack/react-router";
import { PageTitle } from "@/components/app/ui-bits";
import { EmptyState, FilterInput, PanelTabs, WorkspaceIntro } from "@/components/app/workspace-ui";
import { Pagination } from "@/components/app/pagination";
import { normalizeSearch } from "@/lib/search";
import {
  getNotificationsForRoles,
  deleteNotification,
  markAllNotificationsReadForRoles,
  markNotificationRead,
  subscribeToNotifications,
} from "@/lib/notification-store";
import type { AccountRole } from "@/lib/auth-store";
import { cn } from "@/lib/utils";
import { AdPlacement } from "@/components/app/ad-placement";

export function NotificationsPage({ role, roles }: { role?: AccountRole; roles?: AccountRole[] }) {
  const roleKey = (roles ?? [role ?? "cliente"]).join(",");
  const visibleRoles = useMemo(() => roleKey.split(",") as AccountRole[], [roleKey]);
  const [items, setItems] = useState<ReturnType<typeof getNotificationsForRoles>>([]);
  const [filter, setFilter] = useState<"todas" | "nao-lidas">("todas");
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  useEffect(() => {
    const refresh = () => setItems(getNotificationsForRoles(visibleRoles));
    refresh();
    return subscribeToNotifications(refresh);
  }, [visibleRoles]);
  useEffect(() => setPage(1), [filter, query, roleKey]);
  const unread = items.filter((item) => !item.read).length;
  const visible = items.filter(
    (item) =>
      (filter === "todas" || !item.read) &&
      normalizeSearch(`${item.title} ${item.detail}`).includes(normalizeSearch(query.trim())),
  );
  const currentPage = Math.min(page, Math.max(1, Math.ceil(visible.length / 15)));
  return (
    <div className="servix-workspace mx-auto min-w-0 max-w-6xl">
      <PageTitle
        title="Central de notificações"
        subtitle="Acompanhe os pedidos, as conversas e as atualizações da sua conta."
      />
      <WorkspaceIntro
        title={
          unread
            ? `${unread} ${unread === 1 ? "atualização para conferir" : "atualizações para conferir"}`
            : "Sua conta, em dia."
        }
        description="Abra uma atualização para ver os detalhes. Você pode marcar como lida ou remover o que já resolveu."
      >
        <button
          type="button"
          disabled={!unread}
          onClick={() => markAllNotificationsReadForRoles(visibleRoles)}
          className="inline-flex items-center gap-2 rounded-md bg-brand px-4 py-3 text-sm font-semibold text-brand-foreground disabled:opacity-50"
        >
          <CheckCheck className="h-4 w-4" /> Marcar todas como lidas
        </button>
      </WorkspaceIntro>
      <FilterInput value={query} onChange={setQuery} label="Pesquisar notificações" />
      <PanelTabs
        value={filter}
        onChange={setFilter}
        label="Filtrar notificações"
        items={[
          { value: "todas", label: "Todas", count: items.length },
          { value: "nao-lidas", label: "Não lidas", count: unread },
        ]}
      />
      {visible.length ? (
        <div className="overflow-hidden rounded-xl border bg-card divide-y">
          {visible.slice((currentPage - 1) * 15, currentPage * 15).map((item) => {
            const Icon = /mensage|conversa|chat/i.test(`${item.title} ${item.href}`)
              ? MessageCircle
              : /ganhos|repasse|saque/i.test(`${item.title} ${item.href}`)
                ? Wallet
                : /servi|proposta|vaga/i.test(`${item.title} ${item.href}`)
                  ? ClipboardList
                  : Bell;
            return (
              <article
                key={item.id}
                className={cn(
                  "flex min-w-0 items-center gap-1 p-3 sm:gap-3 sm:p-4",
                  !item.read && "bg-secondary/30",
                )}
              >
                <Link
                  to={(item.href ?? (role === "profissional" ? "/pro" : "/perfil")) as never}
                  onClick={() => markNotificationRead(item.id)}
                  className="flex min-w-0 flex-1 items-start gap-3 rounded-lg p-1.5 hover:bg-muted/60 sm:p-2"
                >
                  <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg border border-border bg-card text-primary">
                    <Icon className="h-4 w-4" />
                  </span>
                  <span className="min-w-0 flex-1">
                    <span className="flex flex-wrap items-center gap-x-3 gap-y-1">
                      <span className="break-words text-sm font-semibold">{item.title}</span>
                      {!item.read && <span className="h-1.5 w-1.5 rounded-full bg-primary" />}
                    </span>
                    <span className="mt-1 block break-words text-xs leading-relaxed text-muted-foreground sm:text-sm">
                      {item.detail}
                    </span>
                    <span className="mt-2 block text-[11px] text-muted-foreground">
                      {item.time}
                    </span>
                  </span>
                </Link>
                <div className="flex shrink-0 flex-col gap-1 sm:flex-row">
                  {!item.read && (
                    <button
                      type="button"
                      aria-label={`Marcar como lida: ${item.title}`}
                      onClick={() => markNotificationRead(item.id)}
                      className="grid h-9 w-9 place-items-center rounded-md text-muted-foreground hover:bg-muted hover:text-primary"
                    >
                      <CircleCheck className="h-4 w-4" />
                    </button>
                  )}
                  <button
                    type="button"
                    onClick={() => deleteNotification(item.id)}
                    aria-label={`Excluir notificação: ${item.title}`}
                    className="grid h-9 w-9 place-items-center rounded-md text-muted-foreground hover:bg-destructive/10 hover:text-destructive"
                  >
                    <Trash2 className="h-4 w-4" />
                  </button>
                </div>
              </article>
            );
          })}
        </div>
      ) : (
        <EmptyState
          icon={Bell}
          title={
            query
              ? "Nenhuma atualização para esta busca"
              : filter === "nao-lidas"
                ? "Você já leu todas as notificações"
                : "Nenhuma notificação por enquanto"
          }
          description={
            query
              ? "Tente outro termo para encontrar a atualização que procura."
              : "As novidades dos seus pedidos e da sua conta aparecerão aqui."
          }
        />
      )}
      <div className="mt-5">
        <Pagination
          currentPage={currentPage}
          totalItems={visible.length}
          pageSize={15}
          onPageChange={setPage}
          label="notificações"
        />
      </div>
      {visibleRoles.includes("cliente") && (
        <AdPlacement channel="notificacoes" compact className="mt-5" />
      )}
    </div>
  );
}
