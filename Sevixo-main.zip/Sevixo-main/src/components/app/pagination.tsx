import { useEffect } from "react";
import { ChevronLeft, ChevronRight } from "lucide-react";
import { cn } from "@/lib/utils";

export function Pagination({
  currentPage,
  totalItems,
  pageSize = 10,
  onPageChange,
  label = "resultados",
}: {
  currentPage: number;
  totalItems: number;
  pageSize?: number;
  onPageChange: (page: number) => void;
  label?: string;
}) {
  const totalPages = Math.ceil(totalItems / pageSize);
  const safePage = Math.max(1, Math.min(currentPage, Math.max(1, totalPages)));
  useEffect(() => {
    if (currentPage !== safePage) onPageChange(safePage);
  }, [currentPage, safePage, onPageChange]);
  if (totalPages < 2) return null;

  const pages = Array.from({ length: totalPages }, (_, index) => index + 1).filter(
    (page) => page === 1 || page === totalPages || Math.abs(page - safePage) <= 1,
  );
  const pageItems = pages.flatMap((page, index) => {
    const previous = pages[index - 1];
    return [...(previous && page - previous > 1 ? [`ellipsis-${page}`] : []), page];
  });
  const firstItem = (safePage - 1) * pageSize + 1;
  const lastItem = Math.min(safePage * pageSize, totalItems);

  return (
    <nav
      aria-label={`Paginação de ${label}`}
      className="flex flex-col items-center justify-between gap-3 border-t pt-4 sm:flex-row"
    >
      <p className="text-xs text-muted-foreground">
        {firstItem}–{lastItem} de {totalItems} {label}
      </p>
      <div className="flex items-center gap-1">
        <button
          type="button"
          onClick={() => onPageChange(Math.max(1, safePage - 1))}
          disabled={safePage === 1}
          aria-label="Página anterior"
          className="inline-flex h-8 items-center gap-1 rounded-md border px-2 text-xs font-semibold transition hover:bg-muted disabled:pointer-events-none disabled:opacity-40 sm:h-9 sm:px-3"
        >
          <ChevronLeft className="h-4 w-4" /> <span className="hidden sm:inline">Anterior</span>
        </button>
        {pageItems.map((item) =>
          typeof item === "string" ? (
            <span key={item} aria-hidden="true" className="px-1 text-muted-foreground">
              …
            </span>
          ) : (
            <button
              key={item}
              type="button"
              onClick={() => onPageChange(item)}
              aria-label={`Página ${item}`}
              aria-current={safePage === item ? "page" : undefined}
              className={cn(
                "grid h-8 min-w-8 place-items-center rounded-md px-1.5 text-xs font-bold transition sm:h-9 sm:min-w-9 sm:px-2",
                item === safePage || item === 1 || item === totalPages ? "" : "hidden sm:grid",
                safePage === item
                  ? "bg-primary text-primary-foreground"
                  : "border hover:bg-muted",
              )}
            >
              {item}
            </button>
          ),
        )}
        <button
          type="button"
          onClick={() => onPageChange(Math.min(totalPages, safePage + 1))}
          disabled={safePage === totalPages}
          aria-label="Próxima página"
          className="inline-flex h-8 items-center gap-1 rounded-md border px-2 text-xs font-semibold transition hover:bg-muted disabled:pointer-events-none disabled:opacity-40 sm:h-9 sm:px-3"
        >
          <span className="hidden sm:inline">Próxima</span> <ChevronRight className="h-4 w-4" />
        </button>
      </div>
    </nav>
  );
}
