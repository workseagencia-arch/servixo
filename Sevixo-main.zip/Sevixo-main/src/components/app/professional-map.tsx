import { useEffect, useMemo, useRef, useState, type PointerEvent } from "react";
import { Link } from "@tanstack/react-router";
import {
  ArrowUpRight,
  BriefcaseBusiness,
  Clock,
  MapPin,
  Minus,
  Navigation,
  Plus,
  Radar,
  Star,
} from "lucide-react";
import { Avatar, Rating, Verified, portfolioImages } from "@/components/app/ui-bits";
import { HireDialog, QuoteDialog } from "@/components/app/booking-dialogs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { brl, type Professional } from "@/lib/demo-data";
import { cn } from "@/lib/utils";
import type { DeviceLocation } from "@/lib/location-store";

type GeoPoint = Pick<DeviceLocation, "latitude" | "longitude">;
type Tile = { key: string; src: string; left: number; top: number };
const tileSize = 256;
const fallbackCenter: GeoPoint = { latitude: -23.5671, longitude: -46.7012 };

function zoomForRadius(radiusKm: number) {
  if (radiusKm <= 5) return 12;
  if (radiusKm <= 10) return 11;
  if (radiusKm <= 20) return 10;
  return 9;
}

function project(point: GeoPoint, zoom: number) {
  const scale = tileSize * 2 ** zoom;
  const latitude = Math.max(-85.05112878, Math.min(85.05112878, point.latitude));
  const sin = Math.sin((latitude * Math.PI) / 180);
  return {
    x: ((point.longitude + 180) / 360) * scale,
    y: (0.5 - Math.log((1 + sin) / (1 - sin)) / (4 * Math.PI)) * scale,
  };
}

function unproject(point: { x: number; y: number }, zoom: number): GeoPoint {
  const scale = tileSize * 2 ** zoom;
  const x = ((point.x % scale) + scale) % scale;
  const y = Math.max(0, Math.min(scale, point.y));
  const longitude = (x / scale) * 360 - 180;
  const n = Math.PI - (2 * Math.PI * y) / scale;
  const latitude = (180 / Math.PI) * Math.atan(0.5 * (Math.exp(n) - Math.exp(-n)));
  return { latitude, longitude };
}

export function ProfessionalMap({
  pros,
  radiusKm,
  origin,
  onSelect,
}: {
  pros: Professional[];
  radiusKm: number;
  origin?: GeoPoint | null;
  onSelect: (pro: Professional) => void;
}) {
  const mapRef = useRef<HTMLDivElement>(null);
  const dragStart = useRef<{ x: number; y: number; center: GeoPoint } | null>(null);
  const [size, setSize] = useState({ width: 0, height: 0 });
  const [mapCenter, setMapCenter] = useState<GeoPoint>(fallbackCenter);
  const [manualZoom, setManualZoom] = useState<number | null>(null);
  const [dragging, setDragging] = useState(false);
  const searchPoint = origin ?? fallbackCenter;
  const zoom = manualZoom ?? zoomForRadius(radiusKm);
  const centerPixel = project(mapCenter, zoom);
  const searchPixel = project(searchPoint, zoom);
  const searchPosition = {
    x: searchPixel.x - centerPixel.x + size.width / 2,
    y: searchPixel.y - centerPixel.y + size.height / 2,
  };
  const metersPerPixel =
    (156543.03392 * Math.cos((searchPoint.latitude * Math.PI) / 180)) / 2 ** zoom;
  const circleDiameter = (radiusKm * 2000) / metersPerPixel;

  useEffect(() => setMapCenter(origin ?? fallbackCenter), [origin?.latitude, origin?.longitude]);

  useEffect(() => {
    const element = mapRef.current;
    if (!element) return;
    const observer = new ResizeObserver((entries) => {
      const entry = entries[0];
      if (entry) setSize({ width: entry.contentRect.width, height: entry.contentRect.height });
    });
    observer.observe(element);
    return () => observer.disconnect();
  }, []);

  const tiles = useMemo<Tile[]>(() => {
    if (!size.width || !size.height) return [];
    const count = 2 ** zoom;
    const firstX = Math.floor((centerPixel.x - size.width / 2) / tileSize);
    const lastX = Math.floor((centerPixel.x + size.width / 2) / tileSize);
    const firstY = Math.floor((centerPixel.y - size.height / 2) / tileSize);
    const lastY = Math.floor((centerPixel.y + size.height / 2) / tileSize);
    const result: Tile[] = [];
    for (let tileY = firstY; tileY <= lastY; tileY += 1) {
      if (tileY < 0 || tileY >= count) continue;
      for (let unwrappedX = firstX; unwrappedX <= lastX; unwrappedX += 1) {
        const tileX = ((unwrappedX % count) + count) % count;
        result.push({
          key: `${zoom}/${unwrappedX}/${tileY}`,
          src: `https://tile.openstreetmap.org/${zoom}/${tileX}/${tileY}.png`,
          left: unwrappedX * tileSize - centerPixel.x + size.width / 2,
          top: tileY * tileSize - centerPixel.y + size.height / 2,
        });
      }
    }
    return result;
  }, [centerPixel.x, centerPixel.y, size.height, size.width, zoom]);

  const markerPositions = useMemo(
    () =>
      pros.flatMap((pro) => {
        if (pro.latitude === undefined || pro.longitude === undefined) return [];
        const point = project({ latitude: pro.latitude, longitude: pro.longitude }, zoom);
        return [
          {
            pro,
            left: point.x - centerPixel.x + size.width / 2,
            top: point.y - centerPixel.y + size.height / 2,
          },
        ];
      }),
    [centerPixel.x, centerPixel.y, pros, size.height, size.width, zoom],
  );

  const changeZoom = (amount: number) => setManualZoom(Math.max(3, Math.min(19, zoom + amount)));
  const startDrag = (event: PointerEvent<HTMLDivElement>) => {
    if ((event.target as HTMLElement).closest?.("button, a")) return;
    dragStart.current = { x: event.clientX, y: event.clientY, center: mapCenter };
    mapRef.current?.setPointerCapture(event.pointerId);
    setDragging(true);
  };
  const moveDrag = (event: PointerEvent<HTMLDivElement>) => {
    if (!dragStart.current) return;
    const startPixel = project(dragStart.current.center, zoom);
    setMapCenter(
      unproject(
        {
          x: startPixel.x - (event.clientX - dragStart.current.x),
          y: startPixel.y - (event.clientY - dragStart.current.y),
        },
        zoom,
      ),
    );
  };
  const stopDrag = () => {
    dragStart.current = null;
    setDragging(false);
  };

  return (
    <div
      ref={mapRef}
      className={cn(
        "relative isolate h-[clamp(18rem,38vw,25rem)] min-h-[18rem] touch-none overflow-hidden rounded-xl border bg-[#e9ece5] dark:bg-[#14201d]",
        dragging ? "cursor-grabbing" : "cursor-grab",
      )}
      aria-label="Mapa interativo de profissionais em São Paulo"
      onPointerDown={startDrag}
      onPointerMove={moveDrag}
      onPointerUp={stopDrag}
      onPointerCancel={stopDrag}
      onWheel={(event) => {
        event.preventDefault();
        changeZoom(event.deltaY < 0 ? 1 : -1);
      }}
    >
      <div className="servix-map-tiles absolute inset-0 overflow-hidden" aria-hidden="true">
        {tiles.map((tile) => (
          <img
            key={tile.key}
            src={tile.src}
            alt=""
            draggable={false}
            className="absolute h-64 w-64 max-w-none select-none"
            style={{ left: tile.left, top: tile.top }}
          />
        ))}
      </div>

      <div
        className="pointer-events-none absolute z-[1] aspect-square rounded-full border-2 border-primary/60 bg-primary/10 shadow-[0_0_0_1px_rgba(255,255,255,.5)] transition-[width,height] duration-300"
        style={{
          left: searchPosition.x,
          top: searchPosition.y,
          width: `${circleDiameter}px`,
          height: `${circleDiameter}px`,
          transform: "translate(-50%, -50%)",
        }}
      />
      <div
        className="absolute z-10 grid h-10 w-10 place-items-center rounded-full border-[3px] border-white bg-primary text-primary-foreground shadow-lg"
        style={{
          left: searchPosition.x,
          top: searchPosition.y,
          transform: "translate(-50%, -50%)",
        }}
        title={origin ? "Sua localização" : "Defina sua localização"}
      >
        <Navigation className="h-4 w-4 fill-current" />
      </div>
      <div
        className="absolute z-[1] h-4 w-4 rounded-full bg-primary/20 ring-4 ring-white/70"
        style={{
          left: searchPosition.x,
          top: searchPosition.y,
          transform: "translate(-50%, -50%)",
        }}
      />

      {markerPositions.map(({ pro, left, top }) => (
        <button
          key={pro.id}
          type="button"
          onClick={() => onSelect(pro)}
          className="group absolute z-20 -translate-x-1/2 -translate-y-1/2 rounded-full outline-none transition hover:z-30 focus-visible:ring-4 focus-visible:ring-primary/30"
          style={{ left, top }}
          aria-label={`Ver ${pro.name}, ${pro.role}, ${pro.distanceKm.toString().replace(".", ",")} quilômetros`}
        >
          <span className="flex items-center gap-1.5 rounded-full border border-white bg-card px-2 py-1 shadow-md transition group-hover:-translate-y-0.5 group-hover:shadow-lg">
            <span
              className={cn(
                "h-2.5 w-2.5 rounded-full ring-2 ring-white",
                pro.online ? "bg-emerald-500" : "bg-amber-400",
              )}
            />
            <span className="max-w-20 truncate text-[10px] font-extrabold">
              {pro.name.split(" ")[0]}
            </span>
            <span className="text-[9px] font-bold text-muted-foreground">
              {pro.distanceKm.toString().replace(".", ",")} km
            </span>
          </span>
        </button>
      ))}

      <div className="pointer-events-none absolute left-3 top-3 z-30 rounded-xl border bg-card/95 px-3 py-2 shadow-sm backdrop-blur">
        <p className="flex items-center gap-1.5 text-xs font-bold">
          <MapPin className="h-3.5 w-3.5 text-primary" />
          {origin ? "Sua localização" : "Localização não definida"}
        </p>
        <p className="mt-0.5 text-[10px] text-muted-foreground">Raio geográfico: {radiusKm} km</p>
      </div>
      <div className="absolute right-3 top-3 z-30 grid overflow-hidden rounded-xl border bg-card/95 shadow-sm backdrop-blur">
        <button
          type="button"
          aria-label="Aproximar mapa"
          onClick={() => changeZoom(1)}
          className="grid h-10 w-10 place-items-center border-b hover:bg-muted"
        >
          <Plus className="h-4 w-4" />
        </button>
        <button
          type="button"
          aria-label="Afastar mapa"
          onClick={() => changeZoom(-1)}
          className="grid h-10 w-10 place-items-center hover:bg-muted"
        >
          <Minus className="h-4 w-4" />
        </button>
      </div>
      <div className="absolute bottom-2 right-2 z-30 rounded-lg border bg-card/95 px-2 py-1 text-[9px] leading-tight text-muted-foreground shadow-sm">
        <p>Mapa ilustrativo · localização não definida</p>
        <a
          className="pointer-events-auto font-semibold underline-offset-2 hover:underline"
          href="https://www.openstreetmap.org/copyright"
          target="_blank"
          rel="noreferrer"
        >
          © OpenStreetMap contributors
        </a>
      </div>
    </div>
  );
}

export function MapProfessionalSheet({
  pro,
  open,
  onOpenChange,
}: {
  pro: Professional | null;
  open: boolean;
  onOpenChange: (open: boolean) => void;
}) {
  const [hire, setHire] = useState<{ name: string; price: number; duration: string } | null>(null);
  const [quote, setQuote] = useState(false);
  const pricedService = pro?.services.find((service) => service.price !== null);

  return (
    <>
      <Dialog open={open} onOpenChange={onOpenChange}>
        <DialogContent className="max-h-[92dvh] w-[calc(100vw-1.25rem)] max-w-3xl overflow-y-auto rounded-3xl p-0 sm:w-[calc(100vw-3rem)]">
          {pro && (
            <>
              <div className="bg-hero min-h-24 px-5 pt-5 text-white sm:px-7">
                <p className="inline-flex items-center gap-1.5 rounded-full bg-white/10 px-2.5 py-1 text-xs font-bold">
                  <MapPin className="h-3.5 w-3.5 text-brand" />
                  {pro.distanceKm.toString().replace(".", ",")} km de você
                </p>
              </div>
              <div className="px-5 pb-5 sm:px-7 sm:pb-7">
                <div className="-mt-9 flex items-end justify-between gap-3">
                  <Avatar pro={pro} size="lg" className="rounded-full ring-4 ring-card" />
                  <span
                    className={cn(
                      "mb-1 inline-flex items-center gap-1.5 rounded-full px-2.5 py-1 text-xs font-bold",
                      pro.online
                        ? "bg-accent text-accent-foreground"
                        : "bg-muted text-muted-foreground",
                    )}
                  >
                    <span
                      className={cn(
                        "h-1.5 w-1.5 rounded-full",
                        pro.online ? "bg-emerald-500" : "bg-amber-400",
                      )}
                    />
                    {pro.availability}
                  </span>
                </div>
                <DialogHeader className="mt-3 space-y-1 text-left">
                  <div className="flex flex-wrap items-center gap-2">
                    <DialogTitle className="font-display text-2xl">{pro.name}</DialogTitle>
                    {pro.verified && <Verified />}
                  </div>
                  <DialogDescription className="text-sm">
                    {pro.role} · {pro.neighborhood}
                  </DialogDescription>
                </DialogHeader>

                <div className="mt-4 grid grid-cols-3 divide-x rounded-2xl bg-muted py-3 text-center">
                  <div>
                    <Rating value={pro.rating} className="justify-center text-sm" />
                    <p className="mt-0.5 text-[10px] text-muted-foreground">
                      {pro.reviews} avaliações
                    </p>
                  </div>
                  <div>
                    <p className="font-display font-bold">{pro.jobs}</p>
                    <p className="text-[10px] text-muted-foreground">serviços concluídos</p>
                  </div>
                  <div>
                    <p className="font-display font-bold">{pro.years} anos</p>
                    <p className="text-[10px] text-muted-foreground">de experiência</p>
                  </div>
                </div>

                <div className="mt-5 grid gap-2 text-sm sm:grid-cols-3">
                  <p className="flex items-center gap-2 text-muted-foreground">
                    <MapPin className="h-4 w-4 shrink-0 text-primary" />
                    Atende em {pro.neighborhood}
                  </p>
                  <p className="flex items-center gap-2 text-muted-foreground">
                    <Radar className="h-4 w-4 shrink-0 text-primary" />
                    Cobertura de até {pro.radiusKm} km
                  </p>
                  <p className="flex items-center gap-2 text-muted-foreground">
                    <Clock className="h-4 w-4 shrink-0 text-primary" />
                    {pro.online ? "Pode atender agora" : pro.availability}
                  </p>
                </div>

                <section className="mt-5 border-t pt-4">
                  <h3 className="font-display font-bold">Sobre o profissional</h3>
                  <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{pro.bio}</p>
                </section>

                <section className="mt-5 border-t pt-4">
                  <div className="mb-2 flex items-center justify-between">
                    <h3 className="font-display font-bold">Serviços anunciados</h3>
                    <span className="text-xs text-muted-foreground">
                      a partir de {brl(pro.priceFrom)}
                    </span>
                  </div>
                  <div className="divide-y">
                    {pro.services.map((service) => (
                      <div key={service.name} className="flex items-center gap-3 py-3">
                        <span className="grid h-8 w-8 shrink-0 place-items-center rounded-xl bg-accent text-accent-foreground">
                          <BriefcaseBusiness className="h-4 w-4" />
                        </span>
                        <div className="min-w-0 flex-1">
                          <p className="text-sm font-semibold">{service.name}</p>
                          <p className="text-xs text-muted-foreground">{service.duration}</p>
                        </div>
                        <div className="text-right">
                          <p className="text-sm font-bold">
                            {service.price === null ? "Sob consulta" : brl(service.price)}
                          </p>
                          <button
                            onClick={() =>
                              service.price === null
                                ? setQuote(true)
                                : setHire({
                                    name: service.name,
                                    price: service.price!,
                                    duration: service.duration,
                                  })
                            }
                            className="text-xs font-bold text-primary hover:underline"
                          >
                            {service.price === null ? "Pedir orçamento" : "Contratar"}
                          </button>
                        </div>
                      </div>
                    ))}
                  </div>
                </section>

                {pro.portfolio.length > 0 && (
                  <section className="mt-5 border-t pt-4">
                    <h3 className="font-display mb-3 font-bold">Trabalhos recentes</h3>
                    <div className="grid grid-cols-3 gap-2">
                      {pro.portfolio.map((imageIndex, index) => (
                        <img
                          key={`${imageIndex}-${index}`}
                          src={portfolioImages[imageIndex]}
                          alt={`Trabalho de ${pro.name}`}
                          className="aspect-square w-full rounded-xl object-cover"
                          loading="lazy"
                        />
                      ))}
                    </div>
                  </section>
                )}

                <section className="mt-5 border-t pt-4">
                  <h3 className="font-display mb-3 flex items-center gap-2 font-bold">
                    <Star className="h-4 w-4 fill-status-warning text-status-warning" />
                    Avaliações de clientes
                  </h3>
                  <div className="space-y-3">
                    {pro.reviewList.slice(0, 2).map((review) => (
                      <div
                        key={`${review.author}-${review.date}`}
                        className="rounded-xl bg-muted p-3"
                      >
                        <div className="flex items-center justify-between gap-2">
                          <span className="text-sm font-semibold">{review.author}</span>
                          <span className="text-[10px] text-muted-foreground">{review.date}</span>
                        </div>
                        <p className="mt-1 text-xs text-status-warning">
                          {"★".repeat(review.rating)}
                          <span className="text-border">
                            {"★".repeat(5 - review.rating)}
                          </span> · {review.service}
                        </p>
                        <p className="mt-1.5 text-xs leading-relaxed text-muted-foreground">
                          {review.text}
                        </p>
                      </div>
                    ))}
                  </div>
                </section>

                <div className="sticky bottom-0 mt-5 flex flex-wrap gap-2 border-t bg-background/95 py-3 backdrop-blur sm:flex-nowrap">
                  <button
                    disabled={!pricedService}
                    onClick={() =>
                      pricedService?.price !== null &&
                      pricedService &&
                      setHire({
                        name: pricedService.name,
                        price: pricedService.price!,
                        duration: pricedService.duration,
                      })
                    }
                    className="min-w-[8rem] flex-1 rounded-full bg-primary py-3 text-sm font-bold text-primary-foreground disabled:opacity-50"
                  >
                    Contratar
                  </button>
                  <button
                    onClick={() => setQuote(true)}
                    className="min-w-[8rem] flex-1 rounded-full border py-3 text-sm font-bold hover:bg-muted"
                  >
                    Pedir orçamento
                  </button>
                  <Link
                    to="/profissional/$id"
                    params={{ id: pro.id }}
                    className="inline-flex min-w-full items-center justify-center gap-2 rounded-full border px-4 py-3 text-sm font-bold hover:bg-muted sm:min-w-0"
                  >
                    <span>Ver perfil completo</span>
                    <ArrowUpRight className="h-4 w-4" />
                  </Link>
                </div>
              </div>
            </>
          )}
        </DialogContent>
      </Dialog>
      {pro && (
        <>
          <HireDialog
            pro={pro}
            service={hire}
            open={!!hire}
            onOpenChange={(isOpen) => !isOpen && setHire(null)}
          />
          <QuoteDialog pro={pro} open={quote} onOpenChange={setQuote} />
        </>
      )}
    </>
  );
}
