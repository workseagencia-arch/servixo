import {
  Hammer,
  BrickWall,
  Zap,
  Droplets,
  Paintbrush,
  Drill,
  Snowflake,
  Sparkles,
  Sprout,
  KeyRound,
  Truck,
  Wrench,
  Tv,
  Home,
  Plus,
  Star,
  BadgeCheck,
  MapPin,
  Clock,
  ImageOff,
  type LucideIcon,
} from "lucide-react";
import { Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { cn } from "@/lib/utils";
import { brl, categoryImageIndexes, type CategorySlug, type Professional } from "@/lib/demo-data";
import port1 from "@/assets/port-1.jpg";
import port2 from "@/assets/port-2.jpg";
import port3 from "@/assets/port-3.jpg";
import categorySprite from "@/assets/service-categories-sprite.jpg";

export const portfolioImages = [port1, port2, port3];

const icons: Record<string, LucideIcon> = {
  montador: Hammer,
  pedreiro: BrickWall,
  eletricista: Zap,
  encanador: Droplets,
  pintor: Paintbrush,
  marceneiro: Drill,
  "ar-condicionado": Snowflake,
  diarista: Sparkles,
  jardineiro: Sprout,
  chaveiro: KeyRound,
  frete: Truck,
  "marido-de-aluguel": Wrench,
  instalacao: Tv,
  reformas: Home,
  outros: Plus,
};

export function CategoryIcon({ slug, className }: { slug: string; className?: string }) {
  const Icon = icons[slug] ?? Plus;
  return <Icon className={className} />;
}

export function CategoryCover({ slug, className }: { slug: CategorySlug; className?: string }) {
  const position = categoryImageIndexes[slug];
  const x = position % 4;
  const y = Math.floor(position / 4);
  return (
    <span
      role="img"
      aria-label={`Imagem da categoria ${slug}`}
      className={cn("block bg-muted bg-no-repeat", className)}
      style={{
        backgroundImage: `url(${categorySprite})`,
        backgroundPosition: `${(x / 3) * 100}% ${(y / 3) * 100}%`,
        backgroundSize: "400% 400%",
      }}
    />
  );
}

export function ResilientImage({
  src,
  alt,
  className,
  fallbackLabel = "Imagem indisponível",
  loading = "lazy",
}: {
  src: string;
  alt: string;
  className?: string;
  fallbackLabel?: string;
  loading?: "eager" | "lazy";
}) {
  const [failed, setFailed] = useState(!src);

  useEffect(() => setFailed(!src), [src]);

  if (failed) {
    return (
      <span
        role="img"
        aria-label={alt ? `${alt} — ${fallbackLabel}` : fallbackLabel}
        className={cn("grid place-items-center bg-muted p-3 text-muted-foreground", className)}
      >
        <span className="inline-flex items-center gap-2 text-xs font-semibold">
          <ImageOff className="h-4 w-4 shrink-0" />
          <span>{fallbackLabel}</span>
        </span>
      </span>
    );
  }

  return (
    <img
      src={src}
      alt={alt}
      loading={loading}
      decoding="async"
      onError={() => setFailed(true)}
      className={className}
    />
  );
}

export function Avatar({
  pro,
  size = "md",
  className,
}: {
  pro: Pick<Professional, "initials" | "hue" | "online"> & Partial<Pick<Professional, "photoUrl">>;
  size?: "sm" | "md" | "lg" | "xl";
  className?: string;
}) {
  const [photoFailed, setPhotoFailed] = useState(false);
  const s = {
    sm: "h-10 w-10 text-sm",
    md: "h-14 w-14 text-base",
    lg: "h-20 w-20 text-xl",
    xl: "h-28 w-28 text-3xl",
  }[size];
  useEffect(() => setPhotoFailed(false), [pro.photoUrl]);
  return (
    <div className={cn("relative shrink-0", className)}>
      <div
        className={cn(
          "grid place-items-center rounded-full bg-primary font-display font-bold text-primary-foreground",
          s,
        )}
      >
        {pro.photoUrl && !photoFailed ? (
          <img
            src={pro.photoUrl}
            alt=""
            onError={() => setPhotoFailed(true)}
            className={cn("rounded-full object-cover", s)}
          />
        ) : (
          pro.initials
        )}
      </div>
      {pro.online && (
        <span className="absolute bottom-0.5 right-0.5 h-3.5 w-3.5 rounded-full border-2 border-card bg-status-success" />
      )}
    </div>
  );
}

export function Rating({
  value,
  count,
  className,
}: {
  value: number;
  count?: number;
  className?: string;
}) {
  return (
    <span className={cn("inline-flex items-center gap-1 text-sm font-semibold", className)}>
      <Star className="h-4 w-4 fill-status-warning text-status-warning" />
      {value.toFixed(1).replace(".", ",")}
      {count !== undefined && <span className="font-normal text-muted-foreground">({count})</span>}
    </span>
  );
}

export function Verified({ className }: { className?: string }) {
  return (
    <span
      className={cn(
        "inline-flex items-center gap-1 rounded-full bg-accent px-2 py-0.5 text-[11px] font-bold text-accent-foreground",
        className,
      )}
    >
      <BadgeCheck className="h-3.5 w-3.5" /> Verificado
    </span>
  );
}

export function ProCard({ pro, showEta }: { pro: Professional; showEta?: boolean }) {
  return (
    <Link
      to="/profissional/$id"
      params={{ id: pro.id }}
      className="group flex min-w-0 flex-col gap-4 rounded-xl border border-border bg-card p-5 transition-[border-color,box-shadow] hover:border-primary/35 hover:shadow-md sm:p-6"
    >
      <div className="flex items-start gap-3">
        <Avatar pro={pro} className="[&>div]:!rounded-full [&_img]:!rounded-full" />
        <div className="min-w-0 flex-1">
          <div className="flex flex-wrap items-center gap-1.5">
            <h3 className="truncate font-display text-base font-bold">{pro.name}</h3>
            {pro.verified && (
              <BadgeCheck className="h-4 w-4 text-status-success" aria-label="Verificado" />
            )}
          </div>
          <p className="mt-1 break-words text-sm text-muted-foreground">{pro.role}</p>
          <div className="mt-2 flex flex-wrap items-center gap-3">
            {pro.reviews > 0 ? (
              <Rating value={pro.rating} count={pro.reviews} className="text-xs" />
            ) : (
              <span className="text-xs text-muted-foreground">Ainda sem avaliações</span>
            )}
            {pro.jobs > 0 && (
              <span className="text-xs text-muted-foreground">{pro.jobs} serviços</span>
            )}
          </div>
        </div>
      </div>
      {pro.bio && (
        <p className="line-clamp-2 break-words text-sm leading-relaxed text-muted-foreground">
          {pro.bio}
        </p>
      )}
      <div className="flex flex-wrap gap-2 text-xs font-semibold">
        <span className="inline-flex items-center gap-1 rounded-md bg-muted px-2.5 py-1">
          <MapPin className="h-3.5 w-3.5" />
          {Number.isFinite(pro.distanceKm)
            ? `${pro.distanceKm.toLocaleString("pt-BR")} km`
            : pro.neighborhood || "Região a combinar"}
        </span>
        {showEta && pro.etaMin > 0 ? (
          <span className="inline-flex items-center gap-1 rounded-md bg-brand px-2.5 py-1 text-brand-foreground">
            <Clock className="h-3.5 w-3.5" />
            chega em ~{pro.etaMin} min
          </span>
        ) : (
          <span
            className={cn(
              "inline-flex items-center gap-1 rounded-md px-2.5 py-1",
              pro.online ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground",
            )}
          >
            <span
              className={cn(
                "h-1.5 w-1.5 rounded-full",
                pro.online ? "bg-status-success" : "bg-muted-foreground",
              )}
            />
            {pro.online ? "Disponível para contato" : "Consulte a disponibilidade"}
          </span>
        )}
      </div>
      {pro.services.length > 0 && (
        <p className="line-clamp-2 text-xs leading-relaxed text-muted-foreground">
          <span className="font-semibold text-foreground">Serviços: </span>
          {pro.services.map((service) => service.name).join(" · ")}
        </p>
      )}
      <div className="mt-auto flex items-end justify-between border-t pt-3">
        <div>
          <p className="text-[11px] text-muted-foreground">
            {pro.priceFrom > 0 ? "A partir de" : "Valor"}
          </p>
          <p className="font-display text-lg font-bold">
            {pro.priceFrom > 0 ? brl(pro.priceFrom) : "Sob consulta"}
          </p>
        </div>
        <span className="rounded-md bg-primary px-4 py-2 text-sm font-bold text-primary-foreground transition group-hover:bg-primary/90">
          Ver perfil
        </span>
      </div>
    </Link>
  );
}

export function PageTitle({
  eyebrow,
  title,
  subtitle,
  action,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  action?: React.ReactNode;
}) {
  return (
    <header className="mb-6 flex min-w-0 flex-col gap-4 lg:flex-row lg:items-end lg:justify-between lg:gap-6">
      <div className="min-w-0 flex-1">
        {eyebrow && <p className="mb-2 text-xs font-semibold text-muted-foreground">{eyebrow}</p>}
        <h1 className="break-words font-display text-2xl font-bold leading-tight tracking-tight sm:text-3xl">
          {title}
        </h1>
        {subtitle && (
          <p className="mt-2 max-w-2xl break-words text-sm leading-relaxed text-muted-foreground">
            {subtitle}
          </p>
        )}
      </div>
      {action && <div className="max-w-full lg:max-w-[48%]">{action}</div>}
    </header>
  );
}

const statusTone: Record<string, string> = {
  Solicitado: "bg-muted text-muted-foreground",
  Confirmado: "bg-secondary text-secondary-foreground",
  "A caminho": "bg-brand text-brand-foreground",
  "Em execução": "bg-primary text-primary-foreground",
  Concluído: "bg-accent text-accent-foreground",
  "Aguardando propostas": "bg-status-warning/20 text-status-warning-foreground",
  Aceito: "bg-accent text-accent-foreground",
};
export function StatusPill({ status }: { status: string }) {
  return (
    <span
      className={cn(
        "rounded-full px-2.5 py-1 text-[11px] font-bold",
        statusTone[status] ?? "bg-muted",
      )}
    >
      {status}
    </span>
  );
}
