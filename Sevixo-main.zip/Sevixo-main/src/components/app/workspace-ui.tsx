import type { ReactNode } from "react";
import { Search, X, type LucideIcon } from "lucide-react";
import { cn } from "@/lib/utils";

export const actionClass =
  "inline-flex min-h-10 items-center justify-center gap-2 rounded-md bg-primary px-4 py-2.5 text-sm font-semibold text-primary-foreground transition-colors hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50";
export const secondaryActionClass =
  "inline-flex min-h-10 items-center justify-center gap-2 rounded-md border border-border bg-card px-4 py-2.5 text-sm font-semibold transition-colors hover:border-primary/30 hover:bg-muted/50";

export function WorkspaceIntro({
  title,
  description,
  children,
}: {
  title: string;
  description: string;
  children?: ReactNode;
}) {
  return (
    <section className="mb-6 grid min-w-0 gap-5 rounded-xl bg-primary p-5 text-primary-foreground sm:p-7 lg:grid-cols-[minmax(0,1fr)_auto] lg:items-center">
      <div className="min-w-0">
        <h2 className="max-w-2xl text-xl font-bold tracking-tight sm:text-2xl">{title}</h2>
        <p className="mt-2 max-w-2xl text-sm leading-relaxed text-primary-foreground/75">
          {description}
        </p>
      </div>
      {children && <div className="flex min-w-0 flex-wrap items-center gap-2">{children}</div>}
    </section>
  );
}

export function MetricCard({
  label,
  value,
  note,
  icon: Icon,
  emphasis = false,
}: {
  label: string;
  value: ReactNode;
  note?: string;
  icon?: LucideIcon;
  emphasis?: boolean;
}) {
  return (
    <div
      className={cn(
        "min-w-0 rounded-xl border border-border bg-card p-4 sm:p-5",
        emphasis && "border-primary/20 bg-secondary/50",
      )}
    >
      <div className="flex items-start justify-between gap-3">
        <p className="text-xs font-semibold text-muted-foreground">{label}</p>
        {Icon && <Icon className="h-4 w-4 shrink-0 text-primary" />}
      </div>
      <p className="mt-3 break-words text-2xl font-bold tracking-tight sm:text-3xl">{value}</p>
      {note && <p className="mt-2 text-xs leading-relaxed text-muted-foreground">{note}</p>}
    </div>
  );
}

export function PanelTabs<T extends string>({
  value,
  onChange,
  items,
  label,
}: {
  value: T;
  onChange: (value: T) => void;
  items: { value: T; label: string; count?: number }[];
  label: string;
}) {
  return (
    <div
      aria-label={label}
      className="workspace-tabs mb-5 flex min-w-0 max-w-full gap-1 overflow-x-auto border-b border-border"
    >
      {items.map((item) => (
        <button
          key={item.value}
          type="button"
          aria-pressed={value === item.value}
          onClick={() => onChange(item.value)}
          className={cn(
            "inline-flex shrink-0 items-center gap-2 border-b-2 px-3 py-3 text-sm font-semibold transition-colors sm:px-4",
            value === item.value
              ? "border-primary text-primary"
              : "border-transparent text-muted-foreground hover:border-border hover:text-foreground",
          )}
        >
          {item.label}
          {item.count !== undefined && (
            <span className="rounded-md bg-muted px-1.5 py-0.5 text-[10px] text-muted-foreground">
              {item.count}
            </span>
          )}
        </button>
      ))}
    </div>
  );
}

export function FilterInput({
  value,
  onChange,
  label,
  placeholder = label,
}: {
  value: string;
  onChange: (value: string) => void;
  label: string;
  placeholder?: string;
}) {
  return (
    <div className="mb-5 flex min-w-0 items-center gap-3 rounded-lg border border-border bg-card px-4 focus-within:border-primary/50 focus-within:ring-2 focus-within:ring-primary/10">
      <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
      <input
        type="search"
        aria-label={label}
        value={value}
        onChange={(event) => onChange(event.target.value)}
        placeholder={placeholder}
        className="min-w-0 flex-1 bg-transparent py-3.5 text-sm outline-none"
      />
      {value && (
        <button
          type="button"
          onClick={() => onChange("")}
          aria-label={`Limpar ${label.toLocaleLowerCase("pt-BR")}`}
          className="grid h-8 w-8 shrink-0 place-items-center rounded-md hover:bg-muted"
        >
          <X className="h-4 w-4" />
        </button>
      )}
    </div>
  );
}

export function EmptyState({
  icon: Icon,
  title,
  description,
  children,
}: {
  icon: LucideIcon;
  title: string;
  description: string;
  children?: ReactNode;
}) {
  return (
    <div className="flex min-h-64 min-w-0 flex-col items-center justify-center rounded-xl border border-border bg-card px-5 py-10 text-center sm:px-8">
      <span className="mb-4 grid h-12 w-12 place-items-center rounded-xl border border-primary/10 bg-secondary/50 text-primary">
        <Icon className="h-5 w-5" />
      </span>
      <h3 className="max-w-lg text-lg font-bold tracking-tight">{title}</h3>
      <p className="mt-2 max-w-lg text-sm leading-relaxed text-muted-foreground">{description}</p>
      {children && <div className="mt-5 flex flex-wrap justify-center gap-2">{children}</div>}
    </div>
  );
}
