import { type AdCampaign, type AdChannel } from "@/lib/demo-data";

const storageKey = "servix.ad-campaigns";
const changeEvent = "servix:ad-campaigns-change";

export function readAdCampaigns(): AdCampaign[] {
  if (typeof window === "undefined") return [];
  try {
    const saved = window.localStorage.getItem(storageKey);
    if (!saved) return [];
    const campaigns = JSON.parse(saved) as AdCampaign[];
    return Array.isArray(campaigns) ? campaigns.filter((campaign) => !campaign.id.startsWith("demo-")) : [];
  } catch {
    return [];
  }
}

export function saveAdCampaigns(campaigns: AdCampaign[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(storageKey, JSON.stringify(campaigns));
  window.dispatchEvent(new Event(changeEvent));
}

export function subscribeToAdCampaigns(listener: () => void) {
  if (typeof window === "undefined") return () => undefined;
  window.addEventListener(changeEvent, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(changeEvent, listener);
    window.removeEventListener("storage", listener);
  };
}

export function updateAdCampaign(id: string, update: Partial<AdCampaign>) {
  const campaigns = readAdCampaigns();
  if (!campaigns.some((campaign) => campaign.id === id)) return false;
  saveAdCampaigns(campaigns.map((campaign) => campaign.id === id ? { ...campaign, ...update } : campaign));
  return true;
}

export function recordAdImpression(id: string) {
  const campaigns = readAdCampaigns();
  if (!campaigns.some((campaign) => campaign.id === id)) return;
  saveAdCampaigns(campaigns.map((campaign) => campaign.id === id ? { ...campaign, impressions: campaign.impressions + 1 } : campaign));
}

export function recordAdClick(id: string) {
  const campaigns = readAdCampaigns();
  if (!campaigns.some((campaign) => campaign.id === id)) return;
  saveAdCampaigns(campaigns.map((campaign) => campaign.id === id ? { ...campaign, clicks: campaign.clicks + 1 } : campaign));
}

export function addAdCampaign(campaign: Omit<AdCampaign, "id" | "createdAt" | "impressions" | "clicks">) {
  const campaigns = readAdCampaigns();
  const createdAt = new Date().toISOString();
  const next: AdCampaign = {
    ...campaign,
    id: `ad-${Date.now()}`,
    createdAt,
    impressions: 0,
    clicks: 0,
  };
  saveAdCampaigns([next, ...campaigns]);
  return next;
}

export function isCampaignDeliverable(campaign: AdCampaign, now = Date.now()) {
  return campaign.status === "ativa"
    && campaign.payment === "confirmado"
    && new Date(campaign.startsAt).getTime() <= now
    && new Date(campaign.endsAt).getTime() >= now;
}

export function campaignTargetsChannel(campaign: AdCampaign, channel: AdChannel) {
  // Old locally saved campaigns predate channel targeting. Keep them visible in
  // the broadest customer placements until their owner edits the campaign.
  const channels = campaign.channels ?? (campaign.advertiserType === "empresa"
    ? ["inicio", "busca", "servicos", "profissionais", "vagas", "preco_fechado", "mensagens", "perfil", "notificacoes"]
    : ["inicio", "busca", "servicos", "profissionais", "vagas", "preco_fechado"]);
  return channels.includes(channel);
}
