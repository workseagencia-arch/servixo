export type AccountRole = "cliente" | "profissional" | "moderador";

export type AuthSession = {
  role: AccountRole;
  name: string;
  email: string;
  professionalEnabled?: boolean;
};

export const hasProfessionalAccess = (session: AuthSession | null | undefined) =>
  session?.role === "profissional" || session?.professionalEnabled === true;

const storageKey = "servix.session";
const changeEvent = "servix:session-change";

export function readSession(): AuthSession | null {
  if (typeof window === "undefined") return null;
  try {
    const raw = window.localStorage.getItem(storageKey);
    if (!raw) return null;
    const value = JSON.parse(raw) as Partial<AuthSession>;
    if ((value.role !== "cliente" && value.role !== "profissional" && value.role !== "moderador") || !value.name || !value.email) return null;
    return { ...value, professionalEnabled: value.professionalEnabled === true || value.role === "profissional" } as AuthSession;
  } catch {
    return null;
  }
}

export function saveSession(session: AuthSession) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(storageKey, JSON.stringify(session));
  window.dispatchEvent(new Event(changeEvent));
}

export function clearSession() {
  if (typeof window === "undefined") return;
  window.localStorage.removeItem(storageKey);
  window.dispatchEvent(new Event(changeEvent));
}

export function subscribeToSession(listener: () => void) {
  if (typeof window === "undefined") return () => undefined;
  window.addEventListener(changeEvent, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(changeEvent, listener);
    window.removeEventListener("storage", listener);
  };
}
