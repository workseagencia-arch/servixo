const maxUploadBytes = 8 * 1024 * 1024;
const maxStoredBytes = 240 * 1024;

function loadImage(file: File) {
  return new Promise<{ image: HTMLImageElement; objectUrl: string }>((resolve, reject) => {
    const objectUrl = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => resolve({ image, objectUrl });
    image.onerror = () => {
      URL.revokeObjectURL(objectUrl);
      reject(new Error("Não foi possível abrir essa imagem."));
    };
    image.src = objectUrl;
  });
}

function canvasToBlob(canvas: HTMLCanvasElement, quality: number) {
  return new Promise<Blob>((resolve, reject) => {
    canvas.toBlob(
      (blob) => (blob ? resolve(blob) : reject(new Error("Não foi possível preparar essa imagem."))),
      "image/webp",
      quality,
    );
  });
}

function blobToDataUrl(blob: Blob) {
  return new Promise<string>((resolve, reject) => {
    const reader = new FileReader();
    reader.onload = () => resolve(String(reader.result));
    reader.onerror = () => reject(new Error("Não foi possível carregar a imagem preparada."));
    reader.readAsDataURL(blob);
  });
}

export async function prepareCampaignImage(file: File) {
  if (!/^image\/(jpeg|png|webp)$/.test(file.type)) {
    throw new Error("Use uma imagem JPG, PNG ou WebP.");
  }
  if (file.size > maxUploadBytes) {
    throw new Error("A imagem original deve ter até 8 MB.");
  }

  const { image, objectUrl } = await loadImage(file);
  try {
    const largestSide = Math.max(image.naturalWidth, image.naturalHeight);
    if (!largestSide) throw new Error("Essa imagem não tem dimensões válidas.");

    for (const [maxSide, quality] of [[1600, 0.84], [1280, 0.82], [1024, 0.8], [800, 0.76], [640, 0.7]] as const) {
      const scale = Math.min(1, maxSide / largestSide);
      const canvas = document.createElement("canvas");
      canvas.width = Math.max(1, Math.round(image.naturalWidth * scale));
      canvas.height = Math.max(1, Math.round(image.naturalHeight * scale));
      const context = canvas.getContext("2d");
      if (!context) throw new Error("Não foi possível preparar essa imagem.");
      context.drawImage(image, 0, 0, canvas.width, canvas.height);
      const blob = await canvasToBlob(canvas, quality);
      if (blob.size <= maxStoredBytes || maxSide === 640) return await blobToDataUrl(blob);
    }
  } finally {
    URL.revokeObjectURL(objectUrl);
  }

  throw new Error("Não foi possível preparar essa imagem.");
}
