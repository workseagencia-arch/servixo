import { readSession, saveSession } from "@/lib/auth-store";

export type EditableClientProfile = {
  name: string;
  email: string;
  phone: string;
  accountType: string;
  photoUrl: string;
  address: string;
  birthDate: string;
  taxId: string;
};

const key = "servix.client-profile";
const changed = "servix:client-profile-change";

export function readClientProfile(): EditableClientProfile {
  const session = readSession();
  const fallback: EditableClientProfile = {
    name: session?.name ?? "Sandson Eduardo",
    email: session?.email ?? "sandson@email.com",
    phone: "",
    accountType: "Pessoa física",
    photoUrl: "",
    address: "",
    birthDate: "",
    taxId: "",
  };
  if (typeof window === "undefined") return fallback;
  try {
    return { ...fallback, ...(JSON.parse(window.localStorage.getItem(key) ?? "{}") as Partial<EditableClientProfile>) };
  } catch {
    return fallback;
  }
}

export function saveClientProfile(profile: EditableClientProfile) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(key, JSON.stringify(profile));
  const session = readSession();
  if (session?.role === "cliente") saveSession({ ...session, name: profile.name, email: profile.email });
  window.dispatchEvent(new Event(changed));
}

export function subscribeToClientProfile(listener: () => void) {
  if (typeof window === "undefined") return () => undefined;
  window.addEventListener(changed, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(changed, listener);
    window.removeEventListener("storage", listener);
  };
}
