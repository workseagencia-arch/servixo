// Centralized demonstration data. Replace with Cloud repositories later.
import { addNotification } from "@/lib/notification-store";
import { readSession } from "@/lib/auth-store";
import adWorkshop from "@/assets/port-1.jpg";
import adProfessionals from "@/assets/port-3.jpg";

export type CategorySlug =
  | "montador"
  | "pedreiro"
  | "eletricista"
  | "encanador"
  | "pintor"
  | "marceneiro"
  | "ar-condicionado"
  | "diarista"
  | "jardineiro"
  | "chaveiro"
  | "frete"
  | "marido-de-aluguel"
  | "instalacao"
  | "reformas"
  | "outros";

export type DemoNotification = {
  id: string;
  role: "cliente" | "profissional" | "moderador" | "todos";
  title: string;
  detail: string;
  time: string;
  href?: string;
  read: boolean;
};

export const demoNotifications: DemoNotification[] = [
  {
    id: "cliente-1",
    role: "cliente",
    title: "Carlos está a caminho",
    detail: "Montagem de guarda-roupa · chega em cerca de 25 min",
    time: "Agora",
    href: "/meus-servicos",
    read: false,
  },
  {
    id: "cliente-2",
    role: "cliente",
    title: "Nova proposta recebida",
    detail: "Reforma do banheiro · 3 profissionais responderam",
    time: "Há 1 h",
    href: "/meus-servicos?tab=Orçamentos",
    read: false,
  },
  {
    id: "cliente-3",
    role: "cliente",
    title: "Conte como foi o serviço",
    detail: "Sua avaliação ajuda outros clientes a escolher",
    time: "Há 2 dias",
    href: "/meus-servicos?tab=Histórico",
    read: true,
  },
  {
    id: "profissional-1",
    role: "profissional",
    title: "Novo pedido na sua região",
    detail: "Montagem de guarda-roupa · a 1,2 km",
    time: "Agora",
    href: "/vagas",
    read: false,
  },
  {
    id: "profissional-2",
    role: "profissional",
    title: "Serviço confirmado para amanhã",
    detail: "Instalação de painel de TV · 10h",
    time: "Há 20 min",
    href: "/pro/agenda",
    read: false,
  },
  {
    id: "profissional-3",
    role: "profissional",
    title: "Repasse concluído",
    detail: "R$ 158,00 disponíveis na sua carteira",
    time: "Ontem",
    href: "/pro/ganhos",
    read: true,
  },
];

export const demoProfessionalSecondFactorCode = "482916";

export const categories: { slug: CategorySlug; name: string; from: number; now: boolean }[] = [
  { slug: "montador", name: "Montador de móveis", from: 80, now: true },
  { slug: "eletricista", name: "Eletricista", from: 90, now: true },
  { slug: "encanador", name: "Encanador", from: 90, now: true },
  { slug: "diarista", name: "Diarista", from: 150, now: false },
  { slug: "pintor", name: "Pintor", from: 250, now: false },
  { slug: "ar-condicionado", name: "Ar-condicionado", from: 180, now: true },
  { slug: "chaveiro", name: "Chaveiro", from: 70, now: true },
  { slug: "marido-de-aluguel", name: "Marido de aluguel", from: 100, now: true },
  { slug: "pedreiro", name: "Pedreiro", from: 200, now: false },
  { slug: "marceneiro", name: "Marceneiro", from: 220, now: false },
  { slug: "jardineiro", name: "Jardineiro", from: 120, now: false },
  { slug: "frete", name: "Fretes e mudanças", from: 120, now: true },
  { slug: "instalacao", name: "Técnico / instalação", from: 90, now: true },
  { slug: "reformas", name: "Reformas", from: 500, now: false },
  { slug: "outros", name: "Outras categorias", from: 0, now: false },
];

// Posições das fotos no sprite local da página inicial, em ordem linha a linha.
export const categoryImageIndexes: Record<CategorySlug, number> = {
  montador: 0,
  eletricista: 1,
  encanador: 2,
  diarista: 3,
  pintor: 4,
  "ar-condicionado": 5,
  chaveiro: 6,
  "marido-de-aluguel": 7,
  pedreiro: 8,
  marceneiro: 9,
  jardineiro: 10,
  frete: 11,
  instalacao: 12,
  reformas: 13,
  outros: 14,
};

export const categoryName = (slug: string) =>
  categories.find((c) => c.slug === slug)?.name ?? "Serviço";

export type Review = {
  author: string;
  rating: number;
  text: string;
  date: string;
  service: string;
  verifiedPurchase?: boolean;
};
export type Professional = {
  id: string;
  name: string;
  role: string;
  category: CategorySlug;
  initials: string;
  rating: number;
  reviews: number;
  jobs: number;
  years: number;
  distanceKm: number;
  etaMin: number;
  online: boolean;
  verified: boolean;
  priceFrom: number;
  neighborhood: string;
  radiusKm: number;
  mapX?: number;
  mapY?: number;
  latitude?: number;
  longitude?: number;
  photoUrl?: string;
  availability: string;
  bio: string;
  services: {
    name: string;
    price: number | null;
    duration: string;
    category?: CategorySlug;
    description?: string;
  }[];
  portfolio: number[];
  reviewList: Review[];
  hue: number;
};

export type AdCampaignStatus = "em_analise" | "ativa" | "pausada" | "reprovada";
export type AdCampaignPayment = "pendente" | "confirmado";
export type AdCampaignFormat = "destaque_profissional" | "banner_empresa" | "banner_destaque";
export type AdChannel =
  | "inicio"
  | "busca"
  | "servicos"
  | "profissionais"
  | "vagas"
  | "preco_fechado"
  | "mensagens"
  | "perfil"
  | "notificacoes";
export const adChannelLabels: Record<AdChannel, string> = {
  inicio: "Início",
  busca: "Busca",
  servicos: "Anúncios/Serviços",
  profissionais: "Profissionais",
  vagas: "Vagas",
  preco_fechado: "Preço fechado",
  mensagens: "Mensagens",
  perfil: "Perfil",
  notificacoes: "Notificações",
};
export const customerAdChannels: AdChannel[] = [
  "inicio",
  "busca",
  "servicos",
  "profissionais",
  "vagas",
  "preco_fechado",
  "mensagens",
  "perfil",
  "notificacoes",
];
export type AdCampaign = {
  id: string;
  advertiserType: "profissional" | "empresa";
  advertiserId?: string;
  advertiserName: string;
  format: AdCampaignFormat;
  headline: string;
  description: string;
  imageUrl: string;
  href: string;
  channels?: AdChannel[];
  category?: CategorySlug;
  region: string;
  latitude: number;
  longitude: number;
  radiusKm: number;
  amount: number;
  durationDays: number;
  startsAt: string;
  endsAt: string;
  status: AdCampaignStatus;
  payment: AdCampaignPayment;
  impressions: number;
  clicks: number;
  createdAt: string;
};

// Demonstração comercial centralizada para facilitar a futura troca por um repositório Cloud.
export const demoAdCampaigns: AdCampaign[] = [
  {
    id: "demo-pro-featured",
    advertiserType: "profissional",
    advertiserId: "carlos-henrique",
    advertiserName: "Carlos Henrique",
    format: "destaque_profissional",
    headline: "Montagem cuidadosa, do primeiro parafuso ao acabamento",
    description: "Veja os serviços, valores e horários disponíveis no perfil.",
    imageUrl: adProfessionals,
    href: "/profissional/carlos-henrique",
    channels: ["inicio", "busca", "servicos", "profissionais", "preco_fechado"],
    category: "montador",
    region: "Pinheiros e região · São Paulo",
    latitude: -23.5671,
    longitude: -46.7012,
    radiusKm: 12,
    amount: 99,
    durationDays: 30,
    startsAt: "2026-01-01T00:00:00.000Z",
    endsAt: "2099-12-31T23:59:59.000Z",
    status: "ativa",
    payment: "confirmado",
    impressions: 1240,
    clicks: 86,
    createdAt: "2026-09-01T12:00:00.000Z",
  },
  {
    id: "demo-company-banner",
    advertiserType: "empresa",
    advertiserName: "Casa & Reforma Pinheiros",
    format: "banner_empresa",
    headline: "Tudo para deixar sua casa pronta para morar",
    description: "Ferragens, iluminação e acabamentos com atendimento no bairro.",
    imageUrl: adWorkshop,
    href: "/empresas",
    channels: [
      "inicio",
      "busca",
      "servicos",
      "profissionais",
      "vagas",
      "preco_fechado",
      "mensagens",
      "perfil",
      "notificacoes",
    ],
    region: "Pinheiros e região · São Paulo",
    latitude: -23.5671,
    longitude: -46.7012,
    radiusKm: 15,
    amount: 349,
    durationDays: 30,
    startsAt: "2026-01-01T00:00:00.000Z",
    endsAt: "2099-12-31T23:59:59.000Z",
    status: "ativa",
    payment: "confirmado",
    impressions: 5820,
    clicks: 318,
    createdAt: "2026-09-01T12:00:00.000Z",
  },
];

export type DemoAccountStatus = "ativa" | "suspensa";
export type DemoAdminAccount = {
  id: string;
  name: string;
  email: string;
  role: "cliente" | "profissional" | "empresa" | "moderador";
  professionalId?: string;
  status: DemoAccountStatus;
  verified: boolean;
  lastSeen: string;
};

export const demoAdminAccounts: DemoAdminAccount[] = [
  {
    id: "account-client-marianas",
    name: "Mariana Souza",
    email: "mariana@servix.com.br",
    role: "cliente",
    status: "ativa",
    verified: true,
    lastSeen: "Agora",
  },
  {
    id: "account-carlos",
    name: "Carlos Henrique",
    email: "carlos@servix.com.br",
    role: "profissional",
    professionalId: "carlos-henrique",
    status: "ativa",
    verified: true,
    lastSeen: "Hoje, 09:42",
  },
  {
    id: "account-juliana",
    name: "Juliana Costa",
    email: "juliana@servix.com.br",
    role: "profissional",
    professionalId: "juliana-costa",
    status: "ativa",
    verified: true,
    lastSeen: "Hoje, 08:15",
  },
  {
    id: "account-andre",
    name: "André Luiz",
    email: "andre@servix.com.br",
    role: "profissional",
    professionalId: "andre-luiz",
    status: "ativa",
    verified: true,
    lastSeen: "Ontem, 18:30",
  },
  {
    id: "account-rafael",
    name: "Rafael Santos",
    email: "rafael@servix.com.br",
    role: "profissional",
    professionalId: "rafael-santos",
    status: "ativa",
    verified: false,
    lastSeen: "Ontem, 16:02",
  },
  {
    id: "account-company",
    name: "Casa & Reforma Pinheiros",
    email: "marketing@casareforma.com.br",
    role: "empresa",
    status: "ativa",
    verified: true,
    lastSeen: "28 set, 14:18",
  },
  {
    id: "account-staff",
    name: "Equipe ServiX",
    email: "equipe@servix.com.br",
    role: "moderador",
    status: "ativa",
    verified: true,
    lastSeen: "Agora",
  },
];

export type ModerationReportStatus = "aberta" | "em_analise" | "resolvida" | "arquivada";
export type DemoModerationReport = {
  id: string;
  subjectType: "profissional" | "anuncio";
  subjectId: string;
  subjectName: string;
  reason: string;
  detail: string;
  status: ModerationReportStatus;
  createdAt: string;
};

export const demoModerationReports: DemoModerationReport[] = [
  {
    id: "report-demo-1",
    subjectType: "anuncio",
    subjectId: "demo-company-banner",
    subjectName: "Casa & Reforma Pinheiros",
    reason: "Imagem ou oferta precisa de revisão",
    detail: "Verificar se as condições da oferta estão descritas com clareza.",
    status: "aberta",
    createdAt: "2026-09-29T15:30:00.000Z",
  },
  {
    id: "report-demo-2",
    subjectType: "profissional",
    subjectId: "rafael-santos",
    subjectName: "Rafael Santos",
    reason: "Verificação de documentos pendente",
    detail: "Conferir os documentos antes de conceder o selo de perfil verificado.",
    status: "em_analise",
    createdAt: "2026-09-28T11:10:00.000Z",
  },
];

const r = (
  author: string,
  rating: number,
  text: string,
  date: string,
  service: string,
): Review => ({ author, rating, text, date, service });

export const demoProfessionals: Professional[] = [
  {
    id: "carlos-henrique",
    name: "Carlos Henrique",
    role: "Montador de móveis",
    category: "montador",
    initials: "CH",
    rating: 4.9,
    reviews: 212,
    jobs: 483,
    years: 9,
    distanceKm: 1.8,
    etaMin: 25,
    online: true,
    verified: true,
    priceFrom: 80,
    mapX: 47,
    mapY: 47,
    neighborhood: "Pinheiros, São Paulo",
    radiusKm: 12,
    latitude: -23.5671,
    longitude: -46.7012,
    availability: "Disponível agora",
    hue: 150,
    bio: "Montagem e desmontagem de móveis de todas as marcas, com ferramentas próprias e cuidado com o seu espaço. Pontual e organizado — deixo tudo limpo ao terminar.",
    services: [
      { name: "Montagem de cama", price: 80, duration: "1h" },
      { name: "Montagem de guarda-roupa (até 6 portas)", price: 180, duration: "3h" },
      { name: "Instalação de painel de TV", price: 120, duration: "1h30" },
      { name: "Projeto sob medida", price: null, duration: "Orçamento" },
    ],
    portfolio: [0, 2, 1],
    reviewList: [
      r(
        "Mariana S.",
        5,
        "Montou o guarda-roupa em menos tempo do que o previsto e ainda ajustou as portas. Recomendo demais!",
        "há 2 dias",
        "Guarda-roupa",
      ),
      r(
        "Imobiliária Lar Bom",
        5,
        "Nosso parceiro fixo para entregas de apartamentos mobiliados. Sempre impecável.",
        "há 1 semana",
        "Montagem",
      ),
      r(
        "Rafael T.",
        4,
        "Ótimo serviço, chegou 10 min depois do combinado mas avisou pelo chat.",
        "há 3 semanas",
        "Cama",
      ),
    ],
  },
  {
    id: "juliana-costa",
    name: "Juliana Costa",
    role: "Eletricista",
    category: "eletricista",
    initials: "JC",
    rating: 5.0,
    reviews: 158,
    jobs: 312,
    years: 7,
    distanceKm: 2.6,
    etaMin: 35,
    online: true,
    verified: true,
    priceFrom: 90,
    mapX: 59,
    mapY: 34,
    neighborhood: "Vila Madalena, São Paulo",
    radiusKm: 15,
    latitude: -23.5542,
    longitude: -46.6911,
    availability: "Disponível agora",
    hue: 60,
    bio: "Eletricista com NR-10. Instalações, troca de disjuntores, chuveiros, luminárias e diagnósticos de curto-circuito com laudo.",
    services: [
      { name: "Instalação de chuveiro", price: 90, duration: "1h" },
      { name: "Instalação de luminária", price: 70, duration: "40min" },
      { name: "Troca de quadro de disjuntores", price: 450, duration: "4h" },
      { name: "Diagnóstico elétrico", price: null, duration: "Orçamento" },
    ],
    portfolio: [2, 0, 1],
    reviewList: [
      r(
        "Condomínio Aurora",
        5,
        "Resolveu a iluminação da garagem inteira em um dia. Muito profissional.",
        "há 4 dias",
        "Iluminação",
      ),
      r(
        "Pedro L.",
        5,
        "Explicou tudo com calma e o preço foi exatamente o combinado.",
        "há 2 semanas",
        "Chuveiro",
      ),
    ],
  },
  {
    id: "andre-luiz",
    name: "André Luiz",
    role: "Encanador",
    category: "encanador",
    initials: "AL",
    rating: 4.8,
    reviews: 131,
    jobs: 264,
    years: 12,
    distanceKm: 3.4,
    etaMin: 40,
    online: true,
    verified: true,
    priceFrom: 90,
    mapX: 34,
    mapY: 51,
    neighborhood: "Perdizes, São Paulo",
    radiusKm: 10,
    latitude: -23.5354,
    longitude: -46.6773,
    availability: "Disponível agora",
    hue: 220,
    bio: "Vazamentos, desentupimentos, troca de registros e instalação de louças. Atendimento emergencial na região oeste.",
    services: [
      { name: "Conserto de vazamento", price: 120, duration: "1h" },
      { name: "Desentupimento de pia", price: 110, duration: "1h" },
      { name: "Instalação de vaso sanitário", price: 160, duration: "2h" },
      { name: "Reforma hidráulica", price: null, duration: "Orçamento" },
    ],
    portfolio: [1, 2, 0],
    reviewList: [
      r(
        "Loja Casa Viva",
        5,
        "Atendeu no mesmo dia um vazamento na loja. Salvou nosso sábado!",
        "há 5 dias",
        "Vazamento",
      ),
    ],
  },
  {
    id: "marcos-silva",
    name: "Marcos Silva",
    role: "Pintor",
    category: "pintor",
    initials: "MS",
    rating: 4.9,
    reviews: 97,
    jobs: 188,
    years: 15,
    distanceKm: 4.8,
    etaMin: 0,
    online: false,
    verified: true,
    priceFrom: 250,
    mapX: 28,
    mapY: 73,
    neighborhood: "Butantã, São Paulo",
    radiusKm: 20,
    latitude: -23.5708,
    longitude: -46.7222,
    availability: "Disponível amanhã",
    hue: 110,
    bio: "Pintura residencial e comercial, textura, grafiato e acabamento fino. Proteção completa de móveis e pisos.",
    services: [
      { name: "Pintura de parede (até 12 m²)", price: 250, duration: "1 dia" },
      { name: "Pintura de apartamento completo", price: null, duration: "Orçamento" },
    ],
    portfolio: [2, 1, 0],
    reviewList: [
      r("Ana P.", 5, "Acabamento perfeito, nenhuma mancha no piso.", "há 1 semana", "Pintura sala"),
    ],
  },
  {
    id: "fernanda-rocha",
    name: "Fernanda Rocha",
    role: "Diarista",
    category: "diarista",
    initials: "FR",
    rating: 4.9,
    reviews: 244,
    jobs: 520,
    years: 6,
    distanceKm: 2.1,
    etaMin: 0,
    online: true,
    verified: true,
    priceFrom: 150,
    mapX: 65,
    mapY: 61,
    neighborhood: "Pinheiros, São Paulo",
    radiusKm: 8,
    latitude: -23.5637,
    longitude: -46.6967,
    availability: "Hoje a partir das 14h",
    hue: 330,
    bio: "Limpeza residencial e pós-obra, com produtos próprios. Atendo apartamentos, escritórios e imóveis para entrega.",
    services: [
      { name: "Diária (até 8h)", price: 180, duration: "8h" },
      { name: "Meia diária (4h)", price: 150, duration: "4h" },
      { name: "Limpeza pós-obra", price: null, duration: "Orçamento" },
    ],
    portfolio: [1, 0, 2],
    reviewList: [
      r("Escritório Nexo", 5, "Contratamos toda semana. Confiança total.", "há 3 dias", "Diária"),
    ],
  },
  {
    id: "rafael-santos",
    name: "Rafael Santos",
    role: "Técnico de ar-condicionado",
    category: "ar-condicionado",
    initials: "RS",
    rating: 4.7,
    reviews: 88,
    jobs: 175,
    years: 8,
    distanceKm: 5.9,
    etaMin: 55,
    online: true,
    verified: false,
    priceFrom: 180,
    mapX: 76,
    mapY: 26,
    neighborhood: "Lapa, São Paulo",
    radiusKm: 18,
    latitude: -23.5228,
    longitude: -46.7057,
    availability: "Disponível agora",
    hue: 200,
    bio: "Instalação, limpeza e manutenção de split e janela. Credenciado pelas principais marcas.",
    services: [
      { name: "Limpeza de split", price: 180, duration: "1h30" },
      { name: "Instalação de split até 12.000 BTUs", price: 450, duration: "4h" },
    ],
    portfolio: [0, 1, 2],
    reviewList: [
      r("Lucas M.", 5, "Limpeza caprichada, o ar ficou como novo.", "há 2 semanas", "Limpeza"),
    ],
  },
  {
    id: "gustavo-lima",
    name: "Gustavo Lima",
    role: "Eletricista",
    category: "eletricista",
    initials: "GL",
    rating: 4.8,
    reviews: 73,
    jobs: 146,
    years: 11,
    distanceKm: 12.4,
    etaMin: 0,
    online: true,
    verified: true,
    priceFrom: 110,
    mapX: 40,
    mapY: 23,
    neighborhood: "Lapa, São Paulo",
    radiusKm: 25,
    latitude: -23.5261,
    longitude: -46.7114,
    availability: "Hoje até 18h",
    hue: 165,
    bio: "Instalações elétricas, iluminação e manutenção de quadros. Atendimento residencial e comercial com emissão de nota fiscal.",
    services: [
      { name: "Instalação de tomada e interruptor", price: 110, duration: "1h" },
      { name: "Revisão elétrica residencial", price: null, duration: "Orçamento" },
    ],
    portfolio: [1, 2, 0],
    reviewList: [
      r(
        "Roberto A.",
        5,
        "Chegou no horário e explicou cada etapa.",
        "há 6 dias",
        "Revisão elétrica",
      ),
    ],
  },
  {
    id: "beatriz-nunes",
    name: "Beatriz Nunes",
    role: "Montadora de móveis",
    category: "montador",
    initials: "BN",
    rating: 5.0,
    reviews: 54,
    jobs: 98,
    years: 5,
    distanceKm: 17.8,
    etaMin: 0,
    online: false,
    verified: true,
    priceFrom: 95,
    mapX: 16,
    mapY: 49,
    neighborhood: "Osasco, São Paulo",
    radiusKm: 30,
    latitude: -23.5323,
    longitude: -46.7917,
    availability: "Disponível amanhã",
    hue: 35,
    bio: "Montagem cuidadosa de móveis residenciais, instalação de prateleiras e pequenos ajustes para deixar tudo alinhado.",
    services: [
      { name: "Montagem de cômoda", price: 95, duration: "1h30" },
      { name: "Montagem de móveis planejados", price: null, duration: "Orçamento" },
    ],
    portfolio: [0, 2, 1],
    reviewList: [
      r(
        "Paula R.",
        5,
        "Trabalho limpo, cuidadoso e muito bem feito.",
        "há 1 semana",
        "Montagem de cômoda",
      ),
    ],
  },
  {
    id: "diego-martins",
    name: "Diego Martins",
    role: "Encanador",
    category: "encanador",
    initials: "DM",
    rating: 4.7,
    reviews: 61,
    jobs: 122,
    years: 10,
    distanceKm: 24.6,
    etaMin: 0,
    online: true,
    verified: false,
    priceFrom: 130,
    mapX: 81,
    mapY: 79,
    neighborhood: "Santo André, São Paulo",
    radiusKm: 35,
    latitude: -23.6742,
    longitude: -46.5322,
    availability: "Disponível hoje",
    hue: 255,
    bio: "Atendimento de vazamentos, torneiras, registros e aquecedores. Visita técnica combinada com transparência.",
    services: [
      { name: "Troca de torneira", price: 130, duration: "1h" },
      { name: "Detecção de vazamento", price: null, duration: "Orçamento" },
    ],
    portfolio: [2, 0, 1],
    reviewList: [
      r(
        "Mariana F.",
        5,
        "Resolveu o vazamento e deixou o local organizado.",
        "há 4 dias",
        "Vazamento",
      ),
    ],
  },
];

// Public-facing screens start empty and are filled by real account data.
export const professionals: Professional[] = [];

export const findPro = (id: string) => professionals.find((p) => p.id === id);

export const popularFixed = [
  { title: "Montagem de cama", price: 80, pro: "carlos-henrique" },
  { title: "Instalação de chuveiro", price: 90, pro: "juliana-costa" },
  { title: "Conserto de vazamento", price: 120, pro: "andre-luiz" },
  { title: "Limpeza de split", price: 180, pro: "rafael-santos" },
];

export const PLATFORM_FEE = 0.08; // taxa de serviço exibida ao cliente
export const PRO_COMMISSION = 0.12; // comissão retida do profissional

export type OrderStatus =
  | "Solicitado"
  | "Confirmado"
  | "A caminho"
  | "Em execução"
  | "Concluído"
  | "Aguardando propostas"
  | "Aceito";
export const orderSteps: OrderStatus[] = [
  "Solicitado",
  "Confirmado",
  "A caminho",
  "Em execução",
  "Concluído",
];

export type Order = {
  id: string;
  title: string;
  proId: string | null;
  status: OrderStatus;
  when: string;
  price: number | null;
  kind: "fixo" | "orcamento";
  proposals?: number;
  rated?: boolean;
  place?: string;
  acceptedProId?: string;
  bookingId?: string;
};

export const demoMyOrders: Order[] = [
  {
    id: "S-2081",
    title: "Montagem de guarda-roupa",
    proId: "carlos-henrique",
    status: "A caminho",
    when: "Hoje, 15:00",
    price: 180,
    kind: "fixo",
  },
  {
    id: "S-2079",
    title: "Instalação de chuveiro",
    proId: "juliana-costa",
    status: "Confirmado",
    when: "Amanhã, 09:00",
    price: 90,
    kind: "fixo",
  },
  {
    id: "S-2077",
    title: "Reforma do banheiro",
    proId: null,
    status: "Aguardando propostas",
    when: "Flexível",
    price: null,
    kind: "orcamento",
    proposals: 3,
  },
  {
    id: "S-2064",
    title: "Pintura da sala",
    proId: "marcos-silva",
    status: "Concluído",
    when: "18 set",
    price: 520,
    kind: "orcamento",
    rated: false,
  },
  {
    id: "S-2051",
    title: "Conserto de vazamento",
    proId: "andre-luiz",
    status: "Concluído",
    when: "02 set",
    price: 120,
    kind: "fixo",
    rated: true,
  },
];
export const myOrders: Order[] = [];

export const demoProposals = [
  {
    proId: "andre-luiz",
    price: 3800,
    days: "5 dias",
    note: "Inclui troca de revestimento e louças. Material à parte.",
  },
  {
    proId: "marcos-silva",
    price: 4200,
    days: "6 dias",
    note: "Reforma completa com acabamento e pintura.",
  },
  {
    proId: "carlos-henrique",
    price: 3500,
    days: "7 dias",
    note: "Mão de obra com equipe de 2 pessoas.",
  },
];
export const proposals: typeof demoProposals = [];

export type Message = {
  from: "me" | "them";
  text: string;
  time: string;
  audioUrl?: string;
  attachmentUrl?: string;
  attachmentName?: string;
  attachmentType?: string;
};
export const demoConversations: {
  proId: string;
  order: string;
  unread: number;
  messages: Message[];
}[] = [
  {
    proId: "carlos-henrique",
    order: "Montagem de guarda-roupa",
    unread: 2,
    messages: [
      { from: "me", text: "Oi Carlos! O guarda-roupa tem 6 portas e 3 gavetas.", time: "13:02" },
      {
        from: "them",
        text: "Perfeito, levo tudo que precisa. Tem elevador no prédio?",
        time: "13:05",
      },
      { from: "me", text: "Tem sim, social e de serviço.", time: "13:06" },
      { from: "them", text: "Ótimo! Já estou a caminho, chego em uns 25 minutos.", time: "14:34" },
      { from: "them", text: "Pode deixar a portaria avisada?", time: "14:35" },
    ],
  },
  {
    proId: "juliana-costa",
    order: "Instalação de chuveiro",
    unread: 0,
    messages: [
      {
        from: "them",
        text: "Confirmado para amanhã às 9h. O chuveiro já está comprado?",
        time: "Ontem",
      },
      { from: "me", text: "Sim! Lorenzetti 220V.", time: "Ontem" },
    ],
  },
  {
    proId: "andre-luiz",
    order: "Reforma do banheiro",
    unread: 1,
    messages: [
      {
        from: "them",
        text: "Enviei minha proposta. Posso fazer uma visita técnica sem custo.",
        time: "Seg",
      },
    ],
  },
];
export const conversations: typeof demoConversations = [];

export const clientTypes = [
  "Pessoa física",
  "Empresa",
  "Imobiliária",
  "Administradora",
  "Condomínio",
  "Comércio",
  "Escritório",
];

export const demoNotificationsForDashboard = [
  { text: "Carlos Henrique está a caminho", time: "agora" },
  { text: "Nova proposta para Reforma do banheiro", time: "1h" },
  { text: "Avalie o serviço de Marcos Silva", time: "2d" },
];
export const notifications: typeof demoNotificationsForDashboard = [];

// ------- Módulo empresarial (imobiliárias, condomínios, empresas) -------
export const demoBusinessProperties = [
  {
    code: "IMV-127",
    name: "Apartamento 302",
    address: "Rua das Palmeiras, 120 · Centro",
    services: 3,
    spent: 2840,
  },
  {
    code: "IMV-126",
    name: "Casa Jardins",
    address: "Rua das Acácias, 48 · Jardins",
    services: 1,
    spent: 1920,
  },
  {
    code: "IMV-125",
    name: "Sala 804 · Business Tower",
    address: "Av. Central, 980",
    services: 2,
    spent: 4110,
  },
  {
    code: "IMV-124",
    name: "Loja 04 · Centro Comercial",
    address: "Praça da República, 10",
    services: 0,
    spent: 980,
  },
];
export const businessProperties: typeof demoBusinessProperties = [];

// ------- Painel do profissional -------
// Profile template only; it is populated from the signed-in account/backend at runtime.
export const proMe: Professional = {
  id: "current-user",
  name: "",
  role: "Profissional",
  category: "outros",
  initials: "",
  rating: 0,
  reviews: 0,
  jobs: 0,
  years: 0,
  distanceKm: Number.POSITIVE_INFINITY,
  etaMin: 0,
  online: false,
  verified: false,
  priceFrom: 0,
  neighborhood: "",
  radiusKm: 0,
  availability: "Disponibilidade não informada",
  bio: "",
  services: [],
  portfolio: [],
  reviewList: [],
  hue: 0,
};

export const demoProRequests = [
  {
    id: "P-903",
    client: "Mariana Souza",
    clientType: "Pessoa física",
    title: "Montagem de guarda-roupa 6 portas",
    category: "montador" as const,
    kind: "fixo" as const,
    price: 180,
    when: "Agora",
    distanceKm: 1.2,
    address: "Rua Cardeal Arcoverde, 1200",
  },
  {
    id: "P-902",
    client: "Imobiliária Lar Bom",
    clientType: "Imobiliária",
    title: "Montar 3 camas e 2 racks — apto para locação",
    category: "montador" as const,
    kind: "orcamento" as const,
    price: null,
    when: "Sex, 28 set",
    distanceKm: 3.6,
    address: "Rua Aurora, 221 · Apto 108",
  },
  {
    id: "P-901",
    client: "Escritório Nexo",
    clientType: "Escritório",
    title: "Montagem de 8 estações de trabalho",
    category: "montador" as const,
    kind: "orcamento" as const,
    price: null,
    when: "Próxima semana",
    distanceKm: 4.1,
    address: "Av. Faria Lima, 3000",
  },
  {
    id: "P-900",
    client: "Pedro Lima",
    clientType: "Pessoa física",
    title: "Instalação de painel de TV",
    category: "montador" as const,
    kind: "fixo" as const,
    price: 120,
    when: "Amanhã, 10:00",
    distanceKm: 2.3,
    address: "Rua Teodoro Sampaio, 800",
  },
];
export const proRequests: typeof demoProRequests = [];

export const demoProAgenda = [
  {
    id: "A-1",
    time: "09:00",
    title: "Montagem de cama",
    client: "Lucas Mendes",
    address: "Rua Fradique Coutinho, 50",
    price: 80,
    status: "Concluído" as OrderStatus,
  },
  {
    id: "A-2",
    time: "15:00",
    title: "Montagem de guarda-roupa",
    client: "Sandson E.",
    address: "Rua dos Pinheiros, 400",
    price: 180,
    status: "A caminho" as OrderStatus,
  },
  {
    id: "A-3",
    time: "18:00",
    title: "Instalação de painel de TV",
    client: "Condomínio Aurora",
    address: "Av. Rebouças, 2100",
    price: 120,
    status: "Confirmado" as OrderStatus,
  },
];
export const proAgenda: typeof demoProAgenda = [];

export const demoEarningsWeek = [
  { day: "Seg", value: 260 },
  { day: "Ter", value: 380 },
  { day: "Qua", value: 180 },
  { day: "Qui", value: 520 },
  { day: "Sex", value: 440 },
  { day: "Sáb", value: 610 },
  { day: "Dom", value: 120 },
];
export const earningsWeek: typeof demoEarningsWeek = [];

export const demoPayouts = [
  { date: "20 set", amount: 1840, status: "Pago" },
  { date: "13 set", amount: 2125, status: "Pago" },
  { date: "06 set", amount: 1590, status: "Pago" },
];
export const payouts: typeof demoPayouts = [];

export const brl = (v: number) =>
  v.toLocaleString("pt-BR", {
    style: "currency",
    currency: "BRL",
    minimumFractionDigits: 2,
    maximumFractionDigits: 2,
  });

// ------- Contratações criadas pelo cliente (mockadas) -------
export type Booking = {
  id: string;
  proId: string;
  service: string;
  price: number;
  duration: string;
  mode: "agora" | "agendar";
  date?: string;
  time?: string;
  cep: string;
  address: string;
  number: string;
  complement?: string;
  status: OrderStatus;
  createdAt: string;
  completedAt?: string;
  ownerEmail?: string;
};

export const bookings: Booking[] = [];
const bookingStorageKey = "servix.bookings";
const bookingChangeEvent = "servix:bookings-change";
export function readBookings(): Booking[] {
  if (typeof window === "undefined") return [];
  try {
    const saved = window.localStorage.getItem(bookingStorageKey);
    if (saved) {
      const records: unknown = JSON.parse(saved);
      if (Array.isArray(records)) bookings.splice(0, bookings.length, ...(records as Booking[]));
    } else bookings.splice(0, bookings.length);
  } catch {
    /* Preserve the current list if storage is unavailable. */
  }
  return bookings;
}
function persistBookings() {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(bookingStorageKey, JSON.stringify(bookings));
  window.dispatchEvent(new Event(bookingChangeEvent));
}
export function subscribeToBookings(listener: () => void) {
  if (typeof window === "undefined") return () => undefined;
  window.addEventListener(bookingChangeEvent, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(bookingChangeEvent, listener);
    window.removeEventListener("storage", listener);
  };
}
export function updateBookingStatus(id: string, status: OrderStatus) {
  const booking = readBookings().find((item) => item.id === id);
  if (!booking) return false;
  booking.status = status;
  if (status === "Concluído") booking.completedAt = new Date().toISOString();
  persistBookings();
  return true;
}
let bookingSeq = 2099;
export function addBooking(b: Omit<Booking, "id" | "status" | "createdAt">): Booking {
  readBookings();
  bookingSeq = Math.max(
    bookingSeq,
    ...bookings.map((item) => Number(item.id.replace(/\D/g, "")) || 0),
  );
  const id = `S-${++bookingSeq}`;
  const ownerEmail = b.ownerEmail ?? readSession()?.email;
  const booking: Booking = {
    ...b,
    ...(ownerEmail ? { ownerEmail } : {}),
    id,
    status: "Confirmado",
    createdAt: new Date().toISOString(),
  };
  bookings.unshift(booking);
  persistBookings();
  return booking;
}
export function findBooking(id: string) {
  return readBookings().find((b) => b.id === id);
}

// ------- Solicitações de orçamento (mockadas) -------
export type QuoteProposal = {
  id: string;
  proId: string;
  price: number;
  days: string;
  note: string;
};
export type QuoteRequest = {
  id: string;
  description: string;
  category: string; // slug
  referencePrice?: number;
  sourceService?: string;
  targetProId?: string | undefined;
  ownerEmail?: string;
  latitude?: number;
  longitude?: number;
  when: "asap" | "semana" | "data";
  date?: string;
  cep: string;
  address: string;
  number: string;
  complement?: string | undefined;
  photos: string[];
  status: "Aguardando propostas" | "Aceito";
  proposals: QuoteProposal[];
  acceptedProposalId?: string;
  bookingId?: string;
  createdAt: string;
};

export const quoteRequests: QuoteRequest[] = [];
let quoteSeq = 3000;
const quoteStorageKey = "servix.quote-requests";
const quoteChangeEvent = "servix:quote-requests-change";
let quotesLoaded = false;
let lastQuoteStorage: string | null | undefined;

function hydrateQuoteRequests() {
  if (typeof window === "undefined") return;
  try {
    const saved = window.localStorage.getItem(quoteStorageKey);
    if (quotesLoaded && saved === lastQuoteStorage) return;
    quotesLoaded = true;
    lastQuoteStorage = saved;
    if (!saved) {
      quoteRequests.splice(0, quoteRequests.length);
      return;
    }
    const items = JSON.parse(saved) as QuoteRequest[];
    if (Array.isArray(items)) {
      quoteRequests.splice(0, quoteRequests.length, ...items);
      const maxId = items.reduce(
        (max, item) => Math.max(max, Number(item.id.replace(/\D/g, "")) || 0),
        quoteSeq,
      );
      quoteSeq = maxId;
    }
  } catch {
    // Keep the in-memory demo data if local storage is unavailable.
  }
}

function persistQuoteRequests() {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(quoteStorageKey, JSON.stringify(quoteRequests));
  window.dispatchEvent(new Event(quoteChangeEvent));
}

export function readQuoteRequests() {
  hydrateQuoteRequests();
  return quoteRequests;
}

export function subscribeToQuoteRequests(listener: () => void) {
  if (typeof window === "undefined") return () => undefined;
  window.addEventListener(quoteChangeEvent, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(quoteChangeEvent, listener);
    window.removeEventListener("storage", listener);
  };
}

export const quoteWhenLabel = (q: Pick<QuoteRequest, "when" | "date">) =>
  q.when === "asap"
    ? "O quanto antes"
    : q.when === "semana"
      ? "Esta semana"
      : (q.date ?? "Data a definir");

export function addQuoteRequest(
  q: Omit<QuoteRequest, "id" | "status" | "proposals" | "createdAt">,
): QuoteRequest {
  hydrateQuoteRequests();
  const id = `O-${++quoteSeq}`;
  const req: QuoteRequest = {
    ...q,
    id,
    status: "Aguardando propostas",
    proposals: [],
    createdAt: new Date().toISOString(),
  };
  quoteRequests.unshift(req);
  persistQuoteRequests();
  const storedOwnServices =
    typeof window === "undefined"
      ? []
      : (() => {
          try {
            const saved = window.localStorage.getItem("servix.pro-services");
            const services = saved
              ? (JSON.parse(saved) as { category?: CategorySlug; active?: boolean }[])
              : [];
            return Array.isArray(services) ? services : [];
          } catch {
            return [];
          }
        })();
  const ownCategories = new Set([
    proMe.category,
    ...proMe.services.map((service) => service.category ?? proMe.category),
    ...storedOwnServices
      .filter((service) => service.active !== false)
      .map((service) => service.category ?? proMe.category),
  ]);
  const compatible = professionals.filter((professional) => {
    const matches =
      professional.category === q.category ||
      professional.services.some(
        (service) => (service.category ?? professional.category) === q.category,
      ) ||
      (professional.id === proMe.id && ownCategories.has(q.category as CategorySlug));
    return matches && (!q.targetProId || professional.id === q.targetProId);
  });
  if (compatible.length)
    addNotification({
      role: "profissional",
      title: "Nova oportunidade próxima",
      detail: `${categoryName(q.category)} · ${q.description.slice(0, 90)}`,
      href: "/vagas",
    });
  return req;
}

export function sendQuoteProposal(
  requestId: string,
  proposal: Omit<QuoteProposal, "id">,
): QuoteRequest | undefined {
  hydrateQuoteRequests();
  const request = quoteRequests.find((item) => item.id === requestId);
  if (
    !request ||
    request.status === "Aceito" ||
    request.proposals.some((item) => item.proId === proposal.proId)
  )
    return undefined;
  request.proposals.push({ ...proposal, id: `${requestId}-p-${Date.now()}` });
  persistQuoteRequests();
  addNotification({
    role: "cliente",
    title: "Nova proposta recebida",
    detail: `${categoryName(request.category)} · ${proposal.days} · ${brl(proposal.price)}`,
    href: "/meus-servicos?tab=Orçamentos",
  });
  return request;
}

export function acceptQuoteProposal(quoteId: string, proposalId: string): Booking | undefined {
  hydrateQuoteRequests();
  const q = quoteRequests.find((x) => x.id === quoteId);
  const p = q?.proposals.find((x) => x.id === proposalId);
  if (!q || !p || q.status === "Aceito") return undefined;
  const email = readSession()?.email.toLocaleLowerCase("pt-BR");
  if (!email || q.ownerEmail?.toLocaleLowerCase("pt-BR") !== email) return undefined;
  const booking = addBooking({
    proId: p.proId,
    service: q.description,
    price: p.price,
    duration: p.days,
    mode: "agendar",
    date: quoteWhenLabel(q),
    time: "a combinar",
    cep: q.cep,
    address: q.address,
    number: q.number,
    complement: q.complement ?? "",
  });
  q.status = "Aceito";
  q.acceptedProposalId = p.id;
  q.bookingId = booking.id;
  persistQuoteRequests();
  addNotification({
    role: "profissional",
    title: "Sua proposta foi aceita",
    detail: `${categoryName(q.category)} · ${brl(p.price)} · ${quoteWhenLabel(q)}`,
    href: "/pro/agenda",
  });
  return booking;
}

// Aceitar proposta de um pedido de orçamento antigo (myOrders)
export function acceptLegacyProposal(orderId: string, proId: string): Booking | undefined {
  const o = myOrders.find((x) => x.id === orderId);
  const p = proposals.find((x) => x.proId === proId);
  if (!o || !p || o.status === "Aceito") return undefined;
  const booking = addBooking({
    proId: p.proId,
    service: o.title,
    price: p.price,
    duration: p.days,
    mode: "agendar",
    date: o.when,
    time: "a combinar",
    cep: "05422-000",
    address: "Rua dos Pinheiros",
    number: "400",
    complement: "Apto 52",
  });
  o.status = "Aceito";
  o.acceptedProId = p.proId;
  o.bookingId = booking.id;
  return booking;
}
