import type { AccountRole } from "@/lib/auth-store";

export type DeviceLocation = { latitude: number; longitude: number; accuracy: number; updatedAt: string };
const eventName = "servix:location-change";
const keyFor = (role: AccountRole) => `servix.location.${role}`;

export function readDeviceLocation(role: AccountRole): DeviceLocation | null {
  if (typeof window === "undefined") return null;
  try {
    const value = window.localStorage.getItem(keyFor(role));
    const shared = value ?? (role === "profissional" ? window.localStorage.getItem(keyFor("cliente")) : role === "cliente" ? window.localStorage.getItem(keyFor("profissional")) : null);
    return shared ? JSON.parse(shared) as DeviceLocation : null;
  } catch {
    return null;
  }
}

export function watchDeviceLocation(role: AccountRole, onError?: (message: string) => void) {
  if (typeof navigator === "undefined" || !navigator.geolocation) {
    onError?.("Este aparelho não disponibiliza localização pelo navegador.");
    return () => undefined;
  }
  const watchId = navigator.geolocation.watchPosition((position) => {
    const location: DeviceLocation = {
      latitude: position.coords.latitude,
      longitude: position.coords.longitude,
      accuracy: position.coords.accuracy,
      updatedAt: new Date(position.timestamp).toISOString(),
    };
    window.localStorage.setItem(keyFor(role), JSON.stringify(location));
    if (role === "cliente" || role === "profissional") {
      window.localStorage.setItem(keyFor(role === "cliente" ? "profissional" : "cliente"), JSON.stringify(location));
    }
    window.dispatchEvent(new Event(eventName));
  }, (error) => {
    const message = error.code === error.PERMISSION_DENIED
      ? "Permita o acesso à localização nas configurações do navegador."
      : "Não foi possível atualizar sua localização. Confira o sinal e tente novamente.";
    onError?.(message);
  }, { enableHighAccuracy: true, maximumAge: 15_000, timeout: 20_000 });
  return () => navigator.geolocation.clearWatch(watchId);
}

export function subscribeToLocation(listener: () => void) {
  if (typeof window === "undefined") return () => undefined;
  window.addEventListener(eventName, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(eventName, listener);
    window.removeEventListener("storage", listener);
  };
}

export function distanceBetweenKm(a: Pick<DeviceLocation, "latitude" | "longitude">, b: Pick<DeviceLocation, "latitude" | "longitude">) {
  const radians = (degrees: number) => degrees * Math.PI / 180;
  const dLat = radians(b.latitude - a.latitude);
  const dLon = radians(b.longitude - a.longitude);
  const value = Math.sin(dLat / 2) ** 2 + Math.cos(radians(a.latitude)) * Math.cos(radians(b.latitude)) * Math.sin(dLon / 2) ** 2;
  return 6371 * 2 * Math.atan2(Math.sqrt(value), Math.sqrt(1 - value));
}
