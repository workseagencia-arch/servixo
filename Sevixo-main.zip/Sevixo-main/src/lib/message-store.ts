import type { AccountRole } from "@/lib/auth-store";
import type { Message } from "@/lib/demo-data";
import { readSession } from "@/lib/auth-store";

export type ChatMessage = Message & {
  id: string;
  sender: AccountRole;
};

export type ManagedChatThread = {
  id: string;
  proId: string;
  order: string;
  clientName: string;
  clientEmail?: string;
  professionalName?: string;
  professionalPhotoUrl?: string;
  price: number | null;
  duration: string;
  createdAt: string;
  confirmations: { cliente: boolean; profissional: boolean };
};

type StoredThreads = Record<string, ChatMessage[]>;

const storageKey = "servix.messages.v1";
const managedThreadsKey = "servix.message-threads.v1";
const changeEvent = "servix:messages-change";

function readAll(): StoredThreads {
  if (typeof window === "undefined") return {};
  try {
    const value: unknown = JSON.parse(window.localStorage.getItem(storageKey) ?? "{}");
    return value && typeof value === "object" && !Array.isArray(value)
      ? (value as StoredThreads)
      : {};
  } catch {
    return {};
  }
}

export function readManagedChatThreads(): ManagedChatThread[] {
  if (typeof window === "undefined") return [];
  try {
    const value: unknown = JSON.parse(window.localStorage.getItem(managedThreadsKey) ?? "[]");
    return Array.isArray(value) ? (value as ManagedChatThread[]) : [];
  } catch {
    return [];
  }
}

export function startProfessionalChat(input: {
  proId: string;
  service: string;
  clientName: string;
  professionalName?: string;
  professionalPhotoUrl?: string;
  price?: number | null;
  duration?: string;
  sender: "cliente" | "profissional";
  message?: string;
}): ManagedChatThread {
  const clientEmail = readSession()?.email;
  const existing = readManagedChatThreads().find(
    (thread) =>
      thread.proId === input.proId &&
      thread.order === input.service &&
      thread.clientEmail === clientEmail,
  );
  if (existing) return existing;
  const id =
    typeof crypto !== "undefined" && "randomUUID" in crypto
      ? `chat-${crypto.randomUUID()}`
      : `chat-${Date.now()}-${Math.random().toString(36).slice(2)}`;
  const thread: ManagedChatThread = {
    id,
    proId: input.proId,
    order: input.service,
    clientName: input.clientName,
    ...(clientEmail ? { clientEmail } : {}),
    ...(input.professionalName ? { professionalName: input.professionalName } : {}),
    ...(input.professionalPhotoUrl ? { professionalPhotoUrl: input.professionalPhotoUrl } : {}),
    price: input.price ?? null,
    duration: input.duration ?? "A combinar",
    createdAt: new Date().toISOString(),
    confirmations: { cliente: false, profissional: false },
  };

  if (typeof window !== "undefined") {
    window.localStorage.setItem(
      managedThreadsKey,
      JSON.stringify([thread, ...readManagedChatThreads()]),
    );
  }
  if (typeof window !== "undefined") {
    const all = readAll();
    all[id] = [];
    window.localStorage.setItem(storageKey, JSON.stringify(all));
    if (input.message?.trim())
      appendChatMessage(id, [], input.sender, {
        from: "me",
        text: input.message.trim(),
        time: new Date().toLocaleTimeString("pt-BR", { hour: "2-digit", minute: "2-digit" }),
      });
  }
  if (typeof window !== "undefined") window.dispatchEvent(new Event(changeEvent));
  return thread;
}

export function confirmChatService(threadId: string, role: "cliente" | "profissional") {
  if (typeof window === "undefined") return;
  const threads = readManagedChatThreads();
  const updated = threads.map((thread) =>
    thread.id === threadId
      ? { ...thread, confirmations: { ...thread.confirmations, [role]: true } }
      : thread,
  );
  window.localStorage.setItem(managedThreadsKey, JSON.stringify(updated));
  window.dispatchEvent(new Event(changeEvent));
}

function fixtureMessages(messages: Message[]): ChatMessage[] {
  return messages.map((message, index) => ({
    ...message,
    id: `fixture-${index}`,
    // Os exemplos são escritos do ponto de vista do cliente.
    sender: message.from === "me" ? "cliente" : "profissional",
  }));
}

export function readChatThread(threadId: string, initialMessages: Message[]): ChatMessage[] {
  const saved = readAll()[threadId];
  if (Array.isArray(saved)) return saved;
  return fixtureMessages(initialMessages);
}

export function appendChatMessage(
  threadId: string,
  initialMessages: Message[],
  sender: AccountRole,
  message: Message,
): ChatMessage {
  const all = readAll();
  const existing = Array.isArray(all[threadId]) ? all[threadId]! : fixtureMessages(initialMessages);
  const next: ChatMessage = {
    ...message,
    id:
      typeof crypto !== "undefined" && "randomUUID" in crypto
        ? crypto.randomUUID()
        : `message-${Date.now()}-${Math.random().toString(36).slice(2)}`,
    sender,
  };

  all[threadId] = [...existing, next];
  if (typeof window !== "undefined") {
    window.localStorage.setItem(storageKey, JSON.stringify(all));
    window.dispatchEvent(new Event(changeEvent));
  }
  return next;
}

export function subscribeToChatMessages(listener: () => void) {
  if (typeof window === "undefined") return () => undefined;
  window.addEventListener(changeEvent, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(changeEvent, listener);
    window.removeEventListener("storage", listener);
  };
}
