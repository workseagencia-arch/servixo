import type { AccountRole } from "@/lib/auth-store";
import { type DemoNotification } from "@/lib/demo-data";

export type ServixNotification = DemoNotification;

const storageKey = "servix.notifications";
const changeEvent = "servix:notifications-change";

function readAll(): ServixNotification[] {
  if (typeof window === "undefined") return [];
  try {
    const saved = window.localStorage.getItem(storageKey);
    if (!saved) return [];
    const parsed = JSON.parse(saved) as ServixNotification[];
    return Array.isArray(parsed)
      ? parsed.filter((item) => !/^(cliente-[123]|profissional-[123])$/.test(item.id))
      : [];
  } catch {
    return [];
  }
}

function writeAll(items: ServixNotification[]) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(storageKey, JSON.stringify(items));
  window.dispatchEvent(new Event(changeEvent));
}

export function getNotifications(role: AccountRole): ServixNotification[] {
  return getNotificationsForRoles([role]);
}

export function getNotificationsForRoles(roles: AccountRole[]): ServixNotification[] {
  const visible = new Set(roles);
  return readAll().filter((item) => visible.has(item.role as AccountRole) || item.role === "todos");
}

export function markNotificationRead(id: string) {
  writeAll(readAll().map((item) => (item.id === id ? { ...item, read: true } : item)));
}

export function deleteNotification(id: string) {
  writeAll(readAll().filter((item) => item.id !== id));
}

export function markAllNotificationsRead(role: AccountRole) {
  markAllNotificationsReadForRoles([role]);
}

export function markAllNotificationsReadForRoles(roles: AccountRole[]) {
  const visible = new Set(roles);
  writeAll(
    readAll().map((item) =>
      visible.has(item.role as AccountRole) || item.role === "todos"
        ? { ...item, read: true }
        : item,
    ),
  );
}

export function addNotification(item: Omit<ServixNotification, "id" | "time" | "read">) {
  const next: ServixNotification = {
    ...item,
    id: `n-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    time: "Agora",
    read: false,
  };
  writeAll([next, ...readAll()]);
}

export function subscribeToNotifications(listener: () => void) {
  if (typeof window === "undefined") return () => undefined;
  window.addEventListener(changeEvent, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(changeEvent, listener);
    window.removeEventListener("storage", listener);
  };
}
