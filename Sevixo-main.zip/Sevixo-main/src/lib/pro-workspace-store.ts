export type RequestDecision = "aceito" | "dispensado";

const storageKey = "servix.pro-request-decisions";

export function readRequestDecisions(): Record<string, RequestDecision> {
  if (typeof window === "undefined") return {};
  try {
    const saved = window.localStorage.getItem(storageKey);
    return saved ? JSON.parse(saved) as Record<string, RequestDecision> : {};
  } catch {
    return {};
  }
}

export function saveRequestDecision(id: string, decision: RequestDecision) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(storageKey, JSON.stringify({ ...readRequestDecisions(), [id]: decision }));
  window.dispatchEvent(new Event("servix:request-change"));
}
