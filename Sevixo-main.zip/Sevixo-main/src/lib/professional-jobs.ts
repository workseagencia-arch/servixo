import {
  proAgenda,
  proMe,
  proRequests,
  quoteWhenLabel,
  readBookings,
  readQuoteRequests,
  subscribeToBookings,
  subscribeToQuoteRequests,
  type OrderStatus,
} from "@/lib/demo-data";
import { readRequestDecisions } from "@/lib/pro-workspace-store";

export type ProfessionalJob = {
  id: string;
  title: string;
  client: string;
  address: string;
  time: string;
  dateLabel: string;
  price: number;
  status: OrderStatus;
  createdAt: string;
  completedAt?: string;
};

export function readProfessionalJobs(): ProfessionalJob[] {
  if (typeof window === "undefined") return [];
  let statuses: Record<string, OrderStatus> = {};
  try {
    statuses = JSON.parse(window.localStorage.getItem("servix.pro-agenda-status") ?? "{}");
  } catch {
    /* Use the booking's saved status. */
  }
  const requests = readQuoteRequests();
  const booked: ProfessionalJob[] = readBookings()
    .filter((booking) => booking.proId === proMe.id)
    .map((booking) => {
      const request = requests.find((item) => item.bookingId === booking.id);
      return {
        id: booking.id,
        title: booking.service,
        client: request?.ownerEmail ?? booking.ownerEmail ?? "Cliente ServiX",
        address: `${booking.address}${booking.number ? `, ${booking.number}` : ""}`,
        time: booking.time ?? "A combinar",
        dateLabel: booking.date ?? "A combinar",
        price: booking.price,
        status: booking.status,
        createdAt: booking.createdAt,
        ...(booking.completedAt ? { completedAt: booking.completedAt } : {}),
      };
    });
  const accepted: ProfessionalJob[] = requests.flatMap((request) => {
    const proposal = request.proposals.find((item) => item.id === request.acceptedProposalId);
    if (
      request.status !== "Aceito" ||
      !request.bookingId ||
      !proposal ||
      proposal.proId !== proMe.id ||
      booked.some((item) => item.id === request.bookingId)
    )
      return [];
    return [
      {
        id: request.bookingId,
        title: request.description,
        client: request.ownerEmail ?? "Cliente ServiX",
        address: `${request.address}${request.number ? `, ${request.number}` : ""}`,
        time: "A combinar",
        dateLabel: quoteWhenLabel(request),
        price: proposal.price,
        status: statuses[request.bookingId] ?? "Confirmado",
        createdAt: request.createdAt,
      },
    ];
  });
  const direct = proRequests
    .filter((request) => readRequestDecisions()[request.id] === "aceito")
    .map((request) => ({
      id: request.id,
      title: request.title,
      client: request.client,
      address: request.address,
      time: "A combinar",
      dateLabel: request.when,
      price: request.price ?? 0,
      status: statuses[request.id] ?? ("Confirmado" as OrderStatus),
      createdAt: "",
    }));
  const scheduled = proAgenda.map((item) => ({
    ...item,
    dateLabel: "Data a combinar",
    status: statuses[item.id] ?? item.status,
    createdAt: "",
  }));
  return [...booked, ...accepted, ...direct, ...scheduled].sort(
    (a, b) =>
      (a.status === "Concluído" ? 1 : 0) - (b.status === "Concluído" ? 1 : 0) ||
      a.dateLabel.localeCompare(b.dateLabel) ||
      a.time.localeCompare(b.time),
  );
}

export function subscribeToProfessionalJobs(listener: () => void) {
  const a = subscribeToBookings(listener);
  const b = subscribeToQuoteRequests(listener);
  if (typeof window === "undefined")
    return () => {
      a();
      b();
    };
  window.addEventListener("servix:agenda-change", listener);
  window.addEventListener("servix:request-change", listener);
  return () => {
    a();
    b();
    window.removeEventListener("servix:agenda-change", listener);
    window.removeEventListener("servix:request-change", listener);
  };
}
