export type ProfessionalOnboardingStatus = {
  email: string;
  personalDataSubmitted: boolean;
  faceCaptureCompleted?: boolean;
  secondFactorCompleted?: boolean;
  verificationLevel: "demonstration" | "personal_data";
  completedAt: string;
};

const storageKey = "servix.professional-onboarding";
const changeEvent = "servix:professional-onboarding-change";

function readAll(): ProfessionalOnboardingStatus[] {
  if (typeof window === "undefined") return [];
  try {
    const parsed = JSON.parse(window.localStorage.getItem(storageKey) ?? "[]") as unknown;
    if (!Array.isArray(parsed)) return [];
    return parsed.filter(
      (item): item is ProfessionalOnboardingStatus =>
        typeof item === "object" &&
        item !== null &&
        "email" in item &&
        typeof item.email === "string" &&
        "verificationLevel" in item &&
        (item.verificationLevel === "demonstration" || item.verificationLevel === "personal_data"),
    );
  } catch {
    return [];
  }
}

export function readProfessionalOnboarding(email: string) {
  const normalizedEmail = email.trim().toLocaleLowerCase("pt-BR");
  if (!normalizedEmail) return null;
  return (
    readAll().find((item) => item.email.toLocaleLowerCase("pt-BR") === normalizedEmail) ?? null
  );
}

export function saveProfessionalOnboarding(email: string) {
  if (typeof window === "undefined") return;
  const normalizedEmail = email.trim().toLocaleLowerCase("pt-BR");
  const status: ProfessionalOnboardingStatus = {
    email: normalizedEmail,
    personalDataSubmitted: true,
    faceCaptureCompleted: false,
    secondFactorCompleted: false,
    verificationLevel: "personal_data",
    completedAt: new Date().toISOString(),
  };
  const records = readAll().filter(
    (item) => item.email.toLocaleLowerCase("pt-BR") !== normalizedEmail,
  );
  window.localStorage.setItem(storageKey, JSON.stringify([status, ...records]));
  window.dispatchEvent(new Event(changeEvent));
}

export function subscribeToProfessionalOnboarding(listener: () => void) {
  if (typeof window === "undefined") return () => undefined;
  window.addEventListener(changeEvent, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(changeEvent, listener);
    window.removeEventListener("storage", listener);
  };
}
