import { type CategorySlug, type Professional } from "@/lib/demo-data";
import { hasProfessionalAccess, readSession, saveSession } from "@/lib/auth-store";
import { applyCustomerReviews, subscribeToClientReviews } from "@/lib/review-store";
import {
  isProfessionalSuspended,
  readSecurityState,
  subscribeToSecurityState,
} from "@/lib/security-store";

export type AdvertisedService = {
  id: string;
  name: string;
  category?: CategorySlug;
  price: number | null;
  duration: string;
  description: string;
  active: boolean;
};

export type EditableProfessionalProfile = Pick<
  Professional,
  "name" | "role" | "category" | "neighborhood" | "radiusKm" | "bio" | "online" | "priceFrom"
> & {
  phone: string;
  email: string;
  photoUrl: string;
  latitude?: number;
  longitude?: number;
};

const profileKey = "servix.pro-profile";
const servicesKey = "servix.pro-services";
const profileChanged = "servix:professional-profile-change";
export const fallbackProfile: EditableProfessionalProfile = {
  name: "",
  role: "Profissional",
  category: "outros",
  neighborhood: "",
  radiusKm: 0,
  bio: "",
  online: false,
  priceFrom: 0,
  phone: "",
  email: "",
  photoUrl: "",
};

export function readProfessionalProfile(): EditableProfessionalProfile {
  if (typeof window === "undefined") return fallbackProfile;
  try {
    const raw = window.localStorage.getItem(profileKey);
    return raw
      ? { ...fallbackProfile, ...(JSON.parse(raw) as Partial<EditableProfessionalProfile>) }
      : fallbackProfile;
  } catch {
    return fallbackProfile;
  }
}

export function saveProfessionalProfile(profile: EditableProfessionalProfile) {
  if (typeof window !== "undefined") {
    window.localStorage.setItem(profileKey, JSON.stringify(profile));
    const session = readSession();
    if (
      session &&
      hasProfessionalAccess(session) &&
      (session.name !== profile.name || session.email !== profile.email)
    ) {
      saveSession({ ...session, name: profile.name, email: profile.email });
    }
    window.dispatchEvent(new Event(profileChanged));
  }
}

export function subscribeToProfessionalProfile(listener: () => void) {
  if (typeof window === "undefined") return () => undefined;
  window.addEventListener(profileChanged, listener);
  window.addEventListener("storage", listener);
  const unsubscribeReviews = subscribeToClientReviews(listener);
  const unsubscribeSecurity = subscribeToSecurityState(listener);
  return () => {
    window.removeEventListener(profileChanged, listener);
    window.removeEventListener("storage", listener);
    unsubscribeReviews();
    unsubscribeSecurity();
  };
}

export function readAdvertisedServices(): AdvertisedService[] {
  const fallbackCategory = readProfessionalProfile().category;
  if (typeof window === "undefined") return [];
  try {
    const saved = window.localStorage.getItem(servicesKey);
    if (saved) {
      const services = JSON.parse(saved) as AdvertisedService[];
      return Array.isArray(services)
        ? services.map((service) => ({
            ...service,
            category: service.category ?? fallbackCategory,
          }))
        : [];
    }
    return [];
  } catch {
    return [];
  }
}

export function saveAdvertisedServices(services: AdvertisedService[]) {
  if (typeof window !== "undefined") {
    window.localStorage.setItem(servicesKey, JSON.stringify(services));
    window.dispatchEvent(new Event(profileChanged));
  }
}

export function readProfessionalCategories(): CategorySlug[] {
  const profile = readProfessionalProfile();
  const serviceCategories = readAdvertisedServices()
    .filter((service) => service.active)
    .map((service) => service.category ?? profile.category);
  return [...new Set(serviceCategories)];
}

export function getClientFacingProfessional(): Professional {
  const profile = readProfessionalProfile();
  const savedServices = readAdvertisedServices();
  const hasSavedServiceList =
    typeof window !== "undefined" && window.localStorage.getItem(servicesKey) !== null;
  const services = hasSavedServiceList
    ? savedServices
        .filter((service) => service.active)
        .map(({ name, price, duration, category, description }) => ({
          name,
          price,
          duration,
          category: category ?? profile.category,
          description,
        }))
    : [];
  return applyCustomerReviews({
    id: "current-user",
    rating: 0,
    reviews: 0,
    jobs: 0,
    years: 0,
    etaMin: 0,
    verified: false,
    availability: "Disponibilidade não informada",
    distanceKm: Number.POSITIVE_INFINITY,
    portfolio: [],
    reviewList: [],
    hue: 0,
    ...profile,
    ...(profile.latitude !== undefined ? { latitude: profile.latitude } : {}),
    ...(profile.longitude !== undefined ? { longitude: profile.longitude } : {}),
    initials: profile.name
      .split(" ")
      .map((part) => part[0])
      .slice(0, 2)
      .join("")
      .toUpperCase(),
    services,
  });
}

export function getClientFacingProfessionals(): Professional[] {
  if (typeof window === "undefined" || window.localStorage.getItem(profileKey) === null) return [];
  const own = getClientFacingProfessional();
  const accounts = readSecurityState().accounts;
  if (!hasProfessionalAccess(readSession()) || isProfessionalSuspended(own.id)) return [];
  const account = accounts.find((item) => item.professionalId === own.id);
  return [account ? { ...own, verified: account.verified } : own].filter(
    (profile) => profile.services.length > 0 && !!profile.name.trim(),
  );
}

export function getClientFacingProfessionalById(id: string): Professional | undefined {
  const own = getClientFacingProfessional();
  if (id !== own.id || !getClientFacingProfessionals().length || isProfessionalSuspended(own.id))
    return undefined;
  const profile = own;
  const account = readSecurityState().accounts.find((item) => item.professionalId === own.id);
  return account ? { ...profile, verified: account.verified } : profile;
}
