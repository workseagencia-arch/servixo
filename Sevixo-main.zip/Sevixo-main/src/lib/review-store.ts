import {
  readBookings,
  myOrders,
  professionals,
  type Professional,
  type Review,
} from "@/lib/demo-data";
import { readSession } from "@/lib/auth-store";

export type CustomerReview = Review & {
  id: string;
  bookingId: string;
  proId: string;
  verifiedPurchase: true;
  createdAt: string;
};

const storageKey = "servix.client-reviews";
const changeEvent = "servix:client-reviews-change";

export function readClientReviews(): CustomerReview[] {
  if (typeof window === "undefined") return [];
  try {
    const saved = window.localStorage.getItem(storageKey);
    const reviews = saved ? (JSON.parse(saved) as CustomerReview[]) : [];
    return Array.isArray(reviews) ? reviews : [];
  } catch {
    return [];
  }
}

export function subscribeToClientReviews(listener: () => void) {
  if (typeof window === "undefined") return () => undefined;
  window.addEventListener(changeEvent, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(changeEvent, listener);
    window.removeEventListener("storage", listener);
  };
}

export function hasReviewForBooking(bookingId: string) {
  return readClientReviews().some((review) => review.bookingId === bookingId);
}

export function addCustomerReview(bookingId: string, rating: number, text: string) {
  const order = myOrders.find((item) => item.id === bookingId);
  const booking = readBookings().find((item) => item.id === bookingId);
  const session = readSession();
  if (
    !session ||
    (booking?.ownerEmail &&
      booking.ownerEmail.toLocaleLowerCase("pt-BR") !== session.email.toLocaleLowerCase("pt-BR"))
  )
    return false;
  const proId = order?.proId ?? booking?.proId;
  if (
    (!order && !booking) ||
    (order ?? booking)!.status !== "Concluído" ||
    !proId ||
    order?.rated ||
    hasReviewForBooking(bookingId) ||
    typeof window === "undefined"
  )
    return false;
  const validProfessional =
    professionals.some((item) => item.id === proId) ||
    (proId === "current-user" && window.localStorage.getItem("servix.pro-profile") !== null);
  if (!validProfessional) return false;

  const createdAt = new Date().toISOString();
  const author = readSession()?.name || "Cliente ServiX";
  const review: CustomerReview = {
    id: `review-${Date.now()}`,
    bookingId,
    proId,
    author,
    rating: Math.min(5, Math.max(1, Math.round(rating))),
    text: text.trim(),
    service: order?.title ?? booking!.service,
    date: "hoje",
    verifiedPurchase: true,
    createdAt,
  };

  const reviews = readClientReviews();
  window.localStorage.setItem(storageKey, JSON.stringify([review, ...reviews]));
  if (order) order.rated = true;
  window.dispatchEvent(new Event(changeEvent));
  return true;
}

export function applyCustomerReviews(pro: Professional): Professional {
  const additions = readClientReviews()
    .filter((review) => review.proId === pro.id)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  if (!additions.length) return pro;

  const total = pro.reviews + additions.length;
  const rating =
    (pro.rating * pro.reviews + additions.reduce((sum, review) => sum + review.rating, 0)) / total;
  return {
    ...pro,
    rating: Math.round(rating * 10) / 10,
    reviews: total,
    reviewList: [...additions, ...pro.reviewList],
  };
}

export function readReviewForProfessional(proId: string) {
  const pro = professionals.find((item) => item.id === proId);
  return pro ? applyCustomerReviews(pro) : undefined;
}
