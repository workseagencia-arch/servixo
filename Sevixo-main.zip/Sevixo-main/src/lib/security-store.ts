import {
  type DemoAdminAccount,
  type DemoModerationReport,
  type DemoAccountStatus,
  type ModerationReportStatus,
} from "@/lib/demo-data";

export type AdminAuditEvent = {
  id: string;
  actor: string;
  action: string;
  subject: string;
  createdAt: string;
};

export type SecurityState = {
  accounts: DemoAdminAccount[];
  reports: DemoModerationReport[];
  audit: AdminAuditEvent[];
};

const storageKey = "servix.security-console";
const changeEvent = "servix:security-console-change";

export function readSecurityState(): SecurityState {
  if (typeof window === "undefined") return { accounts: [], reports: [], audit: [] };
  try {
    const raw = window.localStorage.getItem(storageKey);
    if (!raw) return { accounts: [], reports: [], audit: [] };
    const value = JSON.parse(raw) as Partial<SecurityState>;
    return {
      accounts: Array.isArray(value.accounts) ? value.accounts.filter((account) => !/^account-(client-marianas|carlos|juliana|andre|rafael|company|staff)$/.test(account.id)) : [],
      reports: Array.isArray(value.reports) ? value.reports.filter((report) => !report.id.startsWith("report-demo-")) : [],
      audit: Array.isArray(value.audit) ? value.audit : [],
    };
  } catch {
    return { accounts: [], reports: [], audit: [] };
  }
}

function save(state: SecurityState) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(storageKey, JSON.stringify(state));
  window.dispatchEvent(new Event(changeEvent));
}

function addAudit(state: SecurityState, action: string, subject: string, actor = "Equipe ServiX"): AdminAuditEvent[] {
  const event: AdminAuditEvent = {
    id: `audit-${Date.now()}-${Math.random().toString(36).slice(2, 7)}`,
    actor,
    action,
    subject,
    createdAt: new Date().toISOString(),
  };
  return [event, ...state.audit].slice(0, 100);
}

export function recordAdminAudit(action: string, subject: string, actor = "Equipe ServiX") {
  const state = readSecurityState();
  save({ ...state, audit: addAudit(state, action, subject, actor) });
}

export function subscribeToSecurityState(listener: () => void) {
  if (typeof window === "undefined") return () => undefined;
  window.addEventListener(changeEvent, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(changeEvent, listener);
    window.removeEventListener("storage", listener);
  };
}

export function setDemoAccountStatus(id: string, status: DemoAccountStatus) {
  const state = readSecurityState();
  const account = state.accounts.find((item) => item.id === id);
  if (!account || account.role === "moderador") return false;
  save({
    ...state,
    accounts: state.accounts.map((item) => item.id === id ? { ...item, status } : item),
    audit: addAudit(state, status === "suspensa" ? "Conta suspensa" : "Acesso restabelecido", account.name),
  });
  return true;
}

export function setDemoAccountVerified(id: string, verified: boolean) {
  const state = readSecurityState();
  const account = state.accounts.find((item) => item.id === id);
  if (!account || account.role !== "profissional") return false;
  save({
    ...state,
    accounts: state.accounts.map((item) => item.id === id ? { ...item, verified } : item),
    audit: addAudit(state, verified ? "Perfil profissional verificado" : "Selo de verificação removido", account.name),
  });
  return true;
}

export function setModerationReportStatus(id: string, status: ModerationReportStatus) {
  const state = readSecurityState();
  const report = state.reports.find((item) => item.id === id);
  if (!report) return false;
  save({
    ...state,
    reports: state.reports.map((item) => item.id === id ? { ...item, status } : item),
    audit: addAudit(state, `Denúncia ${status.replace("_", " ")}`, report.subjectName),
  });
  return true;
}

export function createModerationReport(report: Omit<DemoModerationReport, "id" | "status" | "createdAt">) {
  const state = readSecurityState();
  const next: DemoModerationReport = {
    ...report,
    id: `report-${Date.now()}`,
    status: "aberta",
    createdAt: new Date().toISOString(),
  };
  save({
    ...state,
    reports: [next, ...state.reports],
    audit: addAudit(state, "Denúncia recebida", report.subjectName, "Cliente ServiX"),
  });
  return next;
}

export function isProfessionalSuspended(professionalId: string) {
  const account = readSecurityState().accounts.find((item) => item.professionalId === professionalId);
  return account?.status === "suspensa";
}

export function isEmailAccountSuspended(email: string) {
  return readSecurityState().accounts.some((item) => item.email.toLocaleLowerCase("pt-BR") === email.toLocaleLowerCase("pt-BR") && item.status === "suspensa");
}
