export type ThemeMode = "light" | "dark";

const themeKey = "servix.theme";
const themeChanged = "servix:theme-change";

export function applyThemeMode(mode: ThemeMode) {
  if (typeof document === "undefined") return;
  document.documentElement.classList.toggle("dark", mode === "dark");
  document.documentElement.style.colorScheme = mode;
}

export function readThemeMode(): ThemeMode {
  if (typeof window === "undefined") return "light";
  return window.localStorage.getItem(themeKey) === "dark" ? "dark" : "light";
}

export function setThemeMode(mode: ThemeMode) {
  if (typeof window === "undefined") return;
  window.localStorage.setItem(themeKey, mode);
  applyThemeMode(mode);
  window.dispatchEvent(new Event(themeChanged));
}

export function subscribeToTheme(listener: () => void) {
  if (typeof window === "undefined") return () => undefined;
  window.addEventListener(themeChanged, listener);
  window.addEventListener("storage", listener);
  return () => {
    window.removeEventListener(themeChanged, listener);
    window.removeEventListener("storage", listener);
  };
}
