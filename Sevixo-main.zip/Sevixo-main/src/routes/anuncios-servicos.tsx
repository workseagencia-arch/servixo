import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState, type FormEvent } from "react";
import { z } from "zod";
import {
  ArrowRight,
  ArrowUpRight,
  BadgeCheck,
  Check,
  ChevronDown,
  Clock3,
  MapPin,
  Plus,
  Search,
  SlidersHorizontal,
  Wrench,
  X,
} from "lucide-react";
import { Avatar, CategoryIcon, Rating, ResilientImage } from "@/components/app/ui-bits";
import { Pagination } from "@/components/app/pagination";
import { HireDialog } from "@/components/app/booking-dialogs";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog";
import {
  categories,
  brl,
  categoryName,
  type AdCampaign,
  type CategorySlug,
  type Professional,
} from "@/lib/demo-data";
import {
  campaignTargetsChannel,
  isCampaignDeliverable,
  readAdCampaigns,
  recordAdClick,
  recordAdImpression,
  subscribeToAdCampaigns,
} from "@/lib/advertising-store";
import {
  getClientFacingProfessionalById,
  getClientFacingProfessionals,
  subscribeToProfessionalProfile,
} from "@/lib/professional-store";
import { subscribeToSession } from "@/lib/auth-store";
import {
  distanceBetweenKm,
  readDeviceLocation,
  subscribeToLocation,
  type DeviceLocation,
} from "@/lib/location-store";

const pageSize = 10;
const searchSchema = z.object({ q: z.string().optional(), cat: z.string().optional() });

export const Route = createFileRoute("/anuncios-servicos")({
  validateSearch: (search: Record<string, unknown>) => searchSchema.parse(search),
  head: () => ({
    meta: [
      { title: "Anúncios e serviços — ServiX" },
      {
        name: "description",
        content: "Encontre serviços, conheça os profissionais e combine os detalhes pela ServiX.",
      },
    ],
  }),
  component: ServiceAdsPage,
});

const normalize = (value: string) =>
  value
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .toLocaleLowerCase("pt-BR");
type ListedService = {
  id: string;
  pro: Professional;
  service: Professional["services"][number];
  category: CategorySlug;
};

function ServiceAdsPage() {
  const { q, cat } = Route.useSearch();
  const navigate = useNavigate({ from: "/anuncios-servicos" });
  const [text, setText] = useState(q ?? "");
  // Match the server's empty state before reading published services in the browser.
  const [pros, setPros] = useState<Professional[]>([]);
  const [campaigns, setCampaigns] = useState<AdCampaign[]>([]);
  const [origin, setOrigin] = useState<DeviceLocation | null>(null);
  const [selectedService, setSelectedService] = useState<ListedService | null>(null);
  const [sort, setSort] = useState<"relevance" | "price" | "rating">("relevance");
  const [page, setPage] = useState(1);
  const resultsHeading = useRef<HTMLHeadingElement>(null);

  useEffect(() => {
    const refresh = () => setPros(getClientFacingProfessionals());
    refresh();
    const unsubscribeProfile = subscribeToProfessionalProfile(refresh);
    const unsubscribeSession = subscribeToSession(refresh);
    return () => {
      unsubscribeProfile();
      unsubscribeSession();
    };
  }, []);
  useEffect(() => {
    const refresh = () => setCampaigns(readAdCampaigns());
    refresh();
    return subscribeToAdCampaigns(refresh);
  }, []);
  useEffect(() => {
    const refresh = () => setOrigin(readDeviceLocation("cliente"));
    refresh();
    return subscribeToLocation(refresh);
  }, []);
  useEffect(() => setText(q ?? ""), [q]);
  useEffect(() => setPage(1), [text, cat]);

  const selectedCategory = categories.find((item) => item.slug === cat);
  const services = useMemo(
    () =>
      pros.flatMap((pro) =>
        pro.services.map((service, index) => ({
          id: `${pro.id}-${index}-${service.name}`,
          pro,
          service,
          category: service.category ?? pro.category,
        })),
      ),
    [pros],
  );
  const filteredServices = useMemo(() => {
    const terms = normalize(text).split(/\s+/).filter(Boolean);
    return services.filter(({ pro, service, category }) => {
      if (cat && category !== cat) return false;
      const searchable = normalize(
        [
          pro.name,
          pro.role,
          pro.neighborhood,
          pro.bio,
          service.name,
          service.description ?? "",
          categoryName(category),
        ].join(" "),
      );
      return terms.every((term) => searchable.includes(term));
    });
  }, [services, text, cat]);
  const sortedServices = useMemo(() => {
    if (sort === "price")
      return [...filteredServices].sort((a, b) => {
        if (a.service.price === null && b.service.price === null) return 0;
        if (a.service.price === null) return 1;
        if (b.service.price === null) return -1;
        return a.service.price - b.service.price;
      });
    if (sort === "rating") return [...filteredServices].sort((a, b) => b.pro.rating - a.pro.rating);
    return filteredServices;
  }, [filteredServices, sort]);
  const currentPage = Math.min(page, Math.max(1, Math.ceil(sortedServices.length / pageSize)));
  const visibleServices = sortedServices.slice(
    (currentPage - 1) * pageSize,
    currentPage * pageSize,
  );
  const hasFilters = Boolean(text.trim() || cat);
  const sponsoredCampaigns = useMemo(
    () =>
      campaigns
        .filter((campaign) => {
          if (!isCampaignDeliverable(campaign) || !campaignTargetsChannel(campaign, "servicos"))
            return false;
          if (cat && campaign.category && campaign.category !== cat) return false;
          if (
            origin &&
            distanceBetweenKm(origin, {
              latitude: campaign.latitude,
              longitude: campaign.longitude,
            }) > campaign.radiusKm
          )
            return false;
          return (
            campaign.advertiserType === "empresa" ||
            (!!campaign.advertiserId && pros.some((pro) => pro.id === campaign.advertiserId))
          );
        })
        .slice(0, 3),
    [campaigns, cat, origin, pros],
  );

  const changeCategory = (category?: CategorySlug) => {
    void navigate({ search: { q: text.trim() || undefined, cat: category } });
  };
  const clearSearch = () => {
    setText("");
    void navigate({ search: { cat } });
  };
  const clearFilters = () => {
    setText("");
    void navigate({ search: {} });
  };
  const submitSearch = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    void navigate({ search: { q: text.trim() || undefined, cat } });
    resultsHeading.current?.scrollIntoView({ block: "start" });
  };

  return (
    <div className="min-w-0 space-y-7 lg:space-y-9">
      <header className="flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <h1 className="font-display text-2xl font-bold tracking-tight sm:text-3xl">
            Anúncios e serviços
          </h1>
          <p className="mt-2 text-sm text-muted-foreground">
            Serviços para sua casa, sua rotina e seu negócio.
          </p>
        </div>
        <Link
          to="/profissionais"
          className="inline-flex w-fit items-center gap-2 py-1 text-sm font-semibold text-primary hover:underline underline-offset-4"
        >
          Explorar profissionais <ArrowUpRight className="h-4 w-4" />
        </Link>
      </header>

      <section
        aria-label="Busca de serviços"
        className="overflow-hidden rounded-xl bg-primary text-primary-foreground"
      >
        <div className="p-5 sm:p-7 lg:px-9 lg:py-8">
          <div className="mb-6 flex flex-col gap-3 md:flex-row md:items-end md:justify-between">
            <div>
              <p className="mb-3 flex items-center gap-2 text-xs font-semibold text-brand">
                <span className="h-1.5 w-1.5 rounded-full bg-brand" /> Encontre sua próxima solução
              </p>
              <h2 className="font-display text-2xl font-bold tracking-tight sm:text-3xl">
                O que você precisa resolver?
              </h2>
            </div>
            <p className="max-w-xs text-sm leading-relaxed text-primary-foreground/75">
              Conheça o serviço e quem faz.
              <br className="hidden md:block" /> Combine os detalhes antes de contratar.
            </p>
          </div>
          <div className="grid min-w-0 gap-3 lg:grid-cols-[minmax(0,1fr)_18rem]">
            <form
              onSubmit={submitSearch}
              className="flex min-w-0 items-center gap-2 rounded-lg border border-transparent bg-card p-1.5 text-card-foreground focus-within:border-brand focus-within:ring-2 focus-within:ring-brand/40"
            >
              <Search className="ml-2 h-5 w-5 shrink-0 text-muted-foreground" />
              <input
                id="service-search"
                type="search"
                value={text}
                onChange={(event) => setText(event.target.value)}
                placeholder="Qual serviço você procura?"
                aria-label="Pesquisar serviços"
                className="min-w-0 flex-1 bg-transparent py-3 text-sm outline-none sm:text-base"
              />
              <button
                type="submit"
                className="inline-flex shrink-0 items-center gap-2 rounded-md bg-brand px-3 py-3 text-sm font-bold text-brand-foreground transition-colors hover:bg-brand/85 sm:px-5"
              >
                Buscar <ArrowRight className="hidden h-4 w-4 sm:block" />
              </button>
            </form>
            <CategoryPicker selected={selectedCategory?.slug} onSelect={changeCategory} />
          </div>
        </div>
        <div className="flex flex-wrap items-center gap-x-6 gap-y-2 border-t border-primary-foreground/15 px-5 py-3 text-xs text-primary-foreground/80 sm:px-7 lg:px-9">
          <span>Pesquise por serviço, profissional ou região</span>
          <span className="hidden sm:inline-flex sm:items-center sm:gap-2">
            <span className="h-1 w-1 rounded-full bg-brand" /> Categorias em um só lugar
          </span>
        </div>
      </section>

      <div className="grid min-w-0 items-start gap-7 xl:grid-cols-[minmax(0,1fr)_17rem] xl:gap-8">
        <div className="min-w-0 space-y-7">
          {sponsoredCampaigns.length > 0 && (
            <section aria-label="Destaques patrocinados" className="space-y-3">
              <div className="flex flex-wrap items-center justify-between gap-2">
                <h2 className="text-base font-bold">Destaques patrocinados</h2>
                <span className="text-xs text-muted-foreground">Publicidade</span>
              </div>
              <div
                className={`grid min-w-0 gap-3 ${sponsoredCampaigns.length > 1 ? "sm:grid-cols-2" : ""} ${sponsoredCampaigns.length === 3 ? "lg:grid-cols-3" : ""}`}
              >
                {sponsoredCampaigns.map((campaign) => (
                  <CampaignCard
                    key={campaign.id}
                    campaign={campaign}
                    compact={sponsoredCampaigns.length === 1}
                  />
                ))}
              </div>
            </section>
          )}

          <section aria-labelledby="service-results-heading" className="min-w-0 space-y-5">
            <div className="flex flex-col gap-3 border-b border-border pb-4 sm:flex-row sm:items-center sm:justify-between">
              <div>
                <h2
                  id="service-results-heading"
                  ref={resultsHeading}
                  className="scroll-mt-48 text-lg font-bold sm:text-xl"
                >
                  {selectedCategory?.name ?? "Explore os serviços"}
                </h2>
                <p role="status" aria-live="polite" className="mt-1 text-xs text-muted-foreground">
                  {sortedServices.length}{" "}
                  {sortedServices.length === 1 ? "serviço disponível" : "serviços disponíveis"}
                  {hasFilters ? " para sua busca" : ""}
                </p>
              </div>
              <label className="flex w-fit max-w-full items-center gap-2 text-xs text-muted-foreground">
                Ordenar por
                <select
                  aria-label="Ordenar serviços"
                  value={sort}
                  onChange={(event) => {
                    setSort(event.target.value as typeof sort);
                    setPage(1);
                  }}
                  className="min-w-0 cursor-pointer rounded-md border border-border bg-card px-3 py-2.5 text-xs font-semibold text-foreground outline-none focus-visible:ring-2 focus-visible:ring-ring"
                >
                  <option value="relevance">Relevância</option>
                  <option value="price">Menor valor</option>
                  <option value="rating">Melhor avaliação</option>
                </select>
              </label>
            </div>
            {hasFilters && (
              <div className="flex flex-wrap items-center gap-2" aria-label="Filtros aplicados">
                {cat && (
                  <button
                    type="button"
                    onClick={() => changeCategory()}
                    aria-label="Remover filtro de categoria"
                    className="inline-flex max-w-full items-center gap-2 rounded-md border border-primary/20 bg-primary/5 px-3 py-2 text-xs font-semibold text-primary"
                  >
                    <span className="min-w-0 break-words">{selectedCategory?.name ?? cat}</span>
                    <X className="h-3.5 w-3.5 shrink-0" />
                  </button>
                )}
                {text.trim() && (
                  <button
                    type="button"
                    onClick={clearSearch}
                    aria-label="Remover pesquisa"
                    className="inline-flex max-w-full items-center gap-2 rounded-md border border-border bg-card px-3 py-2 text-xs font-semibold"
                  >
                    <span className="min-w-0 break-all">“{text.trim()}”</span>
                    <X className="h-3.5 w-3.5 shrink-0" />
                  </button>
                )}
                <button
                  type="button"
                  onClick={clearFilters}
                  className="px-1 py-2 text-xs font-semibold text-muted-foreground underline underline-offset-4 hover:text-primary"
                >
                  Limpar tudo
                </button>
              </div>
            )}
            {visibleServices.length > 0 ? (
              <div className="grid min-w-0 gap-4 md:grid-cols-2" aria-label="Lista de serviços">
                {visibleServices.map((item) => (
                  <ServiceCard key={item.id} item={item} onOpen={() => setSelectedService(item)} />
                ))}
              </div>
            ) : (
              <div className="flex min-h-80 flex-col items-center justify-center rounded-xl border border-border bg-card px-5 py-10 text-center sm:px-10 sm:py-14">
                <span className="mb-5 grid h-14 w-14 place-items-center rounded-xl border border-primary/10 bg-secondary/60 text-primary">
                  <Search className="h-6 w-6" />
                </span>
                <h3 className="max-w-md text-xl font-bold tracking-tight">
                  {hasFilters ? "Não encontramos esse serviço" : "Novos serviços vão aparecer aqui"}
                </h3>
                <p className="mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
                  {hasFilters
                    ? "Experimente outro termo ou altere a categoria para encontrar mais opções."
                    : "Este espaço reúne os anúncios publicados pelos profissionais. Você também pode explorar os perfis ou publicar o que precisa."}
                </p>
                {hasFilters ? (
                  <button
                    type="button"
                    onClick={clearFilters}
                    className="mt-6 inline-flex items-center gap-2 rounded-md bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
                  >
                    Ver todos os serviços <ArrowRight className="h-4 w-4" />
                  </button>
                ) : (
                  <Link
                    to="/profissionais"
                    className="mt-6 inline-flex items-center gap-2 rounded-md bg-primary px-5 py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
                  >
                    Encontrar profissionais <ArrowRight className="h-4 w-4" />
                  </Link>
                )}
              </div>
            )}
            <Pagination
              currentPage={currentPage}
              totalItems={sortedServices.length}
              pageSize={pageSize}
              onPageChange={(nextPage) => {
                setPage(nextPage);
                resultsHeading.current?.scrollIntoView({ block: "start" });
              }}
              label="serviços"
            />
          </section>
        </div>

        <aside
          aria-label="Outras formas de encontrar serviços"
          className="grid min-w-0 gap-5 sm:grid-cols-2 xl:grid-cols-1"
        >
          <div className="rounded-xl border border-border bg-secondary/45 p-5 lg:p-6">
            <span className="mb-4 grid h-10 w-10 place-items-center rounded-lg border border-primary/10 bg-card text-primary">
              <Plus className="h-5 w-5" />
            </span>
            <h2 className="text-lg font-bold leading-snug">Precisa de algo específico?</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Conte o que precisa e deixe os profissionais encontrarem seu pedido.
            </p>
            <Link
              to="/vagas"
              className="mt-5 inline-flex w-full items-center justify-between gap-2 rounded-md bg-primary px-4 py-3 text-sm font-semibold text-primary-foreground hover:bg-primary/90"
            >
              Publicar uma vaga <ArrowRight className="h-4 w-4 shrink-0" />
            </Link>
          </div>
          <div className="rounded-xl border border-border bg-card p-5 lg:p-6">
            <h2 className="text-sm font-bold">Do anúncio à contratação</h2>
            <ol className="mt-5 space-y-5">
              {[
                ["Conheça o serviço", "Veja o que está incluído e o valor informado."],
                ["Confira o profissional", "Consulte o perfil e as avaliações dos clientes."],
                ["Converse e combine", "Acerte os detalhes do trabalho pelo chat."],
              ].map(([title, detail], index) => (
                <li key={title} className="flex gap-3">
                  <span className="grid h-6 w-6 shrink-0 place-items-center rounded-md bg-muted text-xs font-bold text-primary">
                    {index + 1}
                  </span>
                  <div>
                    <h3 className="text-xs font-bold">{title}</h3>
                    <p className="mt-1 text-xs leading-relaxed text-muted-foreground">{detail}</p>
                  </div>
                </li>
              ))}
            </ol>
            <div className="mt-6 border-t border-border pt-5">
              <p className="text-xs text-muted-foreground">Você oferece serviços?</p>
              <Link
                to="/pro/servicos"
                className="mt-2 inline-flex items-center gap-2 text-sm font-semibold text-primary hover:underline underline-offset-4"
              >
                Publicar meu anúncio <ArrowUpRight className="h-4 w-4" />
              </Link>
            </div>
          </div>
        </aside>
      </div>

      {selectedService && (
        <HireDialog
          pro={selectedService.pro}
          service={{
            ...selectedService.service,
            category: selectedService.category,
            description: selectedService.service.description || selectedService.pro.bio,
          }}
          open
          onOpenChange={(open) => !open && setSelectedService(null)}
        />
      )}
    </div>
  );
}

function CategoryPicker({
  selected,
  onSelect,
}: {
  selected: CategorySlug | undefined;
  onSelect: (category?: CategorySlug) => void;
}) {
  const [open, setOpen] = useState(false);
  const [query, setQuery] = useState("");
  const selectedCategory = categories.find((category) => category.slug === selected);
  const terms = normalize(query.trim()).split(/\s+/).filter(Boolean);
  const matchingCategories = categories.filter((category) =>
    terms.every((term) => normalize(category.name).includes(term)),
  );
  const select = (category?: CategorySlug) => {
    onSelect(category);
    setOpen(false);
    setQuery("");
  };

  return (
    <Dialog
      open={open}
      onOpenChange={(nextOpen) => {
        setOpen(nextOpen);
        if (!nextOpen) setQuery("");
      }}
    >
      <DialogTrigger asChild>
        <button
          type="button"
          aria-label={`Escolher categoria: ${selectedCategory?.name ?? "Todas as categorias"}`}
          className="flex min-w-0 items-center gap-3 rounded-lg border border-primary-foreground/30 bg-primary-foreground/5 px-4 py-3 text-left transition-colors hover:bg-primary-foreground/10 focus-visible:ring-2 focus-visible:ring-brand"
        >
          <SlidersHorizontal className="h-5 w-5 shrink-0 text-brand" />
          <span className="min-w-0 flex-1">
            <span className="block text-[11px] text-primary-foreground/65">
              Filtrar por categoria
            </span>
            <span className="mt-0.5 block truncate text-sm font-semibold">
              {selectedCategory?.name ?? "Todas as categorias"}
            </span>
          </span>
          <ChevronDown className="h-4 w-4 shrink-0 text-primary-foreground/70" />
        </button>
      </DialogTrigger>
      <DialogContent className="flex max-h-[min(88dvh,44rem)] w-[calc(100%-2rem)] flex-col gap-0 overflow-hidden rounded-xl bg-card p-0 sm:max-w-2xl">
        <DialogHeader className="shrink-0 border-b border-border p-5 pr-12 text-left sm:p-6">
          <DialogTitle className="text-xl font-bold">Qual categoria você procura?</DialogTitle>
          <DialogDescription className="pt-1">
            Escolha uma opção para ver os serviços correspondentes.
          </DialogDescription>
        </DialogHeader>
        <div className="shrink-0 px-5 pt-5 sm:px-6">
          <div className="flex items-center gap-3 rounded-lg border border-input bg-background px-3 focus-within:border-primary focus-within:ring-2 focus-within:ring-primary/10">
            <Search className="h-4 w-4 shrink-0 text-muted-foreground" />
            <input
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder="Pesquisar uma categoria"
              aria-label="Pesquisar categoria"
              className="min-w-0 flex-1 bg-transparent py-3 text-sm outline-none"
            />
          </div>
        </div>
        <div className="min-h-0 overflow-y-auto overscroll-contain p-5 sm:p-6">
          {!query.trim() && (
            <button
              type="button"
              aria-pressed={!selected}
              onClick={() => select()}
              className={`mb-3 flex w-full items-center gap-3 rounded-lg border p-3 text-left transition-colors ${!selected ? "border-primary/35 bg-secondary/60" : "border-border hover:bg-muted"}`}
            >
              <Wrench className="h-5 w-5 shrink-0 text-primary" />
              <span className="flex-1 text-sm font-semibold">Todas as categorias</span>
              {!selected && <Check className="h-4 w-4 text-primary" />}
            </button>
          )}
          <div className="grid min-w-0 gap-2 sm:grid-cols-2">
            {matchingCategories.map((category) => (
              <button
                key={category.slug}
                type="button"
                aria-pressed={selected === category.slug}
                onClick={() => select(category.slug)}
                className={`flex min-h-16 min-w-0 items-center gap-3 rounded-lg border p-3 text-left transition-colors ${selected === category.slug ? "border-primary/35 bg-secondary/60" : "border-border hover:border-primary/30 hover:bg-muted/50"}`}
              >
                <span className="grid h-9 w-9 shrink-0 place-items-center rounded-md bg-muted text-primary">
                  <CategoryIcon slug={category.slug} className="h-4 w-4" />
                </span>
                <span className="min-w-0 flex-1 text-sm font-semibold">{category.name}</span>
                {selected === category.slug && <Check className="h-4 w-4 shrink-0 text-primary" />}
              </button>
            ))}
          </div>
          {matchingCategories.length === 0 && (
            <p role="status" className="px-4 py-8 text-center text-sm text-muted-foreground">
              Nenhuma categoria encontrada. Tente outro termo.
            </p>
          )}
        </div>
      </DialogContent>
    </Dialog>
  );
}

function ServiceCard({ item, onOpen }: { item: ListedService; onOpen: () => void }) {
  const { pro, service, category } = item;
  return (
    <button
      type="button"
      aria-label={`Ver detalhes de ${service.name}`}
      onClick={onOpen}
      className="group flex min-w-0 flex-col rounded-xl border border-border bg-card p-5 text-left transition-[border-color,box-shadow] hover:border-primary/35 hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:p-6"
    >
      <span className="flex items-center gap-2 text-xs font-semibold text-muted-foreground">
        <CategoryIcon slug={category} className="h-4 w-4 shrink-0 text-primary" />
        {categoryName(category)}
      </span>
      <span className="mt-3 break-words text-lg font-bold leading-snug text-foreground">
        {service.name}
      </span>
      <span className="mt-2 line-clamp-2 min-h-10 break-words text-sm leading-5 text-muted-foreground">
        {service.description ||
          pro.bio ||
          "Conheça os detalhes deste serviço e combine o atendimento com o profissional."}
      </span>
      {service.duration && (
        <span className="mt-3 inline-flex items-center gap-1.5 text-xs text-muted-foreground">
          <Clock3 className="h-3.5 w-3.5 shrink-0" />
          {service.duration}
        </span>
      )}
      <span className="mt-5 flex items-center gap-3 border-t border-border pt-4">
        <Avatar pro={pro} size="md" className="[&>div]:!rounded-full [&_img]:!rounded-full" />
        <span className="min-w-0 flex-1">
          <span className="flex items-center gap-1.5">
            <span className="truncate text-sm font-bold">{pro.name}</span>
            {pro.verified && (
              <BadgeCheck
                aria-label="Perfil verificado"
                className="h-4 w-4 shrink-0 text-primary"
              />
            )}
          </span>
          {pro.neighborhood && (
            <span className="mt-1 flex items-center gap-1 text-xs text-muted-foreground">
              <MapPin className="h-3 w-3 shrink-0" />
              <span className="truncate">{pro.neighborhood}</span>
            </span>
          )}
          <span className="mt-1.5 block">
            {pro.reviews > 0 ? (
              <Rating value={pro.rating} count={pro.reviews} className="text-xs" />
            ) : (
              <span className="text-[11px] text-muted-foreground">Ainda sem avaliações</span>
            )}
          </span>
        </span>
      </span>
      <span className="mt-auto flex flex-wrap items-end justify-between gap-3 pt-5">
        <span>
          <span className="block text-[11px] text-muted-foreground">
            {service.price === null ? "Valor a combinar" : "A partir de"}
          </span>
          <span className="mt-0.5 block text-xl font-bold tracking-tight">
            {service.price === null ? "Sob consulta" : brl(service.price)}
          </span>
        </span>
        <span className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2.5 text-xs font-bold text-primary transition-colors group-hover:border-primary group-hover:bg-primary group-hover:text-primary-foreground">
          Ver detalhes <ArrowUpRight className="h-3.5 w-3.5" />
        </span>
      </span>
    </button>
  );
}

function CampaignCard({ campaign, compact = false }: { campaign: AdCampaign; compact?: boolean }) {
  const pro =
    campaign.advertiserType === "profissional" && campaign.advertiserId
      ? getClientFacingProfessionalById(campaign.advertiserId)
      : undefined;
  useEffect(() => {
    recordAdImpression(campaign.id);
  }, [campaign.id]);
  const target = pro
    ? `/profissional/${pro.id}`
    : (campaign.href.startsWith("/") && !campaign.href.startsWith("//")) ||
        /^https:\/\//i.test(campaign.href)
      ? campaign.href
      : "/empresas";
  const body = (
    <>
      {!pro && (
        <div
          className={`aspect-[16/7] overflow-hidden border-b border-border bg-muted ${compact ? "sm:aspect-auto sm:h-36 sm:w-60 sm:shrink-0 sm:border-b-0 sm:border-r" : ""}`}
        >
          <ResilientImage
            src={campaign.imageUrl}
            alt={campaign.headline}
            fallbackLabel="Imagem indisponível"
            className="h-full w-full object-contain"
          />
        </div>
      )}
      <div className="min-w-0 flex-1 p-4">
        <div className="flex min-w-0 items-center gap-3">
          {pro && <Avatar pro={pro} size="sm" />}
          <div className="min-w-0">
            <p className="truncate text-xs font-semibold text-muted-foreground">
              {campaign.advertiserName}
            </p>
            <h3 className="mt-1 break-words text-sm font-bold">{campaign.headline}</h3>
          </div>
        </div>
        <p className="mt-2 line-clamp-2 break-words text-xs leading-relaxed text-muted-foreground">
          {campaign.description}
        </p>
        <span className="mt-3 inline-flex items-center gap-2 text-xs font-bold text-primary">
          {pro ? "Conhecer profissional" : "Conhecer oferta"}
          <ArrowUpRight className="h-3.5 w-3.5" />
        </span>
      </div>
    </>
  );
  const className = `group block min-w-0 overflow-hidden rounded-lg border border-border bg-card transition-colors hover:border-primary/35 ${compact ? "sm:flex sm:items-center" : ""}`;
  return target.startsWith("/") ? (
    <Link to={target as never} onClick={() => recordAdClick(campaign.id)} className={className}>
      {body}
    </Link>
  ) : (
    <a
      href={target}
      target="_blank"
      rel="noopener noreferrer"
      onClick={() => recordAdClick(campaign.id)}
      className={className}
    >
      {body}
    </a>
  );
}
