import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowRight, CalendarDays, CheckCircle2, Mail, MapPin, Phone, ShieldCheck, UserRound } from "lucide-react";
import { toast } from "sonner";
import { PageTitle } from "@/components/app/ui-bits";
import {
  hasProfessionalAccess,
  readSession,
  saveSession,
  subscribeToSession,
  type AuthSession,
} from "@/lib/auth-store";
import { readClientProfile, saveClientProfile } from "@/lib/client-profile-store";
import { readProfessionalProfile, saveProfessionalProfile } from "@/lib/professional-store";
import { saveProfessionalOnboarding } from "@/lib/professional-onboarding-store";

export const Route = createFileRoute("/ativar-profissional")({
  head: () => ({
    meta: [
      { title: "Cadastro profissional — ServiX" },
      {
        name: "description",
        content: "Complete seus dados pessoais e de contato para ativar o perfil profissional.",
      },
    ],
  }),
  component: ProfessionalRegistration,
});

const fieldsClass =
  "w-full rounded-md border border-input bg-card px-3.5 py-3 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-ring/20";

function isAdult(date: string) {
  if (!date) return false;
  const birth = new Date(`${date}T12:00:00`);
  if (Number.isNaN(birth.valueOf()) || birth > new Date()) return false;
  const today = new Date();
  let age = today.getFullYear() - birth.getFullYear();
  if (
    today.getMonth() < birth.getMonth() ||
    (today.getMonth() === birth.getMonth() && today.getDate() < birth.getDate())
  ) {
    age -= 1;
  }
  return age >= 18;
}

function ProfessionalRegistration() {
  const navigate = useNavigate();
  const [session, setSession] = useState<AuthSession | null>(readSession);
  const [sessionReady, setSessionReady] = useState(false);
  const [fullName, setFullName] = useState("");
  const [phone, setPhone] = useState("");
  const [birthDate, setBirthDate] = useState("");
  const [address, setAddress] = useState("");

  useEffect(() => {
    const refresh = () => {
      setSession(readSession());
      setSessionReady(true);
    };
    refresh();
    return subscribeToSession(refresh);
  }, []);

  useEffect(() => {
    if (!sessionReady) return;
    if (!session) {
      navigate({ to: "/entrar", search: { perfil: "cliente" }, replace: true });
      return;
    }
    const profile = readClientProfile();
    setFullName(profile.name || session.name);
    setPhone(profile.phone || readProfessionalProfile().phone || "");
    setBirthDate(profile.birthDate ?? "");
    setAddress(profile.address ?? "");
  }, [sessionReady, session, navigate]);

  const completeRegistration = () => {
    if (!session) return;
    if (fullName.trim().length < 4) {
      toast.error("Informe seu nome civil completo.");
      return;
    }
    if (phone.replace(/\D/g, "").length < 10) {
      toast.error("Informe um telefone válido para contato.");
      return;
    }
    if (!isAdult(birthDate)) {
      toast.error("Confira sua data de nascimento. O cadastro é exclusivo para maiores de 18 anos.");
      return;
    }
    if (address.trim().length < 8) {
      toast.error("Informe seu endereço completo.");
      return;
    }

    const name = fullName.trim();
    const clientProfile = readClientProfile();
    saveClientProfile({
      ...clientProfile,
      name,
      email: session.email,
      phone: phone.trim(),
      birthDate,
      address: address.trim(),
    });
    saveProfessionalProfile({
      ...readProfessionalProfile(),
      name,
      email: session.email,
      phone: phone.trim(),
    });
    saveProfessionalOnboarding(session.email);
    saveSession({ ...session, role: "cliente", professionalEnabled: true, name });
    toast.success("Perfil profissional ativado. Agora complete sua apresentação e seus serviços.");
    navigate({ to: "/pro/perfil" });
  };

  if (!sessionReady) {
    return (
      <div className="surface mx-auto max-w-2xl p-8 text-center text-sm text-muted-foreground">
        Preparando seu cadastro…
      </div>
    );
  }
  if (!session) return null;

  if (hasProfessionalAccess(session)) {
    return (
      <div className="surface mx-auto max-w-2xl p-8 text-center">
        <CheckCircle2 className="mx-auto h-9 w-9 text-status-success" />
        <h1 className="mt-3 font-display text-2xl font-bold">Perfil profissional ativo</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Sua conta já tem acesso às ferramentas profissionais.
        </p>
        <Link
          to="/pro/perfil"
          className="mt-5 inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground"
        >
          Abrir meu perfil profissional <ArrowRight className="h-4 w-4" />
        </Link>
      </div>
    );
  }

  return (
    <div className="mx-auto w-full max-w-6xl space-y-5">
      <PageTitle
        eyebrow="Cadastro complementar"
        title="Ative seu perfil profissional"
        subtitle="Confirme seus dados pessoais e de contato para começar a divulgar seus serviços pela mesma conta."
      />

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_18rem]">
        <section className="surface p-5 sm:p-7">
          <div className="mb-6 flex items-start gap-3 border-b pb-5">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-md bg-accent text-accent-foreground">
              <UserRound className="h-5 w-5" />
            </span>
            <div>
              <h2 className="font-display text-xl font-bold">Dados para seu perfil</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Se necessário, informe seu CPF ou CNPJ nos dados do perfil da conta. Ele não é solicitado nesta etapa.
              </p>
            </div>
          </div>

          <div className="grid gap-4 sm:grid-cols-2">
            <label className="space-y-1.5 text-sm font-semibold sm:col-span-2">
              Nome civil completo
              <input
                required
                value={fullName}
                onChange={(event) => setFullName(event.target.value)}
                autoComplete="name"
                placeholder="Nome e sobrenome"
                className={fieldsClass}
              />
            </label>
            <label className="space-y-1.5 text-sm font-semibold">
              <span className="flex items-center gap-1.5"><Phone className="h-3.5 w-3.5 text-muted-foreground" /> Telefone</span>
              <input
                required
                type="tel"
                value={phone}
                onChange={(event) => setPhone(event.target.value)}
                autoComplete="tel"
                placeholder="(11) 99999-9999"
                className={fieldsClass}
              />
            </label>
            <label className="space-y-1.5 text-sm font-semibold">
              <span className="flex items-center gap-1.5"><CalendarDays className="h-3.5 w-3.5 text-muted-foreground" /> Data de nascimento</span>
              <input
                required
                type="date"
                value={birthDate}
                onChange={(event) => setBirthDate(event.target.value)}
                autoComplete="bday"
                className={fieldsClass}
              />
            </label>
            <label className="space-y-1.5 text-sm font-semibold sm:col-span-2">
              <span className="flex items-center gap-1.5"><Mail className="h-3.5 w-3.5 text-muted-foreground" /> E-mail da conta</span>
              <input
                type="email"
                value={session.email}
                readOnly
                autoComplete="email"
                className={`${fieldsClass} cursor-not-allowed bg-muted/50 text-muted-foreground`}
              />
              <span className="block text-xs font-normal text-muted-foreground">Este endereço está vinculado ao seu acesso.</span>
            </label>
            <label className="space-y-1.5 text-sm font-semibold sm:col-span-2">
              <span className="flex items-center gap-1.5"><MapPin className="h-3.5 w-3.5 text-muted-foreground" /> Endereço completo</span>
              <input
                required
                value={address}
                onChange={(event) => setAddress(event.target.value)}
                autoComplete="street-address"
                placeholder="Rua, número, bairro, cidade e estado"
                className={fieldsClass}
              />
            </label>
          </div>

          <div className="mt-6 flex flex-wrap items-center justify-between gap-3 border-t pt-5">
            <p className="max-w-md text-xs leading-relaxed text-muted-foreground">
              Ao ativar, esses dados serão associados ao seu perfil da conta e usados para facilitar contato e atendimento.
            </p>
            <button
              type="button"
              onClick={completeRegistration}
              className="inline-flex items-center gap-2 rounded-md bg-primary px-5 py-3 text-sm font-bold text-primary-foreground hover:bg-primary/90"
            >
              Ativar perfil profissional <ArrowRight className="h-4 w-4" />
            </button>
          </div>
        </section>

        <aside className="surface h-fit p-5">
          <span className="grid h-10 w-10 place-items-center rounded-md bg-accent text-accent-foreground">
            <ShieldCheck className="h-5 w-5" />
          </span>
          <h2 className="mt-4 font-display font-bold">Seus dados de cadastro</h2>
          <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
            Nome, contato, nascimento e endereço completam os dados da sua conta. O e-mail vem do acesso atual.
          </p>
          <div className="mt-4 flex items-start gap-2 border-t pt-4 text-xs leading-relaxed text-muted-foreground">
            <MapPin className="mt-0.5 h-4 w-4 shrink-0 text-primary" />
            Nesta versão demonstrativa, os dados ficam salvos neste navegador.
          </div>
        </aside>
      </div>
    </div>
  );
}
