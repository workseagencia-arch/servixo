import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { z } from "zod";
import { Search, MapPin, Zap, SlidersHorizontal, FileText, ListFilter, LocateFixed } from "lucide-react";
import { toast } from "sonner";
import { categories, categoryName, type AdCampaign, type Professional } from "@/lib/demo-data";
import { Avatar, CategoryIcon, Rating, ResilientImage } from "@/components/app/ui-bits";
import { Pagination } from "@/components/app/pagination";
import { MapProfessionalSheet, ProfessionalMap } from "@/components/app/professional-map";
import { QuoteDialog } from "@/components/app/booking-dialogs";
import { getClientFacingProfessionals, subscribeToProfessionalProfile } from "@/lib/professional-store";
import { distanceBetweenKm, readDeviceLocation, subscribeToLocation, watchDeviceLocation, type DeviceLocation } from "@/lib/location-store";
import { campaignTargetsChannel, isCampaignDeliverable, readAdCampaigns, recordAdClick, recordAdImpression, subscribeToAdCampaigns } from "@/lib/advertising-store";
import { cn } from "@/lib/utils";

const searchSchema = z.object({ q: z.string().optional(), cat: z.string().optional(), agora: z.boolean().optional() });
type SearchFilters = z.infer<typeof searchSchema>;

export const Route = createFileRoute("/buscar")({
  validateSearch: (search) => searchSchema.parse(search),
  head: () => ({ meta: [
    { title: "Buscar profissionais — ServiX" },
    { name: "description", content: "Encontre profissionais por serviço, distância, avaliação e disponibilidade." },
    { property: "og:title", content: "Buscar profissionais — ServiX" },
    { property: "og:description", content: "Explore profissionais da região e amplie sua busca pelo mapa." },
  ] }),
  component: SearchPage,
});

const radiusOptions = [5, 10, 20, 50] as const;
const keywordMap: Record<string, string> = {
  guarda: "montador", móvel: "montador", moveis: "montador", cama: "montador", chuveiro: "eletricista", tomada: "eletricista", luz: "eletricista",
  vazamento: "encanador", pia: "encanador", pintura: "pintor", limpeza: "diarista", split: "ar-condicionado", ar: "ar-condicionado",
};

function normalize(value: string) {
  return value.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLocaleLowerCase("pt-BR");
}

function SearchPage() {
  const { q, cat, agora } = Route.useSearch();
  const navigate = useNavigate({ from: "/buscar" });
  const [text, setText] = useState(q ?? "");
  const [radius, setRadius] = useState<(typeof radiusOptions)[number]>(10);
  const [sort, setSort] = useState<"distancia" | "avaliacao" | "preco">("distancia");
  const [quote, setQuote] = useState(false);
  const [selected, setSelected] = useState<Professional | null>(null);
  const [allPros, setAllPros] = useState<Professional[]>([]);
  const [campaigns, setCampaigns] = useState<AdCampaign[]>(readAdCampaigns);
  const [location, setLocation] = useState<DeviceLocation | null>(null);
  const [locating, setLocating] = useState(false);
  const [page, setPage] = useState(1);
  const pageSize = 10;
  const locationWatch = useRef<(() => void) | null>(null);

  useEffect(() => () => locationWatch.current?.(), []);
  useEffect(() => {
    const refresh = () => {
      const latest = readDeviceLocation("cliente");
      setLocation(latest);
      if (latest) setLocating(false);
    };
    refresh();
    return subscribeToLocation(refresh);
  }, []);

  const locate = () => {
    locationWatch.current?.();
    setLocating(true);
    locationWatch.current = watchDeviceLocation("cliente", (message) => { setLocating(false); toast.error(message); });
    toast.message("Aguardando localização do aparelho…");
  };

  useEffect(() => {
    const refresh = () => setAllPros(getClientFacingProfessionals());
    refresh();
    return subscribeToProfessionalProfile(refresh);
  }, []);

  useEffect(() => {
    const refresh = () => setCampaigns(readAdCampaigns());
    refresh();
    return subscribeToAdCampaigns(refresh);
  }, []);

  const inferred = useMemo(() => {
    if (cat || !q) return cat;
    const normalized = normalize(q);
    const keyword = Object.entries(keywordMap).find(([key]) => normalized.includes(normalize(key)));
    if (keyword) return keyword[1];
    return categories.find((category) => normalized.includes(normalize(category.name)))?.slug;
  }, [q, cat]);

  const locatedPros = useMemo(() => allPros.map((pro) => {
    if (pro.latitude === undefined || pro.longitude === undefined) return { ...pro, distanceKm: Number.POSITIVE_INFINITY };
    return location
      ? { ...pro, distanceKm: Math.round(distanceBetweenKm(location, { latitude: pro.latitude, longitude: pro.longitude }) * 10) / 10 }
      : { ...pro, distanceKm: Number.POSITIVE_INFINITY };
  }), [allPros, location]);

  const list = useMemo(() => {
    const terms = normalize(q ?? "").split(/\s+/).filter((term) => term.length > 2);
    const results = locatedPros.filter((pro) => {
      const searchable = normalize([pro.name, pro.role, pro.neighborhood, pro.bio, ...pro.services.flatMap((service) => [service.name, categoryName(service.category ?? pro.category)])].join(" "));
      const matchesTerms = !terms.length || (inferred ? terms.some((term) => searchable.includes(term)) : terms.every((term) => searchable.includes(term)));
      const matchesCategory = pro.services.length > 0 && (!inferred || pro.category === inferred || pro.services.some((service) => (service.category ?? pro.category) === inferred));
      return matchesCategory && matchesTerms && pro.distanceKm <= radius && (!agora || pro.online);
    });
    const matchingCategory = results.map((pro) => {
      if (!inferred) return pro;
      const matchingServices = pro.services.filter((service) => (service.category ?? pro.category) === inferred);
      if (!matchingServices.length) return pro;
      const pricedServices = matchingServices.filter((service) => service.price !== null).map((service) => service.price!);
      return { ...pro, category: inferred as Professional["category"], role: categoryName(inferred), priceFrom: pricedServices.length ? Math.min(...pricedServices) : 0 };
    });
    return matchingCategory.sort((a, b) => sort === "distancia" ? a.distanceKm - b.distanceKm : sort === "avaliacao" ? b.rating - a.rating : a.priceFrom - b.priceFrom);
  }, [locatedPros, inferred, q, agora, radius, sort]);

  const sponsoredProfessional = useMemo(() => {
    const campaign = campaigns.find((item) => item.advertiserType === "profissional" && campaignTargetsChannel(item, "busca") && isCampaignDeliverable(item) && list.some((pro) => pro.id === item.advertiserId));
    return campaign ? { campaign, pro: list.find((pro) => pro.id === campaign.advertiserId)! } : undefined;
  }, [campaigns, list]);
  const organicList = sponsoredProfessional ? list.filter((pro) => pro.id !== sponsoredProfessional.pro.id) : list;
  const visibleOrganic = organicList.slice((page - 1) * pageSize, page * pageSize);
  const businessCampaign = useMemo(() => campaigns.find((item) => {
    if (item.advertiserType !== "empresa" || item.format === "destaque_profissional" || !campaignTargetsChannel(item, "busca") || !isCampaignDeliverable(item)) return false;
    if (inferred && item.category && item.category !== inferred) return false;
    return !location || distanceBetweenKm(location, { latitude: item.latitude, longitude: item.longitude }) <= item.radiusKm;
  }), [campaigns, inferred, location]);

  useEffect(() => setPage(1), [q, cat, agora, radius, sort]);

  return <div className="space-y-5">
      <div className="flex flex-wrap items-end justify-between gap-4">
      <div><p className="mb-1 flex items-center gap-1.5 text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground"><MapPin className="h-3.5 w-3.5 text-primary" />{location ? "Sua localização atual" : "Localização não definida"}</p><h1 className="font-display text-3xl font-extrabold md:text-4xl">{inferred ? categoryName(inferred) : "Encontre quem resolve"}</h1><p className="mt-1 text-sm text-muted-foreground">Profissionais avaliados, com serviços e valores transparentes.</p></div>
      <div className="flex flex-wrap gap-2"><button type="button" onClick={locate} className="inline-flex items-center gap-2 rounded-full border bg-card px-4 py-2.5 text-sm font-bold hover:bg-muted"><LocateFixed className="h-4 w-4 text-primary" />{locating ? "Localizando…" : location ? "Atualizar localização" : "Usar minha localização"}</button><button type="button" onClick={() => setRadius(20)} className="rounded-full border bg-card px-4 py-2.5 text-sm font-bold hover:bg-muted">Ampliar para 20 km</button></div>
    </div>

    <form onSubmit={(event) => { event.preventDefault(); navigate({ search: (previous: SearchFilters) => ({ ...previous, q: text || undefined, cat: undefined }) }); }} className="surface flex items-center gap-2 p-2">
      <Search className="ml-2 h-5 w-5 shrink-0 text-muted-foreground" />
      <input value={text} onChange={(event) => setText(event.target.value)} placeholder="Qual serviço você precisa? Ex.: instalar chuveiro" className="min-w-0 flex-1 bg-transparent py-2 outline-none" />
      <button className="rounded-xl bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground">Buscar</button>
    </form>

    <div className="no-scrollbar -mx-4 flex gap-2 overflow-x-auto px-4 md:mx-0 md:px-0">
      <button type="button" onClick={() => navigate({ search: (previous: SearchFilters) => ({ ...previous, agora: previous.agora ? undefined : true }) })} className={cn("inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-2 text-sm font-semibold", agora && "border-transparent bg-brand text-brand-foreground")}><Zap className="h-4 w-4" />Disponíveis agora</button>
      <Link to="/buscar" search={{ agora }} className={cn("shrink-0 rounded-full border px-3.5 py-2 text-sm font-semibold", !inferred && "border-transparent bg-primary text-primary-foreground")}>Todas as categorias</Link>
      {categories.filter((category) => category.slug !== "outros").map((category) => <Link key={category.slug} to="/buscar" search={{ cat: category.slug, agora }} className={cn("inline-flex shrink-0 items-center gap-1.5 rounded-full border px-3.5 py-2 text-sm font-semibold", inferred === category.slug && "border-transparent bg-primary text-primary-foreground")}><CategoryIcon slug={category.slug} className="h-4 w-4" />{category.name}</Link>)}
    </div>

    <section className="surface space-y-3 p-3 sm:p-4">
      <div className="flex flex-wrap items-center justify-between gap-3 px-1"><div><h2 className="font-display text-lg font-bold">Mapa da região</h2><p className="text-xs text-muted-foreground">Ajuste o raio e selecione um marcador para abrir o perfil.</p></div><div className="flex flex-wrap items-center gap-2"><span className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground"><ListFilter className="h-3.5 w-3.5" />Raio</span><div className="inline-flex rounded-full bg-muted p-1">{radiusOptions.map((value) => <button key={value} onClick={() => setRadius(value)} className={cn("rounded-full px-3 py-1.5 text-xs font-bold transition", radius === value ? "bg-card text-foreground shadow-sm" : "text-muted-foreground hover:text-foreground")}>{value} km</button>)}</div><label className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground"><SlidersHorizontal className="h-3.5 w-3.5" /><select value={sort} onChange={(event) => setSort(event.target.value as typeof sort)} className="rounded-full border bg-card px-3 py-2 text-xs font-semibold text-foreground outline-none"><option value="distancia">Mais perto</option><option value="avaliacao">Melhor avaliados</option><option value="preco">Menor preço</option></select></label></div></div>
      <ProfessionalMap pros={list} radiusKm={radius} origin={location} onSelect={setSelected} />
      <div className="flex flex-wrap items-center justify-between gap-2 px-1 text-[11px] text-muted-foreground"><span className="inline-flex items-center gap-2"><span className="h-2 w-2 rounded-full bg-emerald-500" />Disponível agora <span className="ml-2 h-2 w-2 rounded-full bg-amber-400" />Agenda aberta</span><span>{list.length} profissionais dentro do raio selecionado</span></div>
    </section>

    <section className="space-y-3">
      <div className="flex flex-wrap items-end justify-between gap-3"><div><h2 className="font-display text-xl font-bold">Profissionais na sua região</h2><p className="mt-0.5 text-sm text-muted-foreground">Ordenados por {sort === "distancia" ? "distância" : sort === "avaliacao" ? "avaliação" : "preço"} · {q ? `resultados para “${q}”` : "serviços avaliados e com valores transparentes"}</p></div><span className="rounded-full bg-muted px-3 py-1.5 text-sm font-bold">{list.length} opções</span></div>
      {list.length > 0 ? <div className="grid gap-3 sm:grid-cols-2 xl:grid-cols-3 2xl:grid-cols-4">
        {sponsoredProfessional && <ProfessionalAd campaign={sponsoredProfessional.campaign} pro={sponsoredProfessional.pro} />}
        {visibleOrganic.map((pro, index) => <div key={pro.id} className="contents">
          <button onClick={() => setSelected(pro)} className="surface flex min-h-44 flex-col justify-between p-4 text-left transition hover:-translate-y-0.5 hover:shadow-md focus-visible:ring-2 focus-visible:ring-ring">
            <span className="flex w-full items-start gap-3"><Avatar pro={pro} size="md" /><span className="min-w-0 flex-1"><span className="flex items-center gap-1.5"><span className="truncate font-display font-bold">{pro.name}</span>{pro.verified && <span className="text-status-success" title="Perfil verificado">✓</span>}</span><span className="mt-0.5 block truncate text-xs text-muted-foreground">{pro.role} · {pro.neighborhood}</span><span className="mt-2 flex items-center gap-2"><Rating value={pro.rating} count={pro.reviews} className="text-xs" /><span className="text-[10px] text-muted-foreground">{pro.distanceKm.toString().replace(".", ",")} km</span></span></span></span>
            <span className="mt-4 flex w-full items-end justify-between gap-2 border-t pt-3"><span className="inline-flex items-center gap-1.5 text-xs font-semibold text-muted-foreground"><span className={cn("h-2 w-2 rounded-full", pro.online ? "bg-emerald-500" : "bg-amber-400")} />{pro.online ? "Disponível agora" : pro.availability}</span><span className="text-right"><span className="block text-[9px] uppercase tracking-wide text-muted-foreground">{pro.priceFrom > 0 ? "A partir de" : "Valor"}</span><span className="font-extrabold">{pro.priceFrom > 0 ? pro.priceFrom.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 }) : "Orçamento"}</span></span></span>
          </button>
          {businessCampaign && index === Math.min(2, organicList.length - 1) && <BusinessAd campaign={businessCampaign} className="sm:col-span-2 xl:col-span-2" />}
        </div>)}
        {businessCampaign && organicList.length === 0 && <BusinessAd campaign={businessCampaign} className="sm:col-span-2 xl:col-span-2" />}
      </div> : <div className="surface p-8 text-center"><MapPin className="mx-auto h-7 w-7 text-muted-foreground" /><p className="mt-3 font-bold">Ainda não encontramos esse serviço por perto.</p><p className="mt-1 text-sm text-muted-foreground">Amplie o raio para ver opções em outras regiões.</p><button onClick={() => setRadius(50)} className="mt-4 rounded-full bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground">Buscar em até 50 km</button></div>}
      <Pagination currentPage={page} totalItems={organicList.length} pageSize={pageSize} onPageChange={setPage} label="profissionais" />
      <button onClick={() => setQuote(true)} className="flex w-full items-center gap-3 rounded-2xl border-2 border-dashed p-4 text-left transition hover:bg-muted"><FileText className="h-5 w-5 shrink-0 text-primary" /><span className="min-w-0 flex-1"><span className="block text-sm font-bold">Não encontrou o que precisa?</span><span className="text-xs text-muted-foreground">Peça propostas para profissionais da região.</span></span><span className="text-xs font-bold text-primary">Pedir</span></button>
    </section>

    <MapProfessionalSheet pro={selected} open={!!selected} onOpenChange={(open) => !open && setSelected(null)} />
    <QuoteDialog open={quote} onOpenChange={setQuote} defaultText={q ?? ""} />
  </div>;
}

function ProfessionalAd({ campaign, pro }: { campaign: AdCampaign; pro: Professional }) {
  useEffect(() => { recordAdImpression(campaign.id); }, [campaign.id]);
  return <Link to="/profissional/$id" params={{ id: pro.id }} onClick={() => recordAdClick(campaign.id)} className="surface group min-w-0 overflow-hidden transition hover:-translate-y-0.5 hover:shadow-md sm:col-span-2 xl:col-span-1">
    <div className="relative aspect-[16/8] overflow-hidden bg-muted sm:aspect-[16/7]"><ResilientImage src={campaign.imageUrl} alt="" fallbackLabel="Criativo indisponível" className="h-full w-full object-cover object-center transition duration-500 group-hover:scale-[1.02]" /><span className="absolute left-3 top-3 bg-background/95 px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wide text-foreground">Patrocinado</span></div>
    <div className="p-3.5"><div className="flex items-center gap-3"><Avatar pro={pro} size="sm" /><span className="min-w-0 flex-1"><span className="block text-[10px] font-bold uppercase tracking-wide text-primary">Destaque profissional</span><span className="mt-0.5 block truncate text-sm font-bold">{campaign.headline}</span><span className="mt-1 flex items-center gap-2"><Rating value={pro.rating} count={pro.reviews} className="text-xs" /><span className="text-[10px] text-muted-foreground">{pro.distanceKm.toString().replace(".", ",")} km</span></span></span><span className="text-xs font-extrabold text-primary">Ver perfil</span></div></div>
  </Link>;
}

function BusinessAd({ campaign, className }: { campaign: AdCampaign; className?: string }) {
  useEffect(() => { recordAdImpression(campaign.id); }, [campaign.id]);
  const isLocalPath = campaign.href.startsWith("/") && !campaign.href.startsWith("//");
  const href = isLocalPath || /^https:\/\//i.test(campaign.href) ? campaign.href : "/empresas";
  const content = <>
    <div className={cn("relative overflow-hidden bg-muted", campaign.format === "banner_destaque" ? "aspect-[4/3] sm:aspect-[16/9]" : "aspect-[16/8] sm:aspect-[16/7]")}><ResilientImage src={campaign.imageUrl} alt={campaign.advertiserName} fallbackLabel="Criativo indisponível" className="h-full w-full object-cover object-center transition duration-500 group-hover:scale-[1.02]" /><span className="absolute left-3 top-3 bg-background/95 px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wide text-foreground">Publicidade</span></div>
    <div className="min-w-0 p-3.5"><p className="break-words text-[10px] font-bold uppercase tracking-wide text-muted-foreground">{campaign.advertiserName} · {campaign.region}</p><p className="mt-1 break-words font-display font-bold">{campaign.headline}</p><p className="mt-1 break-words text-xs text-muted-foreground">{campaign.description}</p><span className="mt-3 inline-block text-xs font-extrabold text-primary">Conhecer oferta →</span></div>
  </>;
  const classes = cn("surface group block overflow-hidden transition hover:-translate-y-0.5 hover:shadow-md", className);
  return href.startsWith("/")
    ? <Link to={href as never} onClick={() => recordAdClick(campaign.id)} className={classes}>{content}</Link>
    : <a href={href} target="_blank" rel="noopener noreferrer" onClick={() => recordAdClick(campaign.id)} className={classes}>{content}</a>;
}
