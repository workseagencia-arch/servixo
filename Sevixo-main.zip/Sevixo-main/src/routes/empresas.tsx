import { createFileRoute, Link } from "@tanstack/react-router";
import { Building2, Plus, MapPin, Receipt, Users } from "lucide-react";
import { toast } from "sonner";
import { businessProperties, brl } from "@/lib/demo-data";
import { PageTitle } from "@/components/app/ui-bits";

export const Route = createFileRoute("/empresas")({
  head: () => ({
    meta: [
      { title: "ServiX para Empresas — imobiliárias, condomínios e comércios" },
      { name: "description", content: "Cadastre imóveis e unidades, associe serviços e centralize pagamentos." },
      { property: "og:title", content: "ServiX para Empresas" },
      { property: "og:description", content: "Módulo empresarial para imobiliárias, administradoras e condomínios." },
    ],
  }),
  component: Business,
});

function Business() {
  return (
    <div>
      <PageTitle eyebrow="Módulo empresarial" title="Imóveis e unidades" subtitle="Associe serviços a cada imóvel. Os profissionais são os mesmos do marketplace."
        action={<button onClick={() => toast.success("Cadastro de imóvel em breve")} className="inline-flex items-center gap-2 rounded-full bg-primary px-5 py-3 text-sm font-bold text-primary-foreground"><Plus className="h-4 w-4" />Adicionar imóvel</button>} />
      <div className="mb-6 grid grid-cols-3 gap-3">
        {[[Building2, "4", "imóveis"], [Receipt, brl(9850), "gasto no mês"], [Users, "3", "usuários da equipe"]].map(([I, v, l]) => {
          const Icon = I as typeof Building2;
          return <div key={l as string} className="surface p-4"><Icon className="h-5 w-5 text-muted-foreground" /><p className="font-display mt-2 text-xl font-bold md:text-2xl">{v as string}</p><p className="text-xs text-muted-foreground">{l as string}</p></div>;
        })}
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        {businessProperties.map((p) => (
          <div key={p.code} className="surface p-5">
            <p className="text-xs text-muted-foreground">{p.code}</p>
            <p className="font-display text-lg font-bold">{p.name}</p>
            <p className="flex items-center gap-1 text-sm text-muted-foreground"><MapPin className="h-3.5 w-3.5" />{p.address}</p>
            <div className="mt-4 flex items-center justify-between border-t pt-3 text-sm">
              <span>{p.services} serviços ativos · {brl(p.spent)}</span>
              <Link to="/buscar" className="rounded-full bg-accent px-3 py-1.5 text-xs font-bold text-accent-foreground">Contratar para este imóvel</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}
