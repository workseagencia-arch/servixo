import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { ArrowRight, CheckCircle2, Search, MessageCircle, ShieldCheck } from "lucide-react";
import { toast } from "sonner";
import { z } from "zod";
import {
  hasProfessionalAccess,
  readSession,
  saveSession,
  type AccountRole,
} from "@/lib/auth-store";
import { addNotification } from "@/lib/notification-store";
import { readProfessionalProfile, saveProfessionalProfile } from "@/lib/professional-store";

const accessSearch = z.object({
  perfil: z.enum(["cliente", "profissional", "moderador"]).optional(),
});

export const Route = createFileRoute("/entrar")({
  validateSearch: (search) => accessSearch.parse(search),
  head: () => ({
    meta: [
      { title: "Entrar — ServiX" },
      { name: "description", content: "Acesse sua conta ServiX para acompanhar serviços, conversas e seu perfil." },
    ],
  }),
  component: AccessPage,
});

const inputClass =
  "w-full rounded-xl border bg-background px-4 py-3 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-ring/20";

function AccessPage() {
  const { perfil } = Route.useSearch();
  const navigate = useNavigate();
  const role: AccountRole = perfil === "moderador" ? "moderador" : "cliente";
  const [creating, setCreating] = useState(false);
  const [name, setName] = useState("");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");

  const submit = (event: React.FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    const previous = readSession();
    const sameAccount =
      previous?.email.toLocaleLowerCase("pt-BR") === email.trim().toLocaleLowerCase("pt-BR");
    const displayName =
      name.trim() ||
      (sameAccount && previous
        ? previous.name
        : role === "moderador"
          ? "Equipe ServiX"
          : "Sandson Eduardo");
    const professionalEnabled =
      role !== "moderador" && sameAccount && hasProfessionalAccess(previous);
    const accountRole: AccountRole = role === "moderador" ? "moderador" : "cliente";
    if (professionalEnabled)
      saveProfessionalProfile({
        ...readProfessionalProfile(),
        name: displayName,
        email: email.trim(),
      });
    saveSession({ role: accountRole, professionalEnabled, name: displayName, email: email.trim() });
    addNotification({
      role: accountRole,
      title: "Acesso realizado",
      detail: `Olá, ${displayName}. Seu espaço ServiX está pronto.`,
      href: role === "moderador" ? "/gestao/anuncios" : "/perfil",
    });
    toast.success(role === "moderador" ? "Acesso administrativo realizado" : "Bem-vindo à ServiX");
    navigate({
      to: role === "moderador" ? "/gestao/anuncios" : "/",
    });
  };

  return (
    <div className="mx-auto grid min-h-[calc(100vh-13rem)] w-full max-w-6xl items-center gap-8 py-6 lg:grid-cols-[1fr_440px]">
      <section className="hidden overflow-hidden rounded-lg bg-hero p-9 text-white lg:block">
        <span className="inline-flex items-center gap-2 rounded-full bg-white/10 px-3 py-1.5 text-xs font-bold">
          <ShieldCheck className="h-4 w-4 text-brand" /> Serviços com confiança
        </span>
        <h1 className="font-display mt-7 max-w-md text-4xl font-extrabold leading-tight">
          Sua conta ServiX, com tudo em um só lugar.
        </h1>
        <p className="mt-4 max-w-sm text-sm leading-relaxed text-white/75">
          Encontre serviços, converse com profissionais e acompanhe cada contratação. Se quiser
          divulgar seu trabalho, você poderá ativar esse recurso depois de entrar.
        </p>
        <div className="mt-10 space-y-3 border-t border-white/15 pt-6">
          {[
            [Search, "Encontre o serviço certo"],
            [MessageCircle, "Converse antes de contratar"],
            [CheckCircle2, "Acompanhe tudo pela sua conta"],
          ].map(([Icon, label]) => {
            const I = Icon as typeof Search;
            return (
              <div key={label as string} className="flex items-center gap-3 text-sm font-semibold">
                <I className="h-4 w-4 shrink-0 text-brand" />
                {label as string}
              </div>
            );
          })}
          </div>
      </section>

      <section className="surface mx-auto w-full max-w-lg p-6 sm:p-8">
        <p className="text-xs font-bold uppercase tracking-[0.14em] text-muted-foreground">
          Acesso ServiX
        </p>
        <h1 className="font-display mt-2 text-3xl font-extrabold">
          {creating ? "Crie sua conta" : "Que bom ter você de volta"}
        </h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Entre ou crie sua conta para acessar a plataforma e acompanhar seus serviços.
        </p>

        <form onSubmit={submit} className="mt-6 space-y-4">
          {creating && (
            <label className="block space-y-1.5 text-sm font-semibold">
              Nome completo
              <input
                required
                value={name}
                onChange={(event) => setName(event.target.value)}
                placeholder="Como podemos chamar você?"
                className={inputClass}
                autoComplete="name"
              />
            </label>
          )}
          <label className="block space-y-1.5 text-sm font-semibold">
            E-mail
            <input
              required
              type="email"
              value={email}
              onChange={(event) => setEmail(event.target.value)}
              placeholder="voce@email.com"
              className={inputClass}
              autoComplete="email"
            />
          </label>
          <label className="block space-y-1.5 text-sm font-semibold">
            Senha
            <input
              required
              minLength={6}
              type="password"
              value={password}
              onChange={(event) => setPassword(event.target.value)}
              placeholder="Mínimo de 6 caracteres"
              className={inputClass}
              autoComplete={creating ? "new-password" : "current-password"}
            />
          </label>
          {!creating && (
            <button
              type="button"
              onClick={() =>
                toast(
                  "A recuperação de senha será ativada quando a autenticação real for conectada.",
                )
              }
              className="-mt-2 text-xs font-bold text-primary hover:underline"
            >
              Esqueci minha senha
            </button>
          )}
          <button className="flex w-full items-center justify-center gap-2 rounded-full bg-primary py-3.5 font-bold text-primary-foreground transition hover:bg-primary/90">
            {creating ? "Criar conta" : "Entrar"}
            <ArrowRight className="h-4 w-4" />
          </button>
        </form>

        {role !== "moderador" && (
          <p className="mt-5 text-center text-sm text-muted-foreground">
            {creating ? "Já tem conta?" : "Primeira vez por aqui?"}{" "}
            <button
              onClick={() => setCreating((value) => !value)}
              className="font-bold text-primary hover:underline"
            >
              {creating ? "Entrar" : "Criar conta"}
            </button>
          </p>
        )}
        <p className="mt-5 rounded-xl bg-muted px-3 py-2.5 text-center text-xs leading-relaxed text-muted-foreground">
          Prévia funcional: os dados desta demonstração ficam salvos neste navegador.
        </p>
      </section>
    </div>
  );
}
