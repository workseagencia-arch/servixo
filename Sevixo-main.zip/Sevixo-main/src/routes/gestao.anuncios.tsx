import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type ChangeEvent, type FormEvent } from "react";
import {
  BadgeCheck,
  Building2,
  Check,
  CreditCard,
  Eye,
  ImagePlus,
  Megaphone,
  MousePointerClick,
  Pause,
  Play,
  Plus,
  ShieldCheck,
  X,
} from "lucide-react";
import { toast } from "sonner";
import {
  adChannelLabels,
  categories,
  customerAdChannels,
  type AdCampaign,
  type AdCampaignFormat,
  type AdChannel,
} from "@/lib/demo-data";
import { readSession } from "@/lib/auth-store";
import { addNotification } from "@/lib/notification-store";
import {
  addAdCampaign,
  readAdCampaigns,
  saveAdCampaigns,
  subscribeToAdCampaigns,
} from "@/lib/advertising-store";
import { PageTitle, ResilientImage } from "@/components/app/ui-bits";
import { Pagination } from "@/components/app/pagination";
import { AdChannelPicker } from "@/components/app/ad-channel-picker";
import { recordAdminAudit } from "@/lib/security-store";
import { prepareCampaignImage } from "@/lib/campaign-image";

export const Route = createFileRoute("/gestao/anuncios")({
  head: () => ({
    meta: [
      { title: "Gestão de anúncios — ServiX" },
      {
        name: "description",
        content: "Gerencie campanhas, pagamentos e espaços patrocinados da plataforma.",
      },
    ],
  }),
  component: AdvertisingManagement,
});

const inputClass =
  "w-full rounded-xl border bg-background px-3.5 py-3 text-sm outline-none focus:ring-2 focus:ring-ring/20";
const amountFor = (format: AdCampaignFormat, days: number, channelCount = 2) => {
  const base =
    format === "banner_destaque"
      ? days === 7
        ? 249
        : 649
      : format === "banner_empresa"
        ? days === 7
          ? 129
          : 349
        : days === 7
          ? 39
          : 99;
  return base * Math.max(1, Math.ceil(channelCount / 3));
};
const deliveryZones = [
  { label: "Pinheiros e Vila Madalena · São Paulo", latitude: -23.5671, longitude: -46.7012 },
  { label: "Perdizes e Sumaré · São Paulo", latitude: -23.5354, longitude: -46.6773 },
  { label: "Butantã e Morumbi · São Paulo", latitude: -23.5708, longitude: -46.7222 },
];
const stateLabel: Record<AdCampaign["status"], string> = {
  em_analise: "Em análise",
  ativa: "Ativo",
  pausada: "Pausado",
  reprovada: "Reprovado",
};
const stateClass: Record<AdCampaign["status"], string> = {
  em_analise: "bg-status-warning/15 text-status-warning-foreground",
  ativa: "bg-accent text-accent-foreground",
  pausada: "bg-muted text-muted-foreground",
  reprovada: "bg-destructive/10 text-destructive",
};

function AdvertisingManagement() {
  const [isStaff, setIsStaff] = useState(false);
  const [sessionReady, setSessionReady] = useState(false);
  const [campaigns, setCampaigns] = useState<AdCampaign[]>(readAdCampaigns);
  const [creating, setCreating] = useState(false);
  const [advertiser, setAdvertiser] = useState("");
  const [headline, setHeadline] = useState("");
  const [description, setDescription] = useState("");
  const [region, setRegion] = useState(deliveryZones[0]!.label);
  const [website, setWebsite] = useState("/empresas");
  const [category, setCategory] = useState("");
  const [format, setFormat] = useState<AdCampaignFormat>("banner_empresa");
  const [days, setDays] = useState(30);
  const [channels, setChannels] = useState<AdChannel[]>(customerAdChannels);
  const [imageUrl, setImageUrl] = useState("");
  const [filter, setFilter] = useState<"pendentes" | "ativas" | "todas">("pendentes");
  const [page, setPage] = useState(1);
  const pageSize = 10;

  useEffect(() => {
    const session = readSession();
    setIsStaff(session?.role === "moderador");
    setSessionReady(true);
    const refresh = () => setCampaigns(readAdCampaigns());
    refresh();
    return subscribeToAdCampaigns(refresh);
  }, []);

  const pending = campaigns.filter((item) => item.status === "em_analise");
  const active = campaigns.filter(
    (item) => item.status === "ativa" && item.payment === "confirmado",
  );
  const confirmedRevenue = campaigns
    .filter((item) => item.payment === "confirmado")
    .reduce((sum, item) => sum + item.amount, 0);
  const filteredCampaigns = useMemo(
    () =>
      campaigns.filter((item) =>
        filter === "pendentes"
          ? item.status === "em_analise"
          : filter === "ativas"
            ? item.status === "ativa"
            : true,
      ),
    [campaigns, filter],
  );
  const visibleCampaigns = filteredCampaigns.slice((page - 1) * pageSize, page * pageSize);

  const chooseImage = async (event: ChangeEvent<HTMLInputElement>) => {
    const input = event.currentTarget;
    const file = input.files?.[0];
    if (!file) return;
    try {
      setImageUrl(await prepareCampaignImage(file));
    } catch (error) {
      toast.error(error instanceof Error ? error.message : "Não foi possível preparar essa imagem.");
    } finally {
      input.value = "";
    }
  };

  const createCampaign = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!imageUrl) {
      toast.error("Adicione a imagem que será exibida aos clientes.");
      return;
    }
    if (!channels.length) {
      toast.error("Escolha pelo menos um canal de exibição.");
      return;
    }
    const isLocalPath = website.startsWith("/") && !website.startsWith("//");
    const isHttps = /^https:\/\//i.test(website);
    if (!isLocalPath && !isHttps) {
      toast.error("Informe um link interno ou um endereço que comece com https://.");
      return;
    }
    const now = new Date();
    const end = new Date(now);
    end.setDate(end.getDate() + days);
    const zone = deliveryZones.find((item) => item.label === region) ?? deliveryZones[0]!;
    addAdCampaign({
      advertiserType: "empresa",
      advertiserName: advertiser.trim(),
      format,
      headline: headline.trim(),
      description: description.trim(),
      imageUrl,
      href: website.trim(),
      channels,
      ...(category ? { category: category as NonNullable<AdCampaign["category"]> } : {}),
      region: zone.label,
      latitude: zone.latitude,
      longitude: zone.longitude,
      radiusKm: 15,
      amount: amountFor(format, days, channels.length),
      durationDays: days,
      startsAt: now.toISOString(),
      endsAt: end.toISOString(),
      status: "em_analise",
      payment: "pendente",
    });
    recordAdminAudit("Campanha empresarial cadastrada", advertiser.trim());
    setAdvertiser("");
    setHeadline("");
    setDescription("");
    setImageUrl("");
    setChannels(customerAdChannels);
    setCreating(false);
    setFilter("pendentes");
    toast.success("Campanha cadastrada para análise e confirmação de pagamento.");
  };

  const approve = (campaign: AdCampaign) => {
    const now = new Date();
    const end = new Date(now);
    end.setDate(end.getDate() + campaign.durationDays);
    const next = readAdCampaigns().map((item) => {
      const shouldPause =
        campaign.advertiserType === "profissional" &&
        item.id !== campaign.id &&
        item.advertiserType === "profissional" &&
        item.advertiserId === campaign.advertiserId &&
        item.status === "ativa";
      if (item.id === campaign.id)
        return {
          ...item,
          status: "ativa" as const,
          payment: "confirmado" as const,
          startsAt: now.toISOString(),
          endsAt: end.toISOString(),
        };
      return shouldPause ? { ...item, status: "pausada" as const } : item;
    });
    saveAdCampaigns(next);
    recordAdminAudit("Campanha aprovada e pagamento confirmado", campaign.advertiserName);
    if (campaign.advertiserType === "profissional")
      addNotification({
        role: "profissional",
        title: "Seu destaque foi aprovado",
        detail: `${campaign.durationDays} dias de divulgação estão ativos na região ${campaign.region}.`,
        href: "/pro/divulgacao",
      });
    toast.success("Pagamento confirmado e campanha aprovada.");
  };

  const reject = (campaign: AdCampaign) => {
    const next = readAdCampaigns().map((item) =>
      item.id === campaign.id ? { ...item, status: "reprovada" as const } : item,
    );
    saveAdCampaigns(next);
    recordAdminAudit("Campanha reprovada", campaign.advertiserName);
    toast("Campanha reprovada e removida da fila.");
  };

  const toggleCampaign = (campaign: AdCampaign) => {
    if (campaign.status === "pausada" && new Date(campaign.endsAt).getTime() < Date.now()) {
      toast.error("Esta campanha expirou. Cadastre uma nova para voltar a anunciar.");
      return;
    }
    const nextStatus = campaign.status === "ativa" ? "pausada" : "ativa";
    const next = readAdCampaigns().map((item) =>
      item.id === campaign.id ? { ...item, status: nextStatus as AdCampaign["status"] } : item,
    );
    saveAdCampaigns(next);
    recordAdminAudit(
      nextStatus === "ativa" ? "Campanha reativada" : "Campanha pausada",
      campaign.advertiserName,
    );
    toast.success(nextStatus === "ativa" ? "Campanha reativada" : "Campanha pausada");
  };

  if (!sessionReady)
    return (
      <div className="surface p-8 text-center text-sm text-muted-foreground">
        Verificando acesso da equipe…
      </div>
    );
  if (!isStaff)
    return (
      <div className="surface mx-auto max-w-lg p-8 text-center">
        <ShieldCheck className="mx-auto h-8 w-8 text-primary" />
        <h1 className="mt-3 font-display text-xl font-bold">Área exclusiva da equipe</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Entre pelo acesso demonstrativo da Equipe ServiX para abrir o painel.
        </p>
        <Link
          to="/entrar"
          search={{ perfil: "moderador" }}
          className="mt-5 inline-flex rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground"
        >
          Entrar como equipe
        </Link>
      </div>
    );

  return (
    <div>
      <PageTitle
        eyebrow="Equipe ServiX · acesso interno"
        title="Anúncios da plataforma"
        subtitle="Revise peças, confirme pagamentos e controle os espaços patrocinados."
        action={
          <button
            onClick={() => setCreating((value) => !value)}
            className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground"
          >
            <Plus className="h-4 w-4" />
            Anunciar empresa
          </button>
        }
      />

      <section className="mb-5 grid gap-3 sm:grid-cols-3">
        <div className="surface flex items-center gap-3 p-4">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-status-warning/15 text-status-warning-foreground">
            <Megaphone className="h-5 w-5" />
          </span>
          <span>
            <span className="block text-xs text-muted-foreground">Aguardando análise</span>
            <strong className="font-display text-xl">{pending.length}</strong>
          </span>
        </div>
        <div className="surface flex items-center gap-3 p-4">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-accent text-accent-foreground">
            <Eye className="h-5 w-5" />
          </span>
          <span>
            <span className="block text-xs text-muted-foreground">Campanhas ativas</span>
            <strong className="font-display text-xl">{active.length}</strong>
          </span>
        </div>
        <div className="surface flex items-center gap-3 p-4">
          <span className="grid h-10 w-10 place-items-center rounded-xl bg-brand text-brand-foreground">
            <CreditCard className="h-5 w-5" />
          </span>
          <span>
            <span className="block text-xs text-muted-foreground">Receita confirmada</span>
            <strong className="font-display text-xl">
              {confirmedRevenue.toLocaleString("pt-BR", {
                style: "currency",
                currency: "BRL",
                maximumFractionDigits: 0,
              })}
            </strong>
          </span>
        </div>
      </section>

      {creating && (
        <form onSubmit={createCampaign} className="surface mb-5 space-y-4 p-5 sm:p-6">
          <div>
            <h2 className="font-display text-xl font-bold">Nova campanha empresarial</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Cadastre a peça, a área de exibição e o formato contratado.
            </p>
          </div>
          <div className="grid gap-3 sm:grid-cols-2">
            <label className="space-y-1.5 text-sm font-semibold">
              Empresa
              <input
                required
                maxLength={80}
                value={advertiser}
                onChange={(event) => setAdvertiser(event.target.value)}
                placeholder="Ex.: Casa & Reforma"
                className={inputClass}
              />
            </label>
            <label className="space-y-1.5 text-sm font-semibold">
              Link de destino
              <input
                required
                value={website}
                onChange={(event) => setWebsite(event.target.value)}
                placeholder="https://empresa.com.br"
                className={inputClass}
              />
            </label>
            <label className="space-y-1.5 text-sm font-semibold sm:col-span-2">
              Chamada do anúncio
              <input
                required
                maxLength={90}
                value={headline}
                onChange={(event) => setHeadline(event.target.value)}
                placeholder="A oferta para quem está melhorando a casa"
                className={inputClass}
              />
            </label>
            <label className="space-y-1.5 text-sm font-semibold sm:col-span-2">
              Descrição
              <textarea
                required
                maxLength={180}
                rows={2}
                value={description}
                onChange={(event) => setDescription(event.target.value)}
                placeholder="Benefício claro e relevante para o cliente."
                className={inputClass}
              />
            </label>
            <AdChannelPicker value={channels} onChange={setChannels} />
            <label className="space-y-1.5 text-sm font-semibold">
              Categoria
              <select
                value={category}
                onChange={(event) => setCategory(event.target.value)}
                className={inputClass}
              >
                <option value="">Todas as categorias</option>
                {categories
                  .filter((item) => item.slug !== "outros")
                  .map((item) => (
                    <option key={item.slug} value={item.slug}>
                      {item.name}
                    </option>
                  ))}
              </select>
            </label>
            <label className="space-y-1.5 text-sm font-semibold">
              Região de exibição
              <select
                value={region}
                onChange={(event) => setRegion(event.target.value)}
                className={inputClass}
              >
                {deliveryZones.map((zone) => (
                  <option key={zone.label} value={zone.label}>
                    {zone.label}
                  </option>
                ))}
              </select>
            </label>
            <label className="space-y-1.5 text-sm font-semibold">
              Formato
              <select
                value={format}
                onChange={(event) => setFormat(event.target.value as AdCampaignFormat)}
                className={inputClass}
              >
                <option value="banner_empresa">Banner compacto</option>
                <option value="banner_destaque">Banner em destaque</option>
              </select>
            </label>
            <label className="space-y-1.5 text-sm font-semibold">
              Período
              <select
                value={days}
                onChange={(event) => setDays(Number(event.target.value))}
                className={inputClass}
              >
                <option value={7}>
                  7 dias ·{" "}
                  {amountFor(format, 7, channels.length).toLocaleString("pt-BR", {
                    style: "currency",
                    currency: "BRL",
                  })}
                </option>
                <option value={30}>
                  30 dias ·{" "}
                  {amountFor(format, 30, channels.length).toLocaleString("pt-BR", {
                    style: "currency",
                    currency: "BRL",
                  })}
                </option>
              </select>
            </label>
          </div>
          <label className="flex cursor-pointer items-center gap-3 rounded-2xl border border-dashed p-3.5 hover:bg-muted/60">
            <span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-accent text-accent-foreground">
              <ImagePlus className="h-5 w-5" />
            </span>
            <span className="min-w-0 flex-1">
              <span className="block text-sm font-bold">Imagem para o anúncio</span>
              <span className="block text-xs leading-relaxed text-muted-foreground">
                JPG, PNG ou WebP · até 8 MB. A imagem é otimizada para carregar bem em qualquer tela.
              </span>
            </span>
            <input type="file" accept="image/jpeg,image/png,image/webp" className="sr-only" onChange={chooseImage} />
          </label>
          {imageUrl && (
            <div className="relative aspect-[16/8] overflow-hidden rounded-lg bg-muted sm:aspect-[16/7]">
              <ResilientImage src={imageUrl} alt="Prévia da campanha" fallbackLabel="Prévia indisponível" className="h-full w-full object-cover object-center" loading="eager" />
              <span className="absolute left-3 top-3 bg-background/95 px-2.5 py-1 text-[10px] font-extrabold uppercase tracking-wide">Prévia do anúncio</span>
            </div>
          )}
          <div className="flex flex-wrap items-center justify-between gap-3 border-t pt-4">
            <p className="text-xs text-muted-foreground">
              Pagamento: aguardando confirmação após cadastro.
            </p>
            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => setCreating(false)}
                className="rounded-full border px-4 py-2.5 text-sm font-bold"
              >
                Cancelar
              </button>
              <button className="rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground">
                Cadastrar campanha ·{" "}
                {amountFor(format, days, channels.length).toLocaleString("pt-BR", {
                  style: "currency",
                  currency: "BRL",
                })}
              </button>
            </div>
          </div>
        </form>
      )}

      <section className="surface overflow-hidden">
        <div className="flex flex-wrap items-center justify-between gap-3 border-b p-4 sm:p-5">
          <div>
            <h2 className="font-display text-lg font-bold">Campanhas e moderação</h2>
            <p className="text-xs text-muted-foreground">
              Só anúncios pagos e aprovados aparecem para clientes.
            </p>
          </div>
          <div className="flex rounded-full bg-muted p-1">
            {(
              [
                ["pendentes", "Em análise"],
                ["ativas", "Ativos"],
                ["todas", "Todas"],
              ] as const
            ).map(([value, label]) => (
              <button
                key={value}
                onClick={() => { setFilter(value); setPage(1); }}
                className={`rounded-full px-3 py-2 text-xs font-bold ${filter === value ? "bg-card text-foreground shadow-sm" : "text-muted-foreground"}`}
              >
                {label}
              </button>
            ))}
          </div>
        </div>
        <div className="divide-y">
          {visibleCampaigns.map((campaign) => (
            <article
              key={campaign.id}
              className="grid gap-4 p-4 sm:grid-cols-[minmax(180px,.7fr)_1fr] sm:p-5"
            >
              <div className="relative aspect-[16/8] min-w-0 overflow-hidden rounded-lg bg-muted sm:aspect-auto sm:min-h-40">
                <ResilientImage src={campaign.imageUrl} alt="" fallbackLabel="Criativo indisponível" className="h-full min-h-32 w-full object-cover object-center sm:absolute sm:inset-0 sm:min-h-0" />
                <span className="absolute left-2 top-2 rounded-full bg-background/95 px-2.5 py-1 text-[10px] font-extrabold uppercase">
                  {campaign.advertiserType === "profissional" ? "Profissional" : "Empresa"}
                </span>
              </div>
              <div className="flex min-w-0 flex-col">
                <div className="flex flex-wrap items-start justify-between gap-2">
                  <div className="min-w-0">
                    <p className="text-xs font-semibold text-muted-foreground">
                      {campaign.advertiserName} · {campaign.region}
                    </p>
                    <h3 className="mt-1 break-words font-display text-lg font-bold">{campaign.headline}</h3>
                    <p className="mt-1 break-words text-sm text-muted-foreground">{campaign.description}</p>
                  </div>
                  <span
                    className={`rounded-full px-2.5 py-1 text-[10px] font-extrabold ${stateClass[campaign.status]}`}
                  >
                    {stateLabel[campaign.status]}
                  </span>
                </div>
                <div className="mt-3 flex flex-wrap gap-x-4 gap-y-1 text-xs text-muted-foreground">
                  <span>
                    {campaign.format === "destaque_profissional"
                      ? "Destaque na busca"
                      : campaign.format === "banner_destaque"
                        ? "Banner em destaque"
                        : "Banner compacto"}
                  </span>
                  <span>{campaign.durationDays} dias</span>
                  <span className="max-w-full truncate" title="Canais de exibição">
                    {(
                      campaign.channels ??
                      (campaign.advertiserType === "empresa"
                        ? customerAdChannels
                        : ["inicio", "busca"])
                    )
                      .map((channel) => adChannelLabels[channel])
                      .join(", ")}
                  </span>
                  <span className="font-bold text-foreground">
                    {campaign.amount.toLocaleString("pt-BR", {
                      style: "currency",
                      currency: "BRL",
                    })}
                  </span>
                  <span
                    className={
                      campaign.payment === "confirmado"
                        ? "text-status-success"
                        : "text-status-warning-foreground"
                    }
                  >
                    <CreditCard className="mr-1 inline h-3.5 w-3.5" />
                    Pagamento {campaign.payment === "confirmado" ? "confirmado" : "pendente"}
                  </span>
                </div>
                {campaign.status === "ativa" && (
                  <div className="mt-2 flex gap-4 text-xs text-muted-foreground">
                    <span>
                      <Eye className="mr-1 inline h-3.5 w-3.5" />
                      {campaign.impressions.toLocaleString("pt-BR")} impressões
                    </span>
                    <span>
                      <MousePointerClick className="mr-1 inline h-3.5 w-3.5" />
                      {campaign.clicks.toLocaleString("pt-BR")} cliques
                    </span>
                  </div>
                )}
                <div className="mt-auto flex flex-wrap gap-2 pt-4">
                  {campaign.status === "em_analise" && (
                    <>
                      <button
                        onClick={() => approve(campaign)}
                        className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2 text-xs font-bold text-primary-foreground"
                      >
                        <Check className="h-3.5 w-3.5" />
                        Confirmar pagamento e aprovar
                      </button>
                      <button
                        onClick={() => reject(campaign)}
                        className="inline-flex items-center gap-1.5 rounded-full border px-4 py-2 text-xs font-bold text-destructive"
                      >
                        <X className="h-3.5 w-3.5" />
                        Reprovar
                      </button>
                    </>
                  )}
                  {campaign.status === "ativa" && (
                    <button
                      onClick={() => toggleCampaign(campaign)}
                      className="inline-flex items-center gap-1.5 rounded-full border px-4 py-2 text-xs font-bold"
                    >
                      <Pause className="h-3.5 w-3.5" />
                      Pausar
                    </button>
                  )}
                  {campaign.status === "pausada" && (
                    <button
                      onClick={() => toggleCampaign(campaign)}
                      className="inline-flex items-center gap-1.5 rounded-full border px-4 py-2 text-xs font-bold"
                    >
                      <Play className="h-3.5 w-3.5" />
                      Reativar
                    </button>
                  )}
                </div>
              </div>
            </article>
          ))}
          {!visibleCampaigns.length && (
            <div className="p-10 text-center">
              <Building2 className="mx-auto h-8 w-8 text-muted-foreground" />
              <p className="mt-3 font-bold">Nenhuma campanha nesta lista</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Novos anúncios profissionais ou empresariais aparecerão aqui.
              </p>
            </div>
          )}
        </div>
        <div className="px-4 sm:px-5">
          <Pagination currentPage={page} totalItems={filteredCampaigns.length} pageSize={pageSize} onPageChange={setPage} label="campanhas" />
        </div>
      </section>
      <p className="mt-4 rounded-xl bg-muted px-4 py-3 text-xs leading-relaxed text-muted-foreground">
        <BadgeCheck className="mr-1 inline h-4 w-4" />
        Painel demonstrativo: campanhas e pagamentos são salvos neste navegador. A autenticação de
        equipe, cobrança real e armazenamento compartilhado precisam ser ligados ao backend antes da
        publicação.
      </p>
    </div>
  );
}
