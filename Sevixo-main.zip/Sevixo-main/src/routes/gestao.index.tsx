import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { ArrowRight, Building2, CreditCard, Megaphone, ShieldCheck, Users, UserRoundCheck, ClipboardCheck, Activity } from "lucide-react";
import { PageTitle } from "@/components/app/ui-bits";
import { readSession } from "@/lib/auth-store";
import { readAdCampaigns, subscribeToAdCampaigns } from "@/lib/advertising-store";
import { readSecurityState, subscribeToSecurityState, type SecurityState } from "@/lib/security-store";

export const Route = createFileRoute("/gestao/")({
  head: () => ({ meta: [{ title: "Central administrativa — ServiX" }, { name: "description", content: "Visão geral da operação, moderação e segurança da plataforma ServiX." }] }),
  component: ManagementDashboard,
});

function ManagementDashboard() {
  const [isStaff, setIsStaff] = useState(false);
  const [ready, setReady] = useState(false);
  const [security, setSecurity] = useState<SecurityState>(readSecurityState);
  const [campaigns, setCampaigns] = useState(readAdCampaigns);

  useEffect(() => {
    setIsStaff(readSession()?.role === "moderador");
    setReady(true);
    const refresh = () => { setSecurity(readSecurityState()); setCampaigns(readAdCampaigns()); };
    const offSecurity = subscribeToSecurityState(refresh);
    const offAds = subscribeToAdCampaigns(refresh);
    refresh();
    return () => { offSecurity(); offAds(); };
  }, []);

  const activeAccounts = security.accounts.filter((account) => account.status === "ativa").length;
  const professionals = security.accounts.filter((account) => account.role === "profissional");
  const pendingReports = security.reports.filter((report) => report.status === "aberta" || report.status === "em_analise").length;
  const pendingAds = campaigns.filter((campaign) => campaign.status === "em_analise").length;
  const confirmedRevenue = campaigns.filter((campaign) => campaign.payment === "confirmado").reduce((sum, campaign) => sum + campaign.amount, 0);
  const placements = useMemo(() => campaigns.filter((campaign) => campaign.status === "ativa").reduce((sum, campaign) => sum + (campaign.channels?.length ?? (campaign.advertiserType === "empresa" ? 6 : 2)), 0), [campaigns]);

  if (!ready) return <div className="surface p-8 text-center text-sm text-muted-foreground">Verificando acesso da equipe…</div>;
  if (!isStaff) return <StaffAccessCard />;

  const stats = [
    { label: "Contas ativas", value: activeAccounts, detail: `${security.accounts.length} contas demonstrativas`, icon: Users, tone: "bg-accent text-accent-foreground" },
    { label: "Profissionais", value: professionals.filter((account) => account.status === "ativa").length, detail: `${professionals.filter((account) => account.verified).length} com perfil verificado`, icon: UserRoundCheck, tone: "bg-secondary text-secondary-foreground" },
    { label: "Em análise", value: pendingReports + pendingAds, detail: `${pendingReports} denúncias · ${pendingAds} anúncios`, icon: ClipboardCheck, tone: "bg-status-warning/15 text-status-warning-foreground" },
    { label: "Receita de anúncios", value: confirmedRevenue.toLocaleString("pt-BR", { style: "currency", currency: "BRL", maximumFractionDigits: 0 }), detail: `${placements} canais em campanhas ativas`, icon: CreditCard, tone: "bg-brand text-brand-foreground" },
  ];

  return <div className="space-y-5">
    <PageTitle eyebrow="Equipe ServiX · centro de comando" title="Visão geral" subtitle="Acompanhe operação, receita de mídia e fila de confiança em um só lugar." action={<span className="inline-flex items-center gap-2 rounded-full bg-accent px-3 py-2 text-xs font-bold text-accent-foreground"><ShieldCheck className="h-4 w-4" />Equipe autenticada</span>} />

    <section className="grid gap-3 sm:grid-cols-2 xl:grid-cols-4">
      {stats.map(({ label, value, detail, icon: Icon, tone }) => <article key={label} className="surface flex min-w-0 items-center gap-3 p-4"><span className={`grid h-11 w-11 shrink-0 place-items-center rounded-2xl ${tone}`}><Icon className="h-5 w-5" /></span><span className="min-w-0"><span className="block text-xs font-semibold text-muted-foreground">{label}</span><strong className="mt-0.5 block truncate font-display text-2xl font-extrabold">{value}</strong><span className="mt-0.5 block truncate text-[10px] text-muted-foreground">{detail}</span></span></article>)}
    </section>

    {(pendingReports > 0 || pendingAds > 0) && <section className="surface flex flex-col gap-3 border-status-warning/40 bg-status-warning/5 p-4 sm:flex-row sm:items-center sm:justify-between"><div className="flex items-start gap-3"><span className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-status-warning/15 text-status-warning-foreground"><Activity className="h-5 w-5" /></span><div><h2 className="font-display font-bold">Atenção da equipe</h2><p className="mt-0.5 text-sm text-muted-foreground">Há {pendingReports} denúncias e {pendingAds} anúncios aguardando revisão.</p></div></div><Link to="/gestao/seguranca" className="inline-flex items-center justify-center gap-2 rounded-full border px-4 py-2.5 text-sm font-bold hover:bg-card">Abrir fila de segurança <ArrowRight className="h-4 w-4" /></Link></section>}

    <section className="grid gap-4 lg:grid-cols-2">
      <Link to="/gestao/seguranca" className="surface lift group flex min-h-52 flex-col justify-between p-5 sm:p-6"><div className="flex items-start justify-between gap-3"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-primary text-primary-foreground"><ShieldCheck className="h-6 w-6" /></span><ArrowRight className="h-5 w-5 text-muted-foreground transition group-hover:translate-x-1" /></div><div><h2 className="font-display text-xl font-bold">Controle e segurança</h2><p className="mt-1 max-w-lg text-sm leading-relaxed text-muted-foreground">Revise denúncias, suspenda acessos, conceda verificação e acompanhe cada ação da equipe.</p></div></Link>
      <Link to="/gestao/anuncios" className="surface lift group flex min-h-52 flex-col justify-between p-5 sm:p-6"><div className="flex items-start justify-between gap-3"><span className="grid h-12 w-12 place-items-center rounded-2xl bg-brand text-brand-foreground"><Megaphone className="h-6 w-6" /></span><ArrowRight className="h-5 w-5 text-muted-foreground transition group-hover:translate-x-1" /></div><div><h2 className="font-display text-xl font-bold">Anúncios e receita</h2><p className="mt-1 max-w-lg text-sm leading-relaxed text-muted-foreground">Venda campanhas por canal e região, confira pagamentos e pause peças em qualquer tela.</p></div></Link>
    </section>

    <section className="surface overflow-hidden"><div className="flex flex-wrap items-center justify-between gap-3 border-b p-4 sm:p-5"><div><h2 className="font-display text-lg font-bold">Atividade recente</h2><p className="text-xs text-muted-foreground">Registro local de ações de moderação e segurança.</p></div><span className="inline-flex items-center gap-1.5 rounded-full bg-muted px-3 py-1.5 text-xs font-semibold"><Building2 className="h-3.5 w-3.5" /> {campaigns.filter((campaign) => campaign.status === "ativa").length} campanhas ativas</span></div>
      {security.audit.length ? <div className="divide-y">{security.audit.slice(0, 5).map((event) => <div key={event.id} className="flex flex-wrap items-center justify-between gap-2 px-4 py-3.5 sm:px-5"><div><p className="text-sm font-semibold">{event.action}</p><p className="text-xs text-muted-foreground">{event.subject} · {event.actor}</p></div><time className="text-xs text-muted-foreground">{new Date(event.createdAt).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" })}</time></div>)}</div> : <p className="p-6 text-sm text-muted-foreground">As ações administrativas aparecerão aqui.</p>}</section>
    <p className="rounded-xl bg-muted px-4 py-3 text-xs leading-relaxed text-muted-foreground">Painel demonstrativo com dados salvos neste navegador. Antes da operação real, autenticação, permissões, auditoria e pagamentos precisam ser executados e persistidos no backend.</p>
  </div>;
}

function StaffAccessCard() {
  return <div className="surface mx-auto max-w-lg p-8 text-center"><ShieldCheck className="mx-auto h-8 w-8 text-primary" /><h1 className="mt-3 font-display text-xl font-bold">Área exclusiva da equipe</h1><p className="mt-2 text-sm text-muted-foreground">Entre pelo acesso demonstrativo da Equipe ServiX para abrir o painel.</p><Link to="/entrar" search={{ perfil: "moderador" }} className="mt-5 inline-flex rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground">Entrar como equipe</Link></div>;
}
