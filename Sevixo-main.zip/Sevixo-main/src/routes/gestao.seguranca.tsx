import { createFileRoute } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { BadgeCheck, Ban, FileWarning, History, Search, ShieldCheck, UserRoundCheck, Users } from "lucide-react";
import { toast } from "sonner";
import { PageTitle } from "@/components/app/ui-bits";
import { Pagination } from "@/components/app/pagination";
import { readSession } from "@/lib/auth-store";
import { readSecurityState, setDemoAccountStatus, setDemoAccountVerified, setModerationReportStatus, subscribeToSecurityState, type SecurityState } from "@/lib/security-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/gestao/seguranca")({
  head: () => ({ meta: [{ title: "Controle e segurança — ServiX" }, { name: "description", content: "Central administrativa de acessos, denúncias e auditoria da ServiX." }] }),
  component: SecurityManagement,
});

type PanelTab = "denuncias" | "contas" | "auditoria";
const reportStateLabels = { aberta: "Aberta", em_analise: "Em análise", resolvida: "Resolvida", arquivada: "Arquivada" } as const;

function SecurityManagement() {
  const [isStaff, setIsStaff] = useState(false);
  const [ready, setReady] = useState(false);
  const [state, setState] = useState<SecurityState>(readSecurityState);
  const [tab, setTab] = useState<PanelTab>("denuncias");
  const [query, setQuery] = useState("");
  const [reportPage, setReportPage] = useState(1);
  const [accountPage, setAccountPage] = useState(1);
  const [auditPage, setAuditPage] = useState(1);
  const pageSize = 10;

  useEffect(() => {
    setIsStaff(readSession()?.role === "moderador");
    setReady(true);
    const refresh = () => setState(readSecurityState());
    refresh();
    return subscribeToSecurityState(refresh);
  }, []);

  const filteredAccounts = useMemo(() => state.accounts.filter((account) => !query.trim() || `${account.name} ${account.email} ${account.role}`.toLocaleLowerCase("pt-BR").includes(query.trim().toLocaleLowerCase("pt-BR"))), [state.accounts, query]);
  const visibleAccounts = filteredAccounts.slice((accountPage - 1) * pageSize, accountPage * pageSize);
  const visibleReports = state.reports.slice((reportPage - 1) * pageSize, reportPage * pageSize);
  const visibleAudit = state.audit.slice((auditPage - 1) * pageSize, auditPage * pageSize);
  const openReports = state.reports.filter((report) => report.status === "aberta" || report.status === "em_analise").length;
  const suspended = state.accounts.filter((account) => account.status === "suspensa").length;
  const verified = state.accounts.filter((account) => account.role === "profissional" && account.verified).length;

  useEffect(() => setAccountPage(1), [query]);

  if (!ready) return <div className="surface p-8 text-center text-sm text-muted-foreground">Verificando acesso da equipe…</div>;
  if (!isStaff) return <div className="surface mx-auto max-w-lg p-8 text-center"><ShieldCheck className="mx-auto h-8 w-8 text-primary" /><h1 className="mt-3 font-display text-xl font-bold">Área exclusiva da equipe</h1><p className="mt-2 text-sm text-muted-foreground">Entre pelo acesso demonstrativo da Equipe ServiX para abrir os controles de segurança.</p><a href="/entrar?perfil=moderador" className="mt-5 inline-flex rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground">Entrar como equipe</a></div>;

  const tabs: { id: PanelTab; label: string; icon: typeof FileWarning; count?: number }[] = [
    { id: "denuncias", label: "Denúncias", icon: FileWarning, count: openReports },
    { id: "contas", label: "Contas e perfis", icon: Users },
    { id: "auditoria", label: "Auditoria", icon: History },
  ];

  return <div className="space-y-5">
    <PageTitle eyebrow="Equipe ServiX · confiança e segurança" title="Controle e segurança" subtitle="Ações de acesso, revisão de conteúdo e rastreabilidade para a equipe de moderação." action={<span className="inline-flex items-center gap-2 rounded-full bg-accent px-3 py-2 text-xs font-bold text-accent-foreground"><ShieldCheck className="h-4 w-4" />Painel interno</span>} />

    <section className="grid gap-3 sm:grid-cols-3">
      <Metric icon={FileWarning} label="Denúncias em aberto" value={openReports} tone="bg-status-warning/15 text-status-warning-foreground" />
      <Metric icon={Ban} label="Contas suspensas" value={suspended} tone="bg-destructive/10 text-destructive" />
      <Metric icon={UserRoundCheck} label="Profissionais verificados" value={verified} tone="bg-accent text-accent-foreground" />
    </section>

    <div className="flex gap-1 overflow-x-auto rounded-full bg-muted p-1">{tabs.map(({ id, label, icon: Icon, count }) => <button key={id} onClick={() => setTab(id)} className={cn("inline-flex shrink-0 items-center gap-2 rounded-full px-4 py-2.5 text-sm font-semibold", tab === id ? "bg-card text-foreground shadow-sm" : "text-muted-foreground")}><Icon className="h-4 w-4" />{label}{count ? <span className="rounded-full bg-status-warning/15 px-2 py-0.5 text-[10px] font-bold text-status-warning-foreground">{count}</span> : null}</button>)}</div>

    {tab === "denuncias" && <section className="surface overflow-hidden"><div className="flex flex-wrap items-center justify-between gap-3 border-b p-4 sm:p-5"><div><h2 className="font-display text-lg font-bold">Fila de revisão</h2><p className="text-xs text-muted-foreground">Denúncias de perfis e anúncios recebidas pela plataforma.</p></div><span className="rounded-full bg-muted px-3 py-1.5 text-xs font-bold">{state.reports.length} registros</span></div>
      {state.reports.length ? <><div className="divide-y">{visibleReports.map((report) => <article key={report.id} className="grid gap-3 p-4 sm:grid-cols-[minmax(0,1fr)_12rem] sm:items-center sm:p-5"><div><div className="flex flex-wrap items-center gap-2"><span className="rounded-full bg-muted px-2.5 py-1 text-[10px] font-bold uppercase">{report.subjectType === "profissional" ? "Perfil profissional" : "Anúncio"}</span><span className={cn("rounded-full px-2.5 py-1 text-[10px] font-bold", report.status === "aberta" ? "bg-status-warning/15 text-status-warning-foreground" : report.status === "em_analise" ? "bg-primary/10 text-primary" : "bg-accent text-accent-foreground")}>{reportStateLabels[report.status]}</span><time className="text-[10px] text-muted-foreground">{new Date(report.createdAt).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" })}</time></div><h3 className="mt-2 font-display font-bold">{report.subjectName}</h3><p className="text-sm font-semibold">{report.reason}</p><p className="mt-1 text-sm leading-relaxed text-muted-foreground">{report.detail}</p></div><label className="space-y-1 text-xs font-semibold text-muted-foreground">Situação<select value={report.status} onChange={(event) => { if (setModerationReportStatus(report.id, event.target.value as typeof report.status)) toast.success("Denúncia atualizada e registrada na auditoria."); }} className="w-full rounded-xl border bg-background px-3 py-2.5 text-sm font-semibold text-foreground">{Object.entries(reportStateLabels).map(([value, label]) => <option key={value} value={value}>{label}</option>)}</select></label></article>)}</div><div className="px-4 sm:px-5"><Pagination currentPage={reportPage} totalItems={state.reports.length} pageSize={pageSize} onPageChange={setReportPage} label="denúncias" /></div></> : <EmptyState icon={BadgeCheck} title="Nenhuma denúncia" detail="Novos relatos enviados pelos clientes aparecerão aqui." />}
    </section>}

    {tab === "contas" && <section className="surface overflow-hidden"><div className="flex flex-col gap-3 border-b p-4 sm:flex-row sm:items-center sm:justify-between sm:p-5"><div><h2 className="font-display text-lg font-bold">Acessos e confiança</h2><p className="text-xs text-muted-foreground">Suspenda contas e atualize o selo de verificação dos profissionais.</p></div><label className="flex items-center gap-2 rounded-xl border bg-background px-3 py-2"><Search className="h-4 w-4 text-muted-foreground" /><input value={query} onChange={(event) => setQuery(event.target.value)} placeholder="Buscar conta" className="min-w-0 bg-transparent text-sm outline-none" /></label></div>
      <div className="divide-y">{visibleAccounts.map((account) => <article key={account.id} className="flex flex-col gap-3 p-4 sm:flex-row sm:items-center sm:p-5"><div className="grid h-10 w-10 shrink-0 place-items-center rounded-xl bg-muted font-display font-bold text-muted-foreground">{account.name.split(" ").map((part) => part[0]).slice(0, 2).join("")}</div><div className="min-w-0 flex-1"><div className="flex flex-wrap items-center gap-2"><h3 className="font-semibold">{account.name}</h3><span className="rounded-full bg-muted px-2.5 py-1 text-[10px] font-bold capitalize">{account.role}</span><span className={cn("rounded-full px-2.5 py-1 text-[10px] font-bold", account.status === "ativa" ? "bg-accent text-accent-foreground" : "bg-destructive/10 text-destructive")}>{account.status === "ativa" ? "Ativa" : "Suspensa"}</span>{account.role === "profissional" && account.verified && <span className="inline-flex items-center gap-1 rounded-full bg-primary/10 px-2.5 py-1 text-[10px] font-bold text-primary"><BadgeCheck className="h-3 w-3" />Verificado</span>}</div><p className="mt-1 truncate text-xs text-muted-foreground">{account.email} · último acesso {account.lastSeen}</p></div><div className="flex flex-wrap gap-2">{account.role === "profissional" && <button onClick={() => { if (setDemoAccountVerified(account.id, !account.verified)) toast.success(account.verified ? "Verificação removida." : "Profissional verificado."); }} className="inline-flex items-center gap-1.5 rounded-full border px-3 py-2 text-xs font-bold hover:bg-muted"><UserRoundCheck className="h-3.5 w-3.5" />{account.verified ? "Remover selo" : "Verificar"}</button>}{account.role !== "moderador" && <button onClick={() => { const next = account.status === "ativa" ? "suspensa" : "ativa"; if (setDemoAccountStatus(account.id, next)) toast.success(next === "suspensa" ? "Acesso suspenso. O profissional também foi removido da busca." : "Acesso restabelecido."); }} className={cn("inline-flex items-center gap-1.5 rounded-full border px-3 py-2 text-xs font-bold", account.status === "ativa" ? "text-destructive hover:bg-destructive/5" : "text-status-success hover:bg-accent")}><Ban className="h-3.5 w-3.5" />{account.status === "ativa" ? "Suspender acesso" : "Restabelecer"}</button>}</div></article>)}{!visibleAccounts.length && <EmptyState icon={Users} title="Nenhuma conta encontrada" detail="Tente outro nome ou e-mail." />}</div>
      <div className="px-4 sm:px-5"><Pagination currentPage={accountPage} totalItems={filteredAccounts.length} pageSize={pageSize} onPageChange={setAccountPage} label="contas" /></div>
    </section>}

    {tab === "auditoria" && <section className="surface overflow-hidden"><div className="border-b p-4 sm:p-5"><h2 className="font-display text-lg font-bold">Registro de auditoria</h2><p className="text-xs text-muted-foreground">Cada ação administrativa fica registrada neste navegador com horário e alvo.</p></div>{state.audit.length ? <><div className="divide-y">{visibleAudit.map((event) => <div key={event.id} className="flex flex-wrap items-center justify-between gap-3 p-4 sm:px-5"><div><p className="text-sm font-semibold">{event.action}</p><p className="mt-0.5 text-xs text-muted-foreground">{event.subject} · por {event.actor}</p></div><time className="text-xs text-muted-foreground">{new Date(event.createdAt).toLocaleString("pt-BR", { dateStyle: "short", timeStyle: "short" })}</time></div>)}</div><div className="px-4 sm:px-5"><Pagination currentPage={auditPage} totalItems={state.audit.length} pageSize={pageSize} onPageChange={setAuditPage} label="registros" /></div></> : <EmptyState icon={History} title="Ainda não há ações registradas" detail="A suspensão de contas e a revisão das denúncias serão listadas aqui." />}</section>}

    <p className="rounded-xl bg-muted px-4 py-3 text-xs leading-relaxed text-muted-foreground">Este console grava demonstrações no armazenamento local do navegador. Para garantir segurança real, é necessário vincular identidade, permissões, bloqueios, denúncias e logs a serviços de backend protegidos.</p>
  </div>;
}

function Metric({ icon: Icon, label, value, tone }: { icon: typeof FileWarning; label: string; value: number; tone: string }) {
  return <article className="surface flex items-center gap-3 p-4"><span className={cn("grid h-10 w-10 place-items-center rounded-xl", tone)}><Icon className="h-5 w-5" /></span><span><span className="block text-xs text-muted-foreground">{label}</span><strong className="font-display text-2xl font-extrabold">{value}</strong></span></article>;
}

function EmptyState({ icon: Icon, title, detail }: { icon: typeof FileWarning; title: string; detail: string }) {
  return <div className="p-10 text-center"><Icon className="mx-auto h-8 w-8 text-muted-foreground" /><p className="mt-3 font-semibold">{title}</p><p className="mt-1 text-sm text-muted-foreground">{detail}</p></div>;
}
