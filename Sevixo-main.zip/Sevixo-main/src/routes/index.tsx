import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useRef, useState } from "react";
import {
  ArrowRight,
  ChevronLeft,
  ChevronRight,
  MapPin,
  Building2,
  BriefcaseBusiness,
} from "lucide-react";
import { categories, type Professional } from "@/lib/demo-data";
import { EmptyState } from "@/components/app/workspace-ui";
import { CategoryCover, ProCard } from "@/components/app/ui-bits";
import { distanceBetweenKm, readDeviceLocation, subscribeToLocation } from "@/lib/location-store";
import { HomeBannerCarousel } from "@/components/app/ad-placement";
import {
  getClientFacingProfessionals,
  subscribeToProfessionalProfile,
} from "@/lib/professional-store";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "ServiX — Encontre profissionais confiáveis perto de você" },
      {
        name: "description",
        content:
          "Montador, eletricista, encanador, diarista e mais. Compare avaliações, preços e contrate pelo app.",
      },
      { property: "og:title", content: "ServiX — Qual serviço você precisa?" },
      {
        property: "og:description",
        content: "Marketplace de serviços sob demanda para pessoas e empresas.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  component: Home,
});

function Home() {
  const [nearbyPros, setNearbyPros] = useState<Professional[]>([]);
  const [hasDeviceLocation, setHasDeviceLocation] = useState(false);
  const categoryRailRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const rail = categoryRailRef.current;
    if (!rail) return;
    let dragging = false;
    let moved = false;
    let startX = 0;
    let startScrollLeft = 0;

    const start = (event: MouseEvent) => {
      if (event.button !== 0) return;
      dragging = true;
      moved = false;
      startX = event.clientX;
      startScrollLeft = rail.scrollLeft;
      rail.classList.add("is-dragging");
    };
    const move = (event: MouseEvent) => {
      if (!dragging) return;
      const delta = event.clientX - startX;
      if (Math.abs(delta) > 4) moved = true;
      if (moved) {
        rail.scrollLeft = startScrollLeft - delta;
        event.preventDefault();
      }
    };
    const stop = () => {
      if (!dragging) return;
      dragging = false;
      rail.classList.remove("is-dragging");
    };
    const blockClickAfterDrag = (event: MouseEvent) => {
      if (!moved) return;
      event.preventDefault();
      event.stopImmediatePropagation();
      moved = false;
    };

    rail.addEventListener("mousedown", start);
    rail.addEventListener("click", blockClickAfterDrag, true);
    window.addEventListener("mousemove", move, { passive: false });
    window.addEventListener("mouseup", stop);
    window.addEventListener("blur", stop);
    return () => {
      rail.removeEventListener("mousedown", start);
      rail.removeEventListener("click", blockClickAfterDrag, true);
      window.removeEventListener("mousemove", move);
      window.removeEventListener("mouseup", stop);
      window.removeEventListener("blur", stop);
    };
  }, []);
  useEffect(() => {
    const refresh = () => {
      const location = readDeviceLocation("cliente");
      setHasDeviceLocation(!!location);
      setNearbyPros(
        location
          ? getClientFacingProfessionals()
              .map((pro) =>
                pro.latitude === undefined || pro.longitude === undefined
                  ? pro
                  : {
                      ...pro,
                      distanceKm:
                        Math.round(
                          distanceBetweenKm(location, {
                            latitude: pro.latitude,
                            longitude: pro.longitude,
                          }) * 10,
                        ) / 10,
                    },
              )
              .sort((a, b) => a.distanceKm - b.distanceKm)
          : getClientFacingProfessionals(),
      );
    };
    refresh();
    const unsubscribeLocation = subscribeToLocation(refresh);
    const unsubscribePros = subscribeToProfessionalProfile(refresh);
    return () => {
      unsubscribeLocation();
      unsubscribePros();
    };
  }, []);

  return (
    <div className="space-y-11 sm:space-y-14">
      <HomeBannerCarousel />

      {/* Categories */}
      <section>
        <div className="mb-5 flex items-end justify-between gap-4">
          <div>
            <h2 className="servix-section-title font-display text-2xl font-bold md:text-3xl">
              Encontre por categorias
            </h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Serviços para sua casa, rotina e empresa.
            </p>
          </div>
          <div className="flex shrink-0 items-center gap-1">
            <button
              type="button"
              onClick={() => categoryRailRef.current?.scrollBy({ left: -280, behavior: "smooth" })}
              aria-label="Ver categorias anteriores"
              className="grid h-8 w-8 place-items-center rounded-full border border-border bg-card text-foreground transition-colors hover:border-primary/40 hover:text-primary"
            >
              <ChevronLeft className="h-4 w-4" />
            </button>
            <button
              type="button"
              onClick={() => categoryRailRef.current?.scrollBy({ left: 280, behavior: "smooth" })}
              aria-label="Ver próximas categorias"
              className="grid h-8 w-8 place-items-center rounded-full border border-border bg-card text-foreground transition-colors hover:border-primary/40 hover:text-primary"
            >
              <ChevronRight className="h-4 w-4" />
            </button>
            <Link
              to="/buscar"
              className="ml-1 rounded-sm px-2 py-1.5 text-xs font-bold text-primary transition-colors hover:bg-primary/5 sm:text-sm"
            >
              Ver todas
            </Link>
          </div>
        </div>
        <div
          ref={categoryRailRef}
          role="navigation"
          aria-label="Categorias de serviços"
          onDragStart={(event) => event.preventDefault()}
          className="servix-category-rail -mx-4 flex gap-3 overflow-x-auto overscroll-x-contain px-4 pb-3 pt-2 cursor-grab select-none active:cursor-grabbing touch-pan-x md:mx-0 md:gap-5 md:px-0"
          style={{ scrollBehavior: "auto" }}
        >
          {categories.map((c) => (
            <Link
              key={c.slug}
              to="/buscar"
              search={{ cat: c.slug }}
              className="group flex w-[5.75rem] shrink-0 snap-start flex-col items-center gap-2 text-center focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring sm:w-28 sm:gap-2.5"
            >
              <CategoryCover
                slug={c.slug}
                className="aspect-square w-[5.25rem] rounded-full border-2 border-background bg-muted shadow-[0_1px_4px_rgb(10_40_26/0.14)] ring-1 ring-border/80 transition-[box-shadow,transform,ring-color] duration-200 group-hover:-translate-y-0.5 group-hover:ring-2 group-hover:ring-primary sm:w-24"
              />
              <span className="line-clamp-2 min-h-9 w-full text-xs font-semibold leading-4 text-foreground transition-colors group-hover:text-primary sm:text-sm sm:leading-5">
                {c.name}
              </span>
            </Link>
          ))}
        </div>
      </section>

      {/* Near you */}
      <section>
        <div className="mb-6 flex flex-col gap-4 border-b border-border pb-5 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <p className="mb-2 text-xs font-semibold text-primary">Serviços na sua região</p>
            <h2 className="servix-section-title font-display text-2xl font-bold md:text-3xl">
              Perto de você
            </h2>
            <p className="mt-1.5 flex items-center gap-1.5 text-sm text-muted-foreground">
              <MapPin className="h-4 w-4 shrink-0 text-primary" />
              {hasDeviceLocation
                ? "Profissionais ordenados pela sua localização"
                : "Encontre profissionais que atendem na sua região"}
            </p>
          </div>
          <div className="flex flex-wrap items-center gap-3">
            <span className="inline-flex items-center gap-2 rounded-full border border-border bg-card px-3 py-1.5 text-xs font-medium text-muted-foreground">
              <span
                className={
                  hasDeviceLocation
                    ? "h-1.5 w-1.5 rounded-full bg-status-success"
                    : "h-1.5 w-1.5 rounded-full bg-muted-foreground/50"
                }
              />
              {hasDeviceLocation ? "Localização ativa" : "Localização não definida"}
            </span>
            <Link
              to="/profissionais"
              className="inline-flex items-center gap-1 rounded-sm px-2 py-1.5 text-sm font-bold text-primary transition-colors hover:bg-primary/5"
            >
              Ver profissionais <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
        </div>
        {nearbyPros.length ? (
          <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-3">
            {nearbyPros.slice(0, 3).map((p) => (
              <div key={p.id}>
                <ProCard pro={p} />
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            icon={MapPin}
            title="Encontre ajuda na sua região"
            description="Os profissionais disponíveis aparecerão aqui conforme seus serviços forem publicados."
          >
            <Link
              to="/profissionais"
              className="inline-flex items-center gap-2 rounded-md border bg-card px-4 py-2.5 text-sm font-semibold text-primary hover:bg-muted"
            >
              Consultar profissionais <ArrowRight className="h-4 w-4" />
            </Link>
          </EmptyState>
        )}
      </section>

      {/* How it works */}
      <section className="overflow-hidden rounded-xl border border-border bg-card p-5 sm:p-8 lg:p-10">
        <div className="max-w-xl">
          <h2 className="text-2xl font-bold tracking-tight md:text-3xl">
            Do que você precisa ao serviço realizado.
          </h2>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            Encontre o profissional certo e combine os detalhes com clareza, em cada etapa.
          </p>
        </div>
        <div className="mt-7 grid gap-5 md:grid-cols-3">
          {[
            [
              "Encontre seu serviço",
              "Explore as especialidades e compare os perfis. Se preferir, publique um pedido e receba propostas.",
            ],
            [
              "Combine os detalhes",
              "Converse com o profissional para definir o atendimento, o valor e o prazo antes de confirmar.",
            ],
            [
              "Acompanhe e avalie",
              "Consulte seus serviços, acompanhe o andamento e compartilhe sua experiência após a conclusão.",
            ],
          ].map(([title, description], index) => (
            <div key={title} className="min-w-0 border-t border-border pt-5">
              <span className="text-sm font-bold text-primary">0{index + 1}</span>
              <h3 className="mt-3 text-lg font-bold">{title}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{description}</p>
            </div>
          ))}
        </div>
      </section>

      <section
        aria-label="Conheça outras formas de usar a ServiX"
        className="grid gap-4 lg:grid-cols-2"
      >
        <article className="flex flex-col items-start rounded-xl border border-border bg-card p-6 sm:p-8">
          <span className="grid h-11 w-11 place-items-center rounded-sm bg-primary/10 text-primary">
            <Building2 className="h-5 w-5" />
          </span>
          <h2 className="mt-5 font-display text-xl font-bold sm:text-2xl">
            Para empresas, imobiliárias e condomínios
          </h2>
          <p className="mt-2 max-w-xl text-sm leading-relaxed text-muted-foreground">
            Encontre profissionais para sua operação e publique uma oportunidade para receber
            propostas.
          </p>
          <Link
            to="/vagas"
            className="mt-5 inline-flex items-center gap-2 rounded-sm bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground transition-colors hover:bg-primary/90"
          >
            Publicar uma oportunidade <ArrowRight className="h-4 w-4" />
          </Link>
        </article>

        <article className="flex flex-col items-start rounded-xl border border-primary/20 bg-primary p-6 text-primary-foreground sm:p-8">
          <span className="grid h-11 w-11 place-items-center rounded-sm bg-white/10 text-brand">
            <BriefcaseBusiness className="h-5 w-5" />
          </span>
          <h2 className="mt-5 font-display text-xl font-bold sm:text-2xl">
            É profissional? Ganhe mais com a ServiX
          </h2>
          <p className="mt-2 max-w-xl text-sm leading-relaxed text-primary-foreground/75">
            Apresente seu trabalho, encontre novas oportunidades e amplie sua carteira de clientes.
          </p>
          <Link
            to="/ativar-profissional"
            className="mt-5 inline-flex items-center gap-2 rounded-sm bg-brand px-4 py-2.5 text-sm font-bold text-brand-foreground transition-colors hover:brightness-95"
          >
            Criar perfil profissional <ArrowRight className="h-4 w-4" />
          </Link>
        </article>
      </section>
    </div>
  );
}
