import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { MessagesPage } from "@/components/app/messages-page";

export const Route = createFileRoute("/mensagens")({
  validateSearch: (search) => z.object({ thread: z.string().optional() }).parse(search),
  head: () => ({ meta: [{ title: "Mensagens — ServiX" }, { name: "description", content: "Converse com os profissionais dos seus serviços." }] }),
  component: function CustomerMessages() {
    const { thread } = Route.useSearch();
    return <MessagesPage role="cliente" initialThread={thread} />;
  },
});
