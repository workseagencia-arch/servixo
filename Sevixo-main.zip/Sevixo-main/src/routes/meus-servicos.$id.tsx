import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowLeft, CalendarDays, Clock, MapPin, MessageCircle, Wrench } from "lucide-react";
import {
  brl,
  findBooking,
  findPro,
  myOrders,
  readQuoteRequests,
  subscribeToBookings,
  subscribeToQuoteRequests,
  orderSteps,
  type Booking,
} from "@/lib/demo-data";
import { Avatar, PageTitle, StatusPill } from "@/components/app/ui-bits";
import {
  EmptyState,
  MetricCard,
  actionClass,
  secondaryActionClass,
} from "@/components/app/workspace-ui";
import { getClientFacingProfessional, readProfessionalProfile } from "@/lib/professional-store";
import { readSession } from "@/lib/auth-store";
import { startProfessionalChat } from "@/lib/message-store";

export const Route = createFileRoute("/meus-servicos/$id")({
  head: () => ({ meta: [{ title: "Detalhes do serviço — ServiX" }] }),
  component: OrderDetail,
});
function OrderDetail() {
  const { id } = Route.useParams();
  const navigate = useNavigate();
  const [booking, setBooking] = useState<Booking | null>(null);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    const refresh = () => {
      const record = findBooking(id);
      const email = readSession()?.email.toLocaleLowerCase("pt-BR");
      const owner =
        record?.ownerEmail ?? readQuoteRequests().find((item) => item.bookingId === id)?.ownerEmail;
      setBooking(
        record && email && (!owner || owner.toLocaleLowerCase("pt-BR") === email)
          ? { ...record }
          : null,
      );
      setReady(true);
    };
    refresh();
    const a = subscribeToBookings(refresh);
    const b = subscribeToQuoteRequests(refresh);
    return () => {
      a();
      b();
    };
  }, [id]);
  const legacy = myOrders.find((item) => item.id === id);
  if (!ready)
    return (
      <p role="status" className="py-16 text-center text-sm text-muted-foreground">
        Carregando os detalhes do serviço…
      </p>
    );
  if (!booking && !legacy)
    return (
      <EmptyState
        icon={Wrench}
        title="Serviço não encontrado"
        description="Este pedido não está disponível na sua conta. Confira seus serviços para continuar."
      >
        <Link to="/meus-servicos" className={secondaryActionClass}>
          Voltar aos meus serviços
        </Link>
      </EmptyState>
    );
  const title = booking?.service ?? legacy!.title;
  const status = booking?.status ?? legacy!.status;
  const proId = booking?.proId ?? legacy?.proId;
  const pro = proId
    ? (findPro(proId) ??
      (proId === "current-user" && readProfessionalProfile().name
        ? getClientFacingProfessional()
        : undefined))
    : undefined;
  const price = booking?.price ?? legacy?.price;
  const chat = () => {
    const session = readSession();
    if (!session || !proId) return;
    const thread = startProfessionalChat({
      proId,
      service: title,
      clientName: session.name,
      sender: "cliente",
      price: price ?? null,
      ...(pro ? { professionalName: pro.name, professionalPhotoUrl: pro.photoUrl ?? "" } : {}),
    });
    navigate({ to: "/mensagens", search: { thread: thread.id } });
  };
  const index = orderSteps.indexOf(status);
  return (
    <div className="servix-workspace">
      <Link
        to="/meus-servicos"
        className="mb-5 inline-flex items-center gap-2 text-sm font-semibold text-muted-foreground hover:text-primary"
      >
        <ArrowLeft className="h-4 w-4" />
        Meus serviços
      </Link>
      <PageTitle
        title={title}
        subtitle={`Contratação ${id}`}
        action={<StatusPill status={status} />}
      />
      <div className="mb-6 grid gap-3 sm:grid-cols-3">
        <MetricCard
          label="Valor combinado"
          value={price == null ? "Sob consulta" : brl(price)}
          emphasis
        />
        <MetricCard
          icon={CalendarDays}
          label="Data"
          value={booking?.date ?? legacy?.when ?? "A combinar"}
        />
        <MetricCard icon={Clock} label="Horário" value={booking?.time ?? "A combinar"} />
      </div>
      <div className="grid items-start gap-5 lg:grid-cols-[minmax(0,1fr)_20rem]">
        <section className="min-w-0 rounded-xl border bg-card p-5 sm:p-6">
          <h2 className="text-lg font-bold">Andamento do serviço</h2>
          <p className="mt-2 text-sm text-muted-foreground">
            O profissional atualiza as etapas conforme o trabalho acontece.
          </p>
          <ol className="mt-6 space-y-4">
            {orderSteps.map((step, position) => (
              <li key={step} className="flex items-center gap-3">
                <span
                  className={`grid h-8 w-8 shrink-0 place-items-center rounded-md text-xs font-bold ${position <= index ? "bg-primary text-primary-foreground" : "bg-muted text-muted-foreground"}`}
                >
                  {position + 1}
                </span>
                <span
                  className={`text-sm ${position === index ? "font-bold text-primary" : "text-muted-foreground"}`}
                >
                  {step}
                </span>
              </li>
            ))}
          </ol>
          <div className="mt-6 border-t pt-5">
            <h3 className="flex items-center gap-2 text-sm font-semibold">
              <MapPin className="h-4 w-4 text-primary" />
              Local do atendimento
            </h3>
            <p className="mt-2 text-sm leading-relaxed text-muted-foreground">
              {booking
                ? `${booking.address}, ${booking.number}${booking.complement ? ` · ${booking.complement}` : ""} · CEP ${booking.cep}`
                : (legacy?.place ?? "Endereço a combinar")}
            </p>
          </div>
        </section>
        <aside className="rounded-xl border bg-card p-5">
          <h2 className="mb-4 font-bold">Profissional responsável</h2>
          {pro ? (
            <div className="flex min-w-0 items-center gap-3">
              <Avatar pro={pro} size="sm" />
              <div className="min-w-0">
                <p className="text-sm font-semibold">{pro.name}</p>
                <p className="mt-1 text-xs text-muted-foreground">{pro.role}</p>
              </div>
            </div>
          ) : (
            <p className="text-sm text-muted-foreground">Informações do perfil indisponíveis.</p>
          )}
          {proId && (
            <button onClick={chat} className={`${actionClass} mt-5 w-full`}>
              <MessageCircle className="h-4 w-4" />
              Conversar
            </button>
          )}
          {pro && (
            <Link
              to="/profissional/$id"
              params={{ id: pro.id }}
              className={`${secondaryActionClass} mt-2 w-full`}
            >
              Ver perfil
            </Link>
          )}
        </aside>
      </div>
    </div>
  );
}
