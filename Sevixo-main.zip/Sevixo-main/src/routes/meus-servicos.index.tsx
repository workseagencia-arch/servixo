import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { toast } from "sonner";
import { Check, Clock3, FilePlus2, MapPin, MessageCircle, Search, Star } from "lucide-react";
import {
  brl,
  findPro,
  myOrders,
  readBookings,
  subscribeToBookings,
  readQuoteRequests,
  subscribeToQuoteRequests,
  acceptQuoteProposal,
  quoteWhenLabel,
  categoryName,
  type Booking,
  type Order,
} from "@/lib/demo-data";
import { Avatar, PageTitle, StatusPill } from "@/components/app/ui-bits";
import {
  EmptyState,
  FilterInput,
  MetricCard,
  PanelTabs,
  WorkspaceIntro,
  actionClass,
  secondaryActionClass,
} from "@/components/app/workspace-ui";
import { normalizeSearch } from "@/lib/search";
import { Pagination } from "@/components/app/pagination";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { QuoteDialog } from "@/components/app/booking-dialogs";
import { AdPlacement } from "@/components/app/ad-placement";
import { addCustomerReview, readClientReviews, subscribeToClientReviews } from "@/lib/review-store";
import { readSession, subscribeToSession, type AuthSession } from "@/lib/auth-store";
import { getClientFacingProfessional, readProfessionalProfile } from "@/lib/professional-store";
import { startProfessionalChat } from "@/lib/message-store";

export const Route = createFileRoute("/meus-servicos/")({
  head: () => ({ meta: [{ title: "Meus serviços — ServiX" }] }),
  validateSearch: (
    s: Record<string, unknown>,
  ): { tab?: "Em andamento" | "Orçamentos" | "Histórico" } =>
    s["tab"] === "Orçamentos" || s["tab"] === "Histórico" || s["tab"] === "Em andamento"
      ? { tab: s["tab"] }
      : {},
  component: MyServices,
});
type Tab = "Em andamento" | "Orçamentos" | "Histórico";
function resolvePro(id?: string | null) {
  return id
    ? (findPro(id) ??
        (id === "current-user" && readProfessionalProfile().name
          ? getClientFacingProfessional()
          : undefined))
    : undefined;
}
function MyServices() {
  const search = Route.useSearch();
  const navigate = useNavigate();
  const [tab, setTab] = useState<Tab>(search.tab ?? "Em andamento");
  const [bookings, setBookings] = useState<Booking[]>([]);
  const [session, setSession] = useState<AuthSession | null>(null);
  const [quotes, setQuotes] = useState<ReturnType<typeof readQuoteRequests>>([]);
  const [reviews, setReviews] = useState<ReturnType<typeof readClientReviews>>([]);
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [rateFor, setRateFor] = useState<Order | null>(null);
  const [stars, setStars] = useState(5);
  const [reviewText, setReviewText] = useState("");
  useEffect(() => setTab(search.tab ?? "Em andamento"), [search.tab]);
  useEffect(() => {
    const refresh = () => {
      setBookings([...readBookings()]);
      setQuotes([...readQuoteRequests()]);
    };
    refresh();
    const a = subscribeToBookings(refresh);
    const b = subscribeToQuoteRequests(refresh);
    return () => {
      a();
      b();
    };
  }, []);
  useEffect(() => {
    const refresh = () => setSession(readSession());
    refresh();
    return subscribeToSession(refresh);
  }, []);
  useEffect(() => {
    const refresh = () => setReviews(readClientReviews());
    refresh();
    return subscribeToClientReviews(refresh);
  }, []);
  useEffect(() => setPage(1), [query, tab]);
  const email = session?.email.toLocaleLowerCase("pt-BR");
  const accountQuotes = quotes.filter(
    (item) => !!email && item.ownerEmail?.toLocaleLowerCase("pt-BR") === email,
  );
  const accountBookings = bookings.filter(
    (item) =>
      !!email &&
      (item.ownerEmail?.toLocaleLowerCase("pt-BR") === email ||
        (!item.ownerEmail && accountQuotes.some((quote) => quote.bookingId === item.id))),
  );
  const orders: Order[] = [
    ...accountBookings.map((item) => ({
      id: item.id,
      title: item.service,
      proId: item.proId,
      status: item.status,
      when: item.date ? `${item.date}${item.time ? ` · ${item.time}` : ""}` : "A combinar",
      price: item.price,
      kind: "fixo" as const,
      place: `${item.address}${item.number ? `, ${item.number}` : ""}`,
    })),
    ...myOrders,
  ];
  const active = orders.filter((item) => item.status !== "Concluído");
  const completed = orders.filter((item) => item.status === "Concluído");
  const list = (tab === "Histórico" ? completed : active).filter((item) =>
    normalizeSearch(`${item.title} ${item.id} ${item.place ?? ""}`).includes(
      normalizeSearch(query),
    ),
  );
  const quoteList = accountQuotes.filter((item) =>
    normalizeSearch(`${item.description} ${item.id} ${categoryName(item.category)}`).includes(
      normalizeSearch(query),
    ),
  );
  const accept = (id: string, proposalId: string) => {
    const booking = acceptQuoteProposal(id, proposalId);
    if (!booking) {
      toast.error("Não foi possível aceitar esta proposta.");
      return;
    }
    toast.success("Proposta aceita. Serviço adicionado aos seus pedidos.");
    navigate({ to: "/meus-servicos/$id", params: { id: booking.id } });
  };
  const chat = (order: Order) => {
    const pro = resolvePro(order.proId);
    if (!order.proId || !session) return;
    const thread = startProfessionalChat({
      proId: order.proId,
      clientName: session.name,
      service: order.title,
      sender: "cliente",
      price: order.price,
      ...(pro ? { professionalName: pro.name, professionalPhotoUrl: pro.photoUrl ?? "" } : {}),
    });
    navigate({ to: "/mensagens", search: { thread: thread.id } });
  };
  return (
    <div className="servix-workspace">
      <PageTitle
        title="Meus serviços"
        subtitle="Acompanhe propostas, contratações e o histórico dos seus pedidos."
        action={
          <button onClick={() => setQuoteOpen(true)} className={actionClass}>
            <FilePlus2 className="h-4 w-4" /> Pedir orçamento
          </button>
        }
      />
      <WorkspaceIntro
        title="Tudo o que você contratou, bem organizado."
        description="Consulte as propostas recebidas, confira os detalhes de cada trabalho e converse com o profissional quando precisar."
      >
        <Link
          to="/profissionais"
          className="inline-flex items-center gap-2 rounded-md border border-white/30 px-4 py-3 text-sm font-semibold"
        >
          <Search className="h-4 w-4" />
          Encontrar profissionais
        </Link>
      </WorkspaceIntro>
      <section className="mb-6 grid gap-3 sm:grid-cols-3">
        <MetricCard label="Em andamento" value={active.length} icon={Clock3} emphasis />
        <MetricCard
          label="Aguardando propostas"
          value={accountQuotes.filter((item) => item.status === "Aguardando propostas").length}
          icon={FilePlus2}
        />
        <MetricCard label="Concluídos" value={completed.length} icon={Check} />
      </section>
      <AdPlacement channel="servicos" compact className="mb-5" />
      <FilterInput
        label="Buscar nos meus serviços"
        placeholder="Busque pelo serviço, pedido ou endereço"
        value={query}
        onChange={setQuery}
      />
      <PanelTabs
        value={tab}
        onChange={(value) => {
          setTab(value);
          navigate({ to: "/meus-servicos", search: { tab: value }, replace: true });
        }}
        label="Pedidos e histórico"
        items={[
          { value: "Em andamento", label: "Em andamento", count: active.length },
          { value: "Orçamentos", label: "Orçamentos", count: accountQuotes.length },
          { value: "Histórico", label: "Histórico", count: completed.length },
        ]}
      />
      {tab === "Orçamentos" ? (
        <div className="space-y-4">
          {quoteList.slice((page - 1) * 10, page * 10).map((quote) => (
            <article key={quote.id} className="rounded-xl border bg-card p-5 sm:p-6">
              <div className="flex flex-wrap items-start justify-between gap-3">
                <div className="min-w-0 flex-1">
                  <p className="text-xs text-muted-foreground">
                    {quote.id} · {categoryName(quote.category)} · {quoteWhenLabel(quote)}
                  </p>
                  <h2 className="mt-2 text-lg font-bold">{quote.description}</h2>
                  <p className="mt-2 flex items-start gap-1.5 text-xs text-muted-foreground">
                    <MapPin className="h-3.5 w-3.5 shrink-0" />
                    {quote.address}, {quote.number}
                  </p>
                </div>
                <StatusPill status={quote.status} />
              </div>
              {quote.photos.length > 0 && (
                <div className="mt-4 flex flex-wrap gap-2">
                  {quote.photos.map((url, index) => (
                    <img
                      key={url}
                      src={url}
                      alt={`Referência ${index + 1}`}
                      className="h-16 w-16 rounded-md object-cover"
                    />
                  ))}
                </div>
              )}
              <div className="mt-5 border-t pt-4">
                <h3 className="mb-3 text-sm font-semibold">
                  {quote.status === "Aceito"
                    ? "Proposta escolhida"
                    : `${quote.proposals.length} propostas recebidas`}
                </h3>
                <div className="grid gap-3 lg:grid-cols-2">
                  {quote.proposals
                    .filter(
                      (item) => quote.status !== "Aceito" || item.id === quote.acceptedProposalId,
                    )
                    .map((proposal) => {
                      const pro = resolvePro(proposal.proId);
                      return (
                        <div
                          key={proposal.id}
                          className="min-w-0 rounded-lg border bg-muted/30 p-4"
                        >
                          <div className="flex items-center gap-3">
                            {pro && <Avatar pro={pro} size="sm" />}
                            <div className="min-w-0">
                              <p className="text-sm font-bold">
                                {pro?.name ?? "Profissional indisponível"}
                              </p>
                              <p className="mt-1 text-xs text-muted-foreground">
                                {pro?.role ?? "As informações deste perfil não estão disponíveis."}
                              </p>
                            </div>
                          </div>
                          <div className="mt-4 flex flex-wrap items-end justify-between gap-3">
                            <strong className="text-xl">{brl(proposal.price)}</strong>
                            <span className="text-xs text-muted-foreground">{proposal.days}</span>
                          </div>
                          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                            {proposal.note}
                          </p>
                          <div className="mt-4 flex flex-wrap gap-2">
                            {pro && (
                              <Link
                                to="/profissional/$id"
                                params={{ id: pro.id }}
                                className={secondaryActionClass}
                              >
                                Ver perfil
                              </Link>
                            )}
                            {quote.status === "Aceito" ? (
                              quote.bookingId && (
                                <Link
                                  to="/meus-servicos/$id"
                                  params={{ id: quote.bookingId }}
                                  className={actionClass}
                                >
                                  Ver contratação
                                </Link>
                              )
                            ) : (
                              <button
                                disabled={!pro}
                                onClick={() => accept(quote.id, proposal.id)}
                                className={actionClass}
                              >
                                Aceitar proposta
                              </button>
                            )}
                          </div>
                        </div>
                      );
                    })}
                </div>
                {!quote.proposals.length && (
                  <p className="text-sm text-muted-foreground">
                    Profissionais compatíveis poderão enviar propostas para seu pedido.
                  </p>
                )}
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="grid min-w-0 gap-4 lg:grid-cols-2">
          {list.slice((page - 1) * 10, page * 10).map((order) => {
            const pro = resolvePro(order.proId);
            const reviewed = order.rated || reviews.some((item) => item.bookingId === order.id);
            return (
              <article
                key={order.id}
                className="flex min-w-0 flex-col rounded-xl border bg-card p-5 sm:p-6"
              >
                <div className="flex flex-wrap items-start justify-between gap-3">
                  <span className="text-xs text-muted-foreground">
                    {order.id} · {order.when}
                  </span>
                  <StatusPill status={order.status} />
                </div>
                <h2 className="mt-3 text-lg font-bold">{order.title}</h2>
                {pro && (
                  <div className="mt-4 flex min-w-0 items-center gap-3">
                    <Avatar pro={pro} size="sm" />
                    <div className="min-w-0">
                      <p className="text-sm font-semibold">{pro.name}</p>
                      <p className="text-xs text-muted-foreground">{pro.role}</p>
                    </div>
                  </div>
                )}
                <p className="mt-4 flex items-start gap-2 text-xs text-muted-foreground">
                  <MapPin className="h-3.5 w-3.5 shrink-0" />
                  {order.place ?? "Endereço a combinar"}
                </p>
                <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t pt-4">
                  <strong className="text-xl">
                    {order.price == null ? "Sob consulta" : brl(order.price)}
                  </strong>
                  {reviewed && (
                    <span className="inline-flex items-center gap-1.5 text-xs text-primary">
                      <Check className="h-3.5 w-3.5" />
                      Avaliado
                    </span>
                  )}
                </div>
                <div className="mt-auto flex flex-wrap gap-2 pt-4">
                  <Link to="/meus-servicos/$id" params={{ id: order.id }} className={actionClass}>
                    Ver detalhes
                  </Link>
                  {order.proId && (
                    <button onClick={() => chat(order)} className={secondaryActionClass}>
                      <MessageCircle className="h-4 w-4" />
                      Conversar
                    </button>
                  )}
                  {order.status === "Concluído" && !reviewed && (
                    <button
                      onClick={() => {
                        setRateFor(order);
                        setStars(5);
                        setReviewText("");
                      }}
                      className={secondaryActionClass}
                    >
                      <Star className="h-4 w-4" />
                      Avaliar
                    </button>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      )}
      {(tab === "Orçamentos" ? !quoteList.length : !list.length) && (
        <EmptyState
          icon={FilePlus2}
          title={
            query
              ? "Nenhum pedido encontrado"
              : tab === "Histórico"
                ? "Seu histórico começa após o primeiro serviço"
                : tab === "Orçamentos"
                  ? "Você ainda não solicitou um orçamento"
                  : "Nenhum serviço em andamento"
          }
          description={
            query
              ? "Tente outro termo para localizar seu pedido."
              : "Encontre um profissional ou publique o que você precisa para receber propostas."
          }
        >
          <button onClick={() => setQuoteOpen(true)} className={actionClass}>
            Pedir orçamento
          </button>
        </EmptyState>
      )}
      <div className="mt-5">
        <Pagination
          currentPage={page}
          totalItems={tab === "Orçamentos" ? quoteList.length : list.length}
          pageSize={10}
          onPageChange={setPage}
          label={tab === "Orçamentos" ? "orçamentos" : "serviços"}
        />
      </div>
      <QuoteDialog open={quoteOpen} onOpenChange={setQuoteOpen} />
      <Dialog
        open={!!rateFor}
        onOpenChange={(open) => {
          if (!open) setRateFor(null);
        }}
      >
        <DialogContent className="rounded-xl sm:max-w-md">
          <DialogHeader>
            <DialogTitle>Como foi o serviço?</DialogTitle>
            <DialogDescription>
              Sua avaliação ajuda outros clientes a conhecer o trabalho deste profissional.
            </DialogDescription>
          </DialogHeader>
          <div className="flex justify-center gap-2 py-3">
            {[1, 2, 3, 4, 5].map((value) => (
              <button
                key={value}
                aria-label={`${value} estrelas`}
                aria-pressed={stars === value}
                onClick={() => setStars(value)}
              >
                <Star
                  className={`h-8 w-8 ${value <= stars ? "fill-status-warning text-status-warning" : "text-border"}`}
                />
              </button>
            ))}
          </div>
          <label className="text-sm font-semibold">
            Seu comentário
            <textarea
              rows={4}
              maxLength={500}
              value={reviewText}
              onChange={(event) => setReviewText(event.target.value)}
              placeholder="Conte sobre o atendimento e o resultado."
              className="mt-2 w-full rounded-md border bg-background p-3 text-sm font-normal outline-none"
            />
          </label>
          <button
            className={actionClass}
            onClick={() => {
              if (!rateFor) return;
              if (!addCustomerReview(rateFor.id, stars, reviewText)) {
                toast.error("Só é possível avaliar um serviço concluído, uma vez.");
                return;
              }
              setRateFor(null);
              toast.success("Avaliação enviada. Obrigado!");
            }}
          >
            Enviar avaliação
          </button>
        </DialogContent>
      </Dialog>
    </div>
  );
}
