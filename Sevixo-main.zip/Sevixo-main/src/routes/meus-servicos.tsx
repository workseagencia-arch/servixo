import { createFileRoute, Outlet } from "@tanstack/react-router";

export const Route = createFileRoute("/meus-servicos")({
  component: () => <Outlet />,
});
