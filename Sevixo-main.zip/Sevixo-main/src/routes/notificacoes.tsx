import { createFileRoute } from "@tanstack/react-router";
import { NotificationsPage } from "@/components/app/notifications-page";
import { hasProfessionalAccess, readSession } from "@/lib/auth-store";

function AccountNotifications() {
  return (
    <NotificationsPage
      roles={hasProfessionalAccess(readSession()) ? ["cliente", "profissional"] : ["cliente"]}
    />
  );
}

export const Route = createFileRoute("/notificacoes")({
  head: () => ({ meta: [{ title: "Notificações — ServiX" }] }),
  component: AccountNotifications,
});
