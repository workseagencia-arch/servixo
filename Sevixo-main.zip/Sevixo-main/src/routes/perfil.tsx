import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, type ChangeEvent } from "react";
import {
  ArrowRight,
  Bell,
  BriefcaseBusiness,
  Camera,
  CheckCircle2,
  ChevronRight,
  ClipboardList,
  LockKeyhole,
  MapPin,
  Pencil,
  Save,
  ShieldCheck,
  UserRound,
} from "lucide-react";
import { toast } from "sonner";
import {
  readClientProfile,
  saveClientProfile,
  subscribeToClientProfile,
  type EditableClientProfile,
} from "@/lib/client-profile-store";
import { hasProfessionalAccess, readSession, type AuthSession } from "@/lib/auth-store";
import { PageTitle } from "@/components/app/ui-bits";
import { AdPlacement } from "@/components/app/ad-placement";
import {
  readProfessionalOnboarding,
  subscribeToProfessionalOnboarding,
  type ProfessionalOnboardingStatus,
} from "@/lib/professional-onboarding-store";

export const Route = createFileRoute("/perfil")({
  head: () => ({
    meta: [
      { title: "Meu perfil — ServiX" },
      { name: "description", content: "Atualize seus dados de cliente e preferências." },
    ],
  }),
  component: Profile,
});

const inputClass =
  "w-full rounded-lg border border-input bg-card px-3.5 py-3 text-sm outline-none transition focus:border-primary focus:ring-2 focus:ring-ring/20 disabled:bg-muted/50 disabled:text-muted-foreground";
const clientTypes = [
  "Pessoa física",
  "Empresa",
  "Imobiliária",
  "Administradora",
  "Condomínio",
  "Comércio",
  "Escritório",
];
const initialProfile: EditableClientProfile = {
  name: "Sandson Eduardo",
  email: "sandson@email.com",
  phone: "",
  accountType: "Pessoa física",
  photoUrl: "",
  address: "",
  birthDate: "",
  taxId: "",
};

function Profile() {
  const [profile, setProfile] = useState(initialProfile);
  const [session, setSession] = useState<AuthSession | null>(null);
  const [onboarding, setOnboarding] = useState<ProfessionalOnboardingStatus | null>(null);
  const [editing, setEditing] = useState(false);
  const isProfessional = hasProfessionalAccess(session);

  useEffect(() => {
    const refresh = () => {
      const currentSession = readSession();
      setSession(currentSession);
      setProfile(readClientProfile());
      setOnboarding(currentSession ? readProfessionalOnboarding(currentSession.email) : null);
    };
    refresh();
    const unsubscribeProfile = subscribeToClientProfile(refresh);
    const unsubscribeOnboarding = subscribeToProfessionalOnboarding(refresh);
    window.addEventListener("servix:session-change", refresh);
    return () => {
      unsubscribeProfile();
      unsubscribeOnboarding();
      window.removeEventListener("servix:session-change", refresh);
    };
  }, []);

  const update = (field: keyof EditableClientProfile, value: string) =>
    setProfile((current) => ({ ...current, [field]: value }));

  const photoChanged = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/")) {
      toast.error("Escolha um arquivo de imagem.");
      return;
    }
    if (file.size > 3 * 1024 * 1024) {
      toast.error("A foto deve ter até 3 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => update("photoUrl", String(reader.result));
    reader.readAsDataURL(file);
  };

  const save = () => {
    if (!profile.name.trim() || !profile.email.trim()) {
      toast.error("Preencha seu nome e e-mail.");
      return;
    }
    saveClientProfile(profile);
    setEditing(false);
    toast.success("Perfil atualizado");
  };

  const initials = profile.name
    .split(" ")
    .map((part) => part[0])
    .slice(0, 2)
    .join("")
    .toUpperCase();

  return (
    <div className="mx-auto w-full max-w-6xl space-y-5">
      <PageTitle
        eyebrow="Conta ServiX"
        title="Meu perfil"
        subtitle="Organize seus dados, preferências e ferramentas da conta."
        action={
          <button
            type="button"
            onClick={() => (editing ? save() : setEditing(true))}
            className="inline-flex items-center gap-2 rounded-md bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground transition hover:bg-primary/90"
          >
            {editing ? <Save className="h-4 w-4" /> : <Pencil className="h-4 w-4" />}
            {editing ? "Salvar perfil" : "Editar perfil"}
          </button>
        }
      />

      <section className="surface overflow-hidden">
        <div className="bg-hero px-5 py-5 text-white sm:px-7">
          <p className="text-xs font-bold uppercase tracking-[0.14em] text-white/65">Seu espaço</p>
          <h2 className="mt-1 font-display text-xl font-bold sm:text-2xl">
            Bem-vindo(a), {profile.name.split(" ")[0] || "à ServiX"}
          </h2>
          <p className="mt-1 max-w-xl text-sm text-white/75">
            Seus dados ficam reunidos em um só lugar para você contratar e acompanhar serviços com
            tranquilidade.
          </p>
        </div>
        <div className="flex flex-wrap items-center gap-4 px-5 py-5 sm:px-7">
          <div className="relative -mt-1">
            {profile.photoUrl ? (
              <img
                src={profile.photoUrl}
                alt={`Foto de ${profile.name}`}
                className="h-16 w-16 rounded-full border-2 border-card object-cover ring-1 ring-border"
              />
            ) : (
              <div className="grid h-16 w-16 place-items-center rounded-full border-2 border-card bg-accent font-display text-xl font-bold text-accent-foreground ring-1 ring-border">
                {initials || "CL"}
              </div>
            )}
            {editing && (
              <label
                className="absolute -bottom-1 -right-1 grid h-8 w-8 cursor-pointer place-items-center rounded-md border bg-card shadow-sm"
                aria-label="Alterar foto"
              >
                <Camera className="h-4 w-4" />
                <input type="file" accept="image/*" className="sr-only" onChange={photoChanged} />
              </label>
            )}
          </div>
          <div className="min-w-0 flex-1">
            <p className="truncate font-display text-lg font-bold">{profile.name || "Seu nome"}</p>
            <p className="truncate text-sm text-muted-foreground">
              {profile.email || session?.email}
            </p>
          </div>
          <span className="inline-flex items-center gap-1.5 rounded-md bg-accent px-3 py-2 text-xs font-bold text-accent-foreground">
            {isProfessional ? (
              <BriefcaseBusiness className="h-4 w-4" />
            ) : (
              <UserRound className="h-4 w-4" />
            )}
            {isProfessional ? "Cliente + profissional" : "Conta cliente"}
          </span>
          {isProfessional && (
            <Link
              to="/pro/perfil"
              className="inline-flex items-center gap-1.5 rounded-md border px-3 py-2 text-xs font-bold hover:bg-muted"
            >
              Área profissional <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          )}
        </div>
      </section>

      <div className="grid gap-5 lg:grid-cols-[minmax(0,1fr)_19rem]">
        <div className="space-y-5">
          <section className="surface p-5 sm:p-6">
            <div className="mb-5 flex items-center gap-3 border-b pb-4">
              <span className="grid h-10 w-10 place-items-center rounded-md bg-secondary text-secondary-foreground">
                <UserRound className="h-5 w-5" />
              </span>
              <div>
                <h2 className="font-display font-bold">Dados da conta</h2>
                <p className="text-xs text-muted-foreground">
                  Informações usadas nos pedidos e nas preferências de atendimento.
                </p>
              </div>
            </div>
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="space-y-1.5 text-sm font-semibold">
                Nome civil completo
                <input
                  disabled={!editing}
                  value={profile.name}
                  onChange={(event) => update("name", event.target.value)}
                  className={inputClass}
                  autoComplete="name"
                />
              </label>
              <label className="space-y-1.5 text-sm font-semibold">
                E-mail
                <input
                  disabled={!editing}
                  type="email"
                  value={profile.email}
                  onChange={(event) => update("email", event.target.value)}
                  className={inputClass}
                  autoComplete="email"
                />
              </label>
              <label className="space-y-1.5 text-sm font-semibold">
                Telefone
                <input
                  disabled={!editing}
                  type="tel"
                  value={profile.phone}
                  onChange={(event) => update("phone", event.target.value)}
                  placeholder="(11) 99999-9999"
                  className={inputClass}
                  autoComplete="tel"
                />
              </label>
              <label className="space-y-1.5 text-sm font-semibold">
                CPF ou CNPJ
                <input
                  disabled={!editing}
                  value={profile.taxId}
                  onChange={(event) => update("taxId", event.target.value.replace(/[^\d./-]/g, "").slice(0, 18))}
                  placeholder="Documento da conta"
                  inputMode="numeric"
                  autoComplete="off"
                  className={inputClass}
                />
              </label>
              <label className="space-y-1.5 text-sm font-semibold">
                Data de nascimento
                <input
                  disabled={!editing}
                  type="date"
                  value={profile.birthDate}
                  onChange={(event) => update("birthDate", event.target.value)}
                  autoComplete="bday"
                  className={inputClass}
                />
              </label>
              <label className="space-y-1.5 text-sm font-semibold">
                Tipo de cliente
                <select
                  disabled={!editing}
                  value={profile.accountType}
                  onChange={(event) => update("accountType", event.target.value)}
                  className={inputClass}
                >
                  {clientTypes.map((type) => (
                    <option key={type}>{type}</option>
                  ))}
                </select>
              </label>
              <label className="space-y-1.5 text-sm font-semibold sm:col-span-2">
                Endereço principal
                <input
                  disabled={!editing}
                  value={profile.address}
                  onChange={(event) => update("address", event.target.value)}
                  placeholder="Rua, número, bairro e cidade"
                  className={inputClass}
                  autoComplete="street-address"
                />
              </label>
            </div>
          </section>

          <section className="surface divide-y overflow-hidden">
            <Link
              to="/meus-servicos"
              className="flex items-center gap-4 p-4 transition hover:bg-muted sm:p-5"
            >
              <span className="grid h-10 w-10 place-items-center rounded-md bg-accent text-accent-foreground">
                <ClipboardList className="h-5 w-5" />
              </span>
              <span className="flex-1">
                <span className="block text-sm font-semibold">Meus serviços</span>
                <span className="text-xs text-muted-foreground">
                  Pedidos, orçamentos e histórico
                </span>
              </span>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </Link>
            <Link
              to="/notificacoes"
              className="flex items-center gap-4 p-4 transition hover:bg-muted sm:p-5"
            >
              <span className="grid h-10 w-10 place-items-center rounded-md bg-secondary text-secondary-foreground">
                <Bell className="h-5 w-5" />
              </span>
              <span className="flex-1">
                <span className="block text-sm font-semibold">Notificações</span>
                <span className="text-xs text-muted-foreground">
                  Acompanhe atualizações da sua conta
                </span>
              </span>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </Link>
            <Link
              to="/buscar"
              className="flex items-center gap-4 p-4 transition hover:bg-muted sm:p-5"
            >
              <span className="grid h-10 w-10 place-items-center rounded-md bg-muted text-foreground">
                <MapPin className="h-5 w-5" />
              </span>
              <span className="flex-1">
                <span className="block text-sm font-semibold">Buscar profissionais</span>
                <span className="text-xs text-muted-foreground">
                  Encontre serviços perto de você
                </span>
              </span>
              <ChevronRight className="h-4 w-4 text-muted-foreground" />
            </Link>
            <div className="flex items-center gap-4 p-4 sm:p-5">
              <span className="grid h-10 w-10 place-items-center rounded-md bg-muted text-muted-foreground">
                <ShieldCheck className="h-5 w-5" />
              </span>
              <span className="flex-1">
                <span className="block text-sm font-semibold">Privacidade da conta</span>
                <span className="text-xs text-muted-foreground">
                Dados pessoais, contato e preferências da conta
                </span>
              </span>
              <LockKeyhole className="h-4 w-4 text-muted-foreground" />
            </div>
          </section>
        </div>

        <aside className="space-y-4">
          <section className="surface p-5">
            <div className="flex items-center gap-2">
              <ShieldCheck className="h-5 w-5 text-primary" />
              <h2 className="font-display font-bold">Cadastro profissional</h2>
            </div>
            {isProfessional && onboarding ? (
              <>
                <p className="mt-3 flex items-center gap-2 text-sm font-semibold text-status-success">
                  <CheckCircle2 className="h-4 w-4" /> Dados pessoais registrados
                </p>
                <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
                  Nome, telefone, e-mail, nascimento e endereço foram associados ao seu perfil da
                  conta. Você pode revisar esses dados a qualquer momento.
                </p>
              </>
            ) : isProfessional ? (
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                Complete seus dados pessoais, endereço e contato para ativar a área profissional.
              </p>
            ) : (
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                Ao ativar seu perfil profissional, você confirma seus dados pessoais e endereço.
              </p>
            )}
            {isProfessional && (
              <Link
                to="/pro/perfil"
                className="mt-4 inline-flex items-center gap-1.5 text-sm font-bold text-primary hover:underline"
              >
                Ver perfil profissional <ArrowRight className="h-4 w-4" />
              </Link>
            )}
          </section>

          {!isProfessional && (
            <Link
              to="/ativar-profissional"
              className="group block rounded-lg bg-primary p-5 text-primary-foreground transition hover:bg-primary/95"
            >
              <BriefcaseBusiness className="h-5 w-5" />
              <span className="mt-3 block font-display font-bold">Também presta serviços?</span>
              <span className="mt-1 block text-sm text-primary-foreground/75">
                Complete seu cadastro e atenda clientes pela mesma conta.
              </span>
              <span className="mt-4 inline-flex items-center gap-1 text-sm font-bold">
                Ativar perfil profissional{" "}
                <ArrowRight className="h-4 w-4 transition group-hover:translate-x-0.5" />
              </span>
            </Link>
          )}

          <AdPlacement channel="perfil" compact />
        </aside>
      </div>
    </div>
  );
}
