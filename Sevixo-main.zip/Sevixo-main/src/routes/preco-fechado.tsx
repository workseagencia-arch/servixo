import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { z } from "zod";
import { ArrowRight, Clock3, ShoppingBag } from "lucide-react";
import { PageTitle, CategoryCover, Avatar } from "@/components/app/ui-bits";
import { Pagination } from "@/components/app/pagination";
import { QuoteDialog } from "@/components/app/booking-dialogs";
import { AdPlacement } from "@/components/app/ad-placement";
import { CatalogSearch } from "@/components/app/catalog-search";
import { normalizeSearch } from "@/lib/search";
import { EmptyState, actionClass, secondaryActionClass } from "@/components/app/workspace-ui";
import {
  brl,
  categories,
  categoryName,
  type CategorySlug,
  type Professional,
} from "@/lib/demo-data";
import {
  getClientFacingProfessionals,
  subscribeToProfessionalProfile,
} from "@/lib/professional-store";
import { subscribeToSession } from "@/lib/auth-store";

const searchSchema = z.object({ q: z.string().optional(), cat: z.string().optional() });
export const Route = createFileRoute("/preco-fechado")({
  validateSearch: (search) => searchSchema.parse(search),
  head: () => ({ meta: [{ title: "Preço fechado — ServiX" }] }),
  component: FixedPricePage,
});
function FixedPricePage() {
  const { q, cat } = Route.useSearch();
  const navigate = useNavigate({ from: "/preco-fechado" });
  const [text, setText] = useState(q ?? "");
  const [pros, setPros] = useState<Professional[]>([]);
  const [request, setRequest] = useState<{
    name: string;
    price: number;
    category: CategorySlug;
    description: string;
  } | null>(null);
  const [page, setPage] = useState(1);
  const [sort, setSort] = useState("price");
  useEffect(() => {
    const refresh = () => setPros(getClientFacingProfessionals());
    refresh();
    const a = subscribeToProfessionalProfile(refresh);
    const b = subscribeToSession(refresh);
    return () => {
      a();
      b();
    };
  }, []);
  useEffect(() => setText(q ?? ""), [q]);
  useEffect(() => setPage(1), [text, cat, sort]);
  const selected = categories.find((item) => item.slug === cat);
  const services = useMemo(() => {
    const terms = normalizeSearch(text).split(/\s+/).filter(Boolean);
    return pros
      .flatMap((pro) =>
        pro.services
          .filter((service) => service.price !== null)
          .map((service, index) => ({
            pro,
            service,
            category: service.category ?? pro.category,
            id: `${pro.id}-${index}-${service.name}`,
          })),
      )
      .filter(
        ({ pro, service, category }) =>
          (!cat || category === cat) &&
          terms.every((term) =>
            normalizeSearch(
              [
                pro.name,
                pro.neighborhood,
                service.name,
                service.description ?? "",
                categoryName(category),
              ].join(" "),
            ).includes(term),
          ),
      )
      .sort((a, b) =>
        sort === "price-desc"
          ? b.service.price! - a.service.price!
          : a.service.price! - b.service.price!,
      );
  }, [pros, text, cat, sort]);
  const clear = () => {
    setText("");
    void navigate({ search: {} });
  };
  return (
    <div className="servix-workspace min-w-0 space-y-7">
      <PageTitle
        title="Preço fechado"
        subtitle="Compare os valores publicados e encontre o serviço que cabe no seu plano."
        action={
          <Link to="/anuncios-servicos" className={secondaryActionClass}>
            Todos os serviços <ArrowRight className="h-4 w-4" />
          </Link>
        }
      />
      <CatalogSearch
        title="Seu próximo serviço, com valor definido."
        description="Escolha uma opção e publique seu pedido para profissionais da categoria."
        label="Pesquisar serviços com preço fechado"
        placeholder="Qual serviço você quer comparar?"
        value={text}
        onChange={setText}
        category={selected?.slug}
        onCategory={(slug) => {
          void navigate({ search: { q: text.trim() || undefined, cat: slug } });
        }}
        onSubmit={(event) => {
          event.preventDefault();
          void navigate({ search: { q: text.trim() || undefined, cat } });
        }}
      />
      <AdPlacement channel="preco_fechado" compact />
      <div className="grid min-w-0 items-start gap-7 xl:grid-cols-[minmax(0,1fr)_17rem]">
        <section className="min-w-0 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b pb-4">
            <div>
              <h2 className="text-xl font-bold">
                {selected?.name ?? "Serviços com valor anunciado"}
              </h2>
              <p role="status" className="mt-1 text-xs text-muted-foreground">
                {services.length} opções disponíveis
              </p>
            </div>
            <select
              aria-label="Ordenar preços"
              value={sort}
              onChange={(event) => setSort(event.target.value)}
              className="rounded-md border bg-card px-3 py-2.5 text-xs font-semibold"
            >
              <option value="price">Menor valor</option>
              <option value="price-desc">Maior valor</option>
            </select>
          </div>
          {(text.trim() || cat) && (
            <div className="flex flex-wrap gap-3 text-xs">
              <span className="text-muted-foreground">
                {selected?.name}
                {selected && text.trim() ? " · " : ""}
                {text.trim()}
              </span>
              <button
                onClick={clear}
                className="font-semibold text-primary underline underline-offset-4"
              >
                Limpar filtros
              </button>
            </div>
          )}
          {services.length ? (
            <div className="grid min-w-0 gap-4 md:grid-cols-2">
              {services.slice((page - 1) * 10, page * 10).map(({ id, pro, service, category }) => (
                <article
                  key={id}
                  className="flex min-w-0 flex-col overflow-hidden rounded-xl border bg-card"
                >
                  <div className="grid min-w-0 grid-cols-[6rem_minmax(0,1fr)] gap-4 p-5">
                    <div className="aspect-square self-start overflow-hidden rounded-lg bg-muted">
                      <CategoryCover slug={category} className="h-full w-full" />
                    </div>
                    <div className="min-w-0">
                      <p className="text-xs font-semibold text-muted-foreground">
                        {categoryName(category)}
                      </p>
                      <h3 className="mt-2 break-words text-base font-bold leading-snug">
                        {service.name}
                      </h3>
                      {service.duration && (
                        <p className="mt-2 flex items-center gap-1.5 text-xs text-muted-foreground">
                          <Clock3 className="h-3.5 w-3.5 shrink-0" />
                          {service.duration}
                        </p>
                      )}
                    </div>
                  </div>
                  {service.description && (
                    <p className="line-clamp-2 px-5 text-sm leading-relaxed text-muted-foreground">
                      {service.description}
                    </p>
                  )}
                  <Link
                    to="/profissional/$id"
                    params={{ id: pro.id }}
                    className="mx-5 mt-4 flex min-w-0 items-center gap-2 border-t pt-4 text-xs"
                  >
                    <Avatar pro={pro} size="sm" />
                    <span className="min-w-0">
                      <span className="block text-muted-foreground">Anunciado por</span>
                      <span className="mt-0.5 block truncate font-semibold">{pro.name}</span>
                    </span>
                  </Link>
                  <div className="mt-auto flex flex-wrap items-end justify-between gap-3 p-5">
                    <div>
                      <p className="text-[11px] text-muted-foreground">Preço anunciado</p>
                      <p className="mt-1 text-2xl font-bold tracking-tight">
                        {brl(service.price!)}
                      </p>
                    </div>
                    <button
                      aria-label={`Solicitar ${service.name}`}
                      onClick={() =>
                        setRequest({
                          name: service.name,
                          price: service.price!,
                          category,
                          description: service.description ?? "",
                        })
                      }
                      className={actionClass}
                    >
                      Solicitar serviço <ArrowRight className="h-4 w-4" />
                    </button>
                  </div>
                </article>
              ))}
            </div>
          ) : (
            <EmptyState
              icon={ShoppingBag}
              title={
                text.trim() || cat
                  ? "Nenhuma opção para esta busca"
                  : "Novos serviços com preço fechado em breve"
              }
              description={
                text.trim() || cat
                  ? "Experimente outro termo ou escolha uma nova categoria."
                  : "Os anúncios com valor definido aparecerão aqui assim que forem publicados."
              }
            >
              {text.trim() || cat ? (
                <button onClick={clear} className={actionClass}>
                  Limpar filtros
                </button>
              ) : (
                <Link to="/anuncios-servicos" className={actionClass}>
                  Explorar outros serviços
                </Link>
              )}
            </EmptyState>
          )}
          <Pagination
            currentPage={page}
            totalItems={services.length}
            pageSize={10}
            onPageChange={setPage}
            label="serviços"
          />
        </section>
        <aside className="rounded-xl border bg-secondary/40 p-6">
          <h2 className="text-lg font-bold">Como funciona o pedido</h2>
          <ol className="mt-4 space-y-4 text-sm leading-relaxed text-muted-foreground">
            <li>
              <b className="text-primary">1.</b> Escolha o serviço e confira o valor publicado.
            </li>
            <li>
              <b className="text-primary">2.</b> Informe o local, o prazo e os detalhes do trabalho.
            </li>
            <li>
              <b className="text-primary">3.</b> Receba propostas de profissionais compatíveis.
            </li>
          </ol>
          <p className="mt-5 border-t pt-4 text-xs leading-relaxed text-muted-foreground">
            O pedido fica na sua conta. Combine o escopo e a disponibilidade antes de aceitar uma
            proposta.
          </p>
        </aside>
      </div>
      {request && (
        <QuoteDialog
          open
          onOpenChange={(open) => !open && setRequest(null)}
          defaultCategory={request.category}
          referencePrice={request.price}
          sourceService={request.name}
          defaultText={`${request.name}${request.description ? ` — ${request.description}` : ""}`}
          returnTo="/vagas"
        />
      )}
    </div>
  );
}
