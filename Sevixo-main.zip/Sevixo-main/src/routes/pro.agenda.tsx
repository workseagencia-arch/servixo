import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { ArrowRight, CalendarDays, Check, Clock, MapPin, Wrench } from "lucide-react";
import { toast } from "sonner";
import { PageTitle, StatusPill } from "@/components/app/ui-bits";
import {
  EmptyState,
  FilterInput,
  MetricCard,
  PanelTabs,
  WorkspaceIntro,
  actionClass,
  secondaryActionClass,
} from "@/components/app/workspace-ui";
import { normalizeSearch } from "@/lib/search";
import { Pagination } from "@/components/app/pagination";
import { brl, updateBookingStatus, type OrderStatus } from "@/lib/demo-data";
import {
  readProfessionalJobs,
  subscribeToProfessionalJobs,
  type ProfessionalJob,
} from "@/lib/professional-jobs";
import { addNotification } from "@/lib/notification-store";

export const Route = createFileRoute("/pro/agenda")({
  head: () => ({ meta: [{ title: "Agenda e serviços — ServiX" }] }),
  component: Agenda,
});
const steps: OrderStatus[] = ["Confirmado", "A caminho", "Em execução", "Concluído"];
function Agenda() {
  const [jobs, setJobs] = useState<ProfessionalJob[]>([]);
  const [filter, setFilter] = useState<"todos" | "abertos" | "concluidos">("abertos");
  const [query, setQuery] = useState("");
  const [page, setPage] = useState(1);
  useEffect(() => {
    const refresh = () => setJobs(readProfessionalJobs());
    refresh();
    return subscribeToProfessionalJobs(refresh);
  }, []);
  useEffect(() => setPage(1), [query, filter]);
  const active = jobs.filter((job) => job.status !== "Concluído");
  const completed = jobs.filter((job) => job.status === "Concluído");
  const filtered = jobs.filter(
    (job) =>
      (filter === "todos" ||
        (filter === "concluidos" ? job.status === "Concluído" : job.status !== "Concluído")) &&
      normalizeSearch(`${job.title} ${job.client} ${job.id} ${job.address}`).includes(
        normalizeSearch(query),
      ),
  );
  const changeStatus = (job: ProfessionalJob, status: OrderStatus) => {
    if (!updateBookingStatus(job.id, status)) {
      let statuses: Record<string, OrderStatus> = {};
      try {
        statuses = JSON.parse(localStorage.getItem("servix.pro-agenda-status") ?? "{}");
      } catch {
        /* Start with an empty status history. */
      }
      localStorage.setItem(
        "servix.pro-agenda-status",
        JSON.stringify({ ...statuses, [job.id]: status }),
      );
    }
    window.dispatchEvent(new Event("servix:agenda-change"));
    addNotification({
      role: "cliente",
      title: status === "Concluído" ? "Serviço concluído" : "Andamento do serviço atualizado",
      detail: `${job.title}: ${status}.`,
      href: `/meus-servicos/${job.id}`,
    });
    toast.success(`Serviço atualizado: ${status}`);
  };
  return (
    <div className="servix-workspace">
      <PageTitle
        title="Agenda e serviços"
        subtitle="Organize seus compromissos e mantenha o cliente informado sobre cada etapa."
        action={
          <Link to="/vagas" className={secondaryActionClass}>
            Encontrar vagas <ArrowRight className="h-4 w-4" />
          </Link>
        }
      />
      <WorkspaceIntro
        title="Seu trabalho, do combinado à entrega."
        description="Confira os pedidos confirmados, consulte o endereço e atualize o andamento conforme o trabalho acontecer."
      />
      <div className="mb-6 grid gap-3 sm:grid-cols-3">
        <MetricCard icon={Wrench} label="Serviços em andamento" value={active.length} emphasis />
        <MetricCard
          icon={Clock}
          label="Próximo compromisso"
          value={active[0]?.time ?? "—"}
          note={active[0]?.dateLabel ?? "Nenhum serviço agendado"}
        />
        <MetricCard icon={Check} label="Serviços concluídos" value={completed.length} />
      </div>
      <FilterInput
        label="Buscar na agenda"
        placeholder="Busque por serviço, cliente ou endereço"
        value={query}
        onChange={setQuery}
      />
      <PanelTabs
        label="Status da agenda"
        value={filter}
        onChange={setFilter}
        items={[
          { value: "abertos", label: "Em andamento", count: active.length },
          { value: "concluidos", label: "Concluídos", count: completed.length },
          { value: "todos", label: "Todos", count: jobs.length },
        ]}
      />
      <div className="space-y-3">
        {filtered.slice((page - 1) * 10, page * 10).map((job) => {
          const next = steps[steps.indexOf(job.status) + 1];
          return (
            <article
              key={job.id}
              className="grid min-w-0 gap-4 rounded-xl border bg-card p-5 sm:grid-cols-[8rem_minmax(0,1fr)] lg:grid-cols-[8rem_minmax(0,1fr)_auto]"
            >
              <div className="flex items-center gap-3 sm:block sm:border-r sm:pr-4">
                <CalendarDays className="h-5 w-5 shrink-0 text-primary sm:mb-3" />
                <div>
                  <p className="text-lg font-bold">{job.time}</p>
                  <p className="mt-1 text-xs text-muted-foreground">{job.dateLabel}</p>
                </div>
              </div>
              <div className="min-w-0">
                <div className="flex flex-wrap items-center gap-2">
                  <span className="text-xs text-muted-foreground">{job.id}</span>
                  <StatusPill status={job.status} />
                </div>
                <h2 className="mt-2 text-base font-bold">{job.title}</h2>
                <p className="mt-1 text-sm text-muted-foreground">{job.client}</p>
                <p className="mt-3 flex items-start gap-2 text-xs leading-relaxed text-muted-foreground">
                  <MapPin className="mt-0.5 h-3.5 w-3.5 shrink-0" />
                  {job.address || "Endereço a combinar"}
                </p>
              </div>
              <div className="flex flex-wrap items-center justify-between gap-3 sm:col-start-2 lg:col-start-auto lg:flex-col lg:items-end">
                <span className="text-xl font-bold">{brl(job.price)}</span>
                {job.status !== "Concluído" && next && (
                  <button className={actionClass} onClick={() => changeStatus(job, next)}>
                    {next === "Concluído" ? "Concluir serviço" : `Atualizar: ${next}`}
                    <ArrowRight className="h-4 w-4" />
                  </button>
                )}
                {job.status === "Concluído" && (
                  <span className="inline-flex items-center gap-2 text-sm text-primary">
                    <Check className="h-4 w-4" />
                    Concluído
                  </span>
                )}
              </div>
            </article>
          );
        })}
      </div>
      {!filtered.length && (
        <EmptyState
          icon={CalendarDays}
          title={query ? "Nenhum compromisso encontrado" : "Sua agenda está livre"}
          description={
            query
              ? "Tente outro nome ou consulte todos os serviços."
              : "Os serviços confirmados aparecerão aqui para você acompanhar cada etapa."
          }
        >
          <Link to="/vagas" className={secondaryActionClass}>
            Consultar vagas
          </Link>
        </EmptyState>
      )}
      <div className="mt-5">
        <Pagination
          currentPage={page}
          totalItems={filtered.length}
          pageSize={10}
          onPageChange={setPage}
          label="serviços"
        />
      </div>
    </div>
  );
}
