import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, type ChangeEvent, type FormEvent } from "react";
import { CalendarDays, Eye, ImagePlus, Megaphone, MousePointerClick } from "lucide-react";
import { toast } from "sonner";
import {
  categories,
  proMe,
  brl,
  type AdCampaign,
  type AdChannel,
  type CategorySlug,
} from "@/lib/demo-data";
import {
  addAdCampaign,
  readAdCampaigns,
  subscribeToAdCampaigns,
  isCampaignDeliverable,
} from "@/lib/advertising-store";
import { addNotification } from "@/lib/notification-store";
import {
  readProfessionalCategories,
  readProfessionalProfile,
  subscribeToProfessionalProfile,
} from "@/lib/professional-store";
import { PageTitle, ResilientImage } from "@/components/app/ui-bits";
import { AdChannelPicker } from "@/components/app/ad-channel-picker";
import {
  EmptyState,
  WorkspaceIntro,
  actionClass,
  secondaryActionClass,
} from "@/components/app/workspace-ui";
import { Pagination } from "@/components/app/pagination";
import { prepareCampaignImage } from "@/lib/campaign-image";

export const Route = createFileRoute("/pro/divulgacao")({
  head: () => ({ meta: [{ title: "Impulsionar perfil — ServiX" }] }),
  component: ProfessionalPromotion,
});
const inputClass =
  "mt-2 w-full rounded-md border bg-background px-3 py-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/10";
const priceForDays = (days: number, channelCount = 2) =>
  (days === 7 ? 39 : 99) * Math.max(1, Math.ceil(channelCount / 3));
function ProfessionalPromotion() {
  const [campaigns, setCampaigns] = useState<AdCampaign[]>([]);
  const [days, setDays] = useState(30);
  const [channels, setChannels] = useState<AdChannel[]>([
    "servicos",
    "profissionais",
    "preco_fechado",
  ]);
  const [offeredCategories, setOfferedCategories] = useState<CategorySlug[]>([]);
  const [category, setCategory] = useState<CategorySlug>("outros");
  const [headline, setHeadline] = useState("");
  const [description, setDescription] = useState(
    "Conheça meus serviços, valores e horários disponíveis.",
  );
  const [imageUrl, setImageUrl] = useState("");
  const [page, setPage] = useState(1);
  const [uploading, setUploading] = useState(false);
  const existing = campaigns
    .filter((item) => item.advertiserType === "profissional" && item.advertiserId === proMe.id)
    .sort((a, b) => b.createdAt.localeCompare(a.createdAt));
  const active = existing.find((item) => isCampaignDeliverable(item));
  useEffect(() => {
    setHeadline(`${readProfessionalProfile().name || "Seu profissional"}, serviços na sua região`);
    setCategory(readProfessionalCategories()[0] ?? readProfessionalProfile().category);
    setImageUrl(
      readAdCampaigns().find(
        (item) => item.advertiserType === "profissional" && item.advertiserId === proMe.id,
      )?.imageUrl ?? "",
    );
    const refresh = () => setCampaigns(readAdCampaigns());
    refresh();
    const refreshCategories = () => setOfferedCategories(readProfessionalCategories());
    refreshCategories();
    const a = subscribeToAdCampaigns(refresh);
    const b = subscribeToProfessionalProfile(refreshCategories);
    return () => {
      a();
      b();
    };
  }, []);
  const chooseImage = async (event: ChangeEvent<HTMLInputElement>) => {
    const input = event.currentTarget;
    const file = input.files?.[0];
    if (!file) return;
    setUploading(true);
    try {
      setImageUrl(await prepareCampaignImage(file));
    } catch (error) {
      toast.error(
        error instanceof Error ? error.message : "Não foi possível preparar essa imagem.",
      );
    } finally {
      input.value = "";
      setUploading(false);
    }
  };

  const submit = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!offeredCategories.length || !offeredCategories.includes(category)) {
      toast.error("Publique ao menos um serviço ativo antes de impulsionar o perfil.");
      return;
    }
    if (!headline.trim() || !description.trim()) {
      toast.error("Informe o título e a mensagem do anúncio.");
      return;
    }
    if (!imageUrl) {
      toast.error("Adicione uma imagem para criar seu destaque.");
      return;
    }
    if (!channels.length) {
      toast.error("Escolha pelo menos um canal de exibição.");
      return;
    }
    const profile = readProfessionalProfile();
    if (profile.latitude === undefined || profile.longitude === undefined) {
      toast.error("Defina sua localização antes de criar uma campanha regional.");
      return;
    }
    const now = new Date();
    const end = new Date(now);
    end.setDate(end.getDate() + days);
    const campaign = addAdCampaign({
      advertiserType: "profissional",
      advertiserId: proMe.id,
      advertiserName: profile.name,
      format: "destaque_profissional",
      headline: headline.trim(),
      description: description.trim(),
      imageUrl,
      channels,
      href: `/profissional/${proMe.id}`,
      category,
      region: profile.neighborhood,
      latitude: profile.latitude,
      longitude: profile.longitude,
      radiusKm: profile.radiusKm,
      amount: priceForDays(days, channels.length),
      durationDays: days,
      startsAt: now.toISOString(),
      endsAt: end.toISOString(),
      status: "em_analise",
      payment: "pendente",
    });
    addNotification({
      role: "profissional",
      title: "Destaque enviado para análise",
      detail: `${campaign.durationDays} dias · R$ ${campaign.amount},00. A equipe confirmará o pagamento antes de publicar.`,
      href: "/pro/divulgacao",
    });
    toast.success("Solicitação enviada para a equipe ServiX.");
  };

  return (
    <div className="servix-workspace">
      <PageTitle
        title="Impulsionar perfil"
        subtitle="Planeje a divulgação dos seus serviços e acompanhe cada campanha."
        action={
          <Link to="/pro/servicos" className={secondaryActionClass}>
            Meus anúncios
          </Link>
        }
      />
      <WorkspaceIntro
        title="Seu trabalho em destaque, na região certa."
        description="Escolha a apresentação, os canais e o período de divulgação. A publicação depende da análise da equipe e da confirmação do pagamento."
      />
      {active && (
        <div className="mb-6 flex flex-wrap items-center justify-between gap-4 rounded-xl border border-primary/20 bg-secondary/40 p-5">
          <div>
            <p className="text-xs font-semibold text-primary">Campanha ativa</p>
            <h2 className="mt-1 font-bold">{active.headline}</h2>
            <p className="mt-1 text-xs text-muted-foreground">
              Até {new Date(active.endsAt).toLocaleDateString("pt-BR")}
            </p>
          </div>
          <div className="flex flex-wrap gap-4 text-xs text-muted-foreground">
            <span className="inline-flex items-center gap-1.5">
              <Eye className="h-4 w-4" />
              {active.impressions} visualizações
            </span>
            <span className="inline-flex items-center gap-1.5">
              <MousePointerClick className="h-4 w-4" />
              {active.clicks} cliques
            </span>
          </div>
        </div>
      )}
      <div className="grid min-w-0 items-start gap-6 xl:grid-cols-[minmax(0,1fr)_22rem]">
        <form onSubmit={submit} className="min-w-0 space-y-5">
          <section className="rounded-xl border bg-card p-5 sm:p-6">
            <h2 className="flex items-center gap-3 text-lg font-bold">
              <span className="grid h-7 w-7 place-items-center rounded-md bg-secondary text-xs text-primary">
                1
              </span>
              Apresentação do anúncio
            </h2>
            <p className="mt-2 text-sm text-muted-foreground">
              Uma mensagem objetiva e uma boa imagem ajudam o cliente a conhecer seu trabalho.
            </p>
            <div className="mt-5 space-y-4">
              <label className="block text-sm font-semibold">
                Título
                <input
                  required
                  maxLength={100}
                  value={headline}
                  onChange={(event) => setHeadline(event.target.value)}
                  className={inputClass}
                />
              </label>
              <label className="block text-sm font-semibold">
                Mensagem
                <textarea
                  required
                  maxLength={280}
                  rows={3}
                  value={description}
                  onChange={(event) => setDescription(event.target.value)}
                  className={inputClass}
                />
              </label>
              <label className="block text-sm font-semibold">
                Serviço anunciado
                <select
                  aria-label="Serviço anunciado"
                  value={category}
                  onChange={(event) => setCategory(event.target.value as CategorySlug)}
                  className={inputClass}
                >
                  {!offeredCategories.includes(category) && (
                    <option disabled value={category}>
                      Selecione uma especialidade
                    </option>
                  )}
                  {categories
                    .filter((item) => offeredCategories.includes(item.slug))
                    .map((item) => (
                      <option value={item.slug} key={item.slug}>
                        {item.name}
                      </option>
                    ))}
                </select>
              </label>
              <label className="flex cursor-pointer items-center justify-center gap-3 rounded-lg border border-dashed bg-muted/30 px-4 py-5 text-sm font-semibold hover:border-primary">
                <ImagePlus className="h-5 w-5 text-primary" />
                {uploading
                  ? "Preparando imagem…"
                  : imageUrl
                    ? "Alterar imagem"
                    : "Adicionar imagem"}
                <input
                  type="file"
                  accept="image/jpeg,image/png,image/webp"
                  className="sr-only"
                  aria-label="Imagem do anúncio"
                  disabled={uploading}
                  onChange={chooseImage}
                />
              </label>
              <p className="text-xs text-muted-foreground">
                JPG, PNG ou WebP. Até 8 MB. Confira o enquadramento na prévia.
              </p>
            </div>
          </section>
          <section className="rounded-xl border bg-card p-5 sm:p-6">
            <h2 className="mb-5 flex items-center gap-3 text-lg font-bold">
              <span className="grid h-7 w-7 place-items-center rounded-md bg-secondary text-xs text-primary">
                2
              </span>
              Onde divulgar
            </h2>
            <AdChannelPicker value={channels} onChange={setChannels} />
            <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
              A divulgação considera sua especialidade e sua área de atendimento.
            </p>
          </section>
          <section className="rounded-xl border bg-card p-5 sm:p-6">
            <h2 className="mb-5 flex items-center gap-3 text-lg font-bold">
              <span className="grid h-7 w-7 place-items-center rounded-md bg-secondary text-xs text-primary">
                3
              </span>
              Período e investimento
            </h2>
            <div className="grid gap-3 sm:grid-cols-2">
              {[7, 30].map((option) => (
                <button
                  type="button"
                  key={option}
                  aria-pressed={days === option}
                  onClick={() => setDays(option)}
                  className={`rounded-lg border p-4 text-left ${days === option ? "border-primary bg-secondary/40" : "hover:bg-muted/50"}`}
                >
                  <CalendarDays className="mb-3 h-4 w-4 text-primary" />
                  <span className="block text-sm font-semibold">{option} dias de divulgação</span>
                  <strong className="mt-1 block text-xl">
                    {brl(priceForDays(option, channels.length))}
                  </strong>
                </button>
              ))}
            </div>
            <div className="mt-5 flex flex-wrap items-center justify-between gap-4 border-t pt-5">
              <div>
                <p className="text-xs text-muted-foreground">Total da solicitação</p>
                <strong className="text-2xl">{brl(priceForDays(days, channels.length))}</strong>
                <p className="mt-1 text-xs text-muted-foreground">
                  {channels.length} canais · {days} dias
                </p>
              </div>
              <button
                type="submit"
                disabled={uploading || !offeredCategories.length}
                className={actionClass}
              >
                Solicitar divulgação
              </button>
            </div>
            <p className="mt-4 text-xs leading-relaxed text-muted-foreground">
              Esta etapa envia uma solicitação para análise. Nenhuma cobrança automática é
              realizada.
            </p>
          </section>
        </form>
        <aside className="min-w-0 space-y-5 xl:sticky xl:top-6">
          <section className="overflow-hidden rounded-xl border bg-card">
            <div className="border-b px-5 py-4">
              <h2 className="font-bold">Prévia do anúncio</h2>
              <p className="mt-1 text-xs text-muted-foreground">
                O formato se adapta ao canal de exibição.
              </p>
            </div>
            {imageUrl ? (
              <ResilientImage
                src={imageUrl}
                alt="Prévia da imagem do anúncio"
                className="aspect-[4/3] w-full bg-muted object-contain"
              />
            ) : (
              <div className="grid aspect-[4/3] place-items-center bg-muted/40">
                <ImagePlus className="h-10 w-10 text-muted-foreground/50" />
              </div>
            )}
            <div className="p-5">
              <span className="text-[10px] font-semibold text-muted-foreground">Patrocinado</span>
              <h3 className="mt-2 text-lg font-bold">{headline || "Título do seu anúncio"}</h3>
              <p className="mt-2 text-sm leading-relaxed text-muted-foreground">{description}</p>
            </div>
          </section>
          <div className="rounded-xl border bg-card p-5">
            <h2 className="font-bold">Antes de publicar</h2>
            <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
              Mantenha seus anúncios ativos, confira a localização e use uma imagem que represente
              seu trabalho. A equipe revisa o conteúdo antes de liberar a divulgação.
            </p>
          </div>
        </aside>
      </div>
      <section className="mt-8">
        <h2 className="mb-4 text-xl font-bold">Minhas campanhas</h2>
        {existing.length ? (
          <div className="divide-y overflow-hidden rounded-xl border bg-card">
            {existing.slice((page - 1) * 10, page * 10).map((campaign) => (
              <article
                key={campaign.id}
                className="flex min-w-0 flex-wrap items-center justify-between gap-4 p-5"
              >
                <div className="min-w-0">
                  <h3 className="font-semibold">{campaign.headline}</h3>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {campaign.durationDays} dias · {brl(campaign.amount)} · {campaign.region}
                  </p>
                </div>
                <span className="rounded-md bg-muted px-3 py-1.5 text-xs font-semibold">
                  {isCampaignDeliverable(campaign)
                    ? "Ativa"
                    : campaign.status === "em_analise"
                      ? "Em análise"
                      : campaign.status === "ativa"
                        ? "Período encerrado"
                        : campaign.status === "pausada"
                          ? "Pausada"
                          : "Encerrada"}
                  {campaign.payment === "pendente" && " · Pagamento pendente"}
                </span>
              </article>
            ))}
          </div>
        ) : (
          <EmptyState
            icon={Megaphone}
            title="Sua primeira campanha começa aqui"
            description="Depois de solicitar a divulgação, acompanhe a análise e o período de exibição nesta área."
          />
        )}
        <div className="mt-4">
          <Pagination
            currentPage={page}
            totalItems={existing.length}
            pageSize={10}
            onPageChange={setPage}
            label="campanhas"
          />
        </div>
      </section>
    </div>
  );
}
