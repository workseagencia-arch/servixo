import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import { Banknote, CalendarDays, Wallet } from "lucide-react";
import { PageTitle } from "@/components/app/ui-bits";
import {
  EmptyState,
  MetricCard,
  PanelTabs,
  WorkspaceIntro,
  secondaryActionClass,
} from "@/components/app/workspace-ui";
import { Pagination } from "@/components/app/pagination";
import { payouts, PRO_COMMISSION, brl } from "@/lib/demo-data";
import {
  readProfessionalJobs,
  subscribeToProfessionalJobs,
  type ProfessionalJob,
} from "@/lib/professional-jobs";

export const Route = createFileRoute("/pro/ganhos")({
  head: () => ({ meta: [{ title: "Ganhos e repasses — ServiX" }] }),
  component: Earnings,
});
function Earnings() {
  const [jobs, setJobs] = useState<ProfessionalJob[]>([]);
  const [period, setPeriod] = useState<"semana" | "mes">("mes");
  const [page, setPage] = useState(1);
  useEffect(() => {
    const refresh = () => setJobs(readProfessionalJobs());
    refresh();
    return subscribeToProfessionalJobs(refresh);
  }, []);
  const now = new Date();
  const start =
    period === "mes"
      ? new Date(now.getFullYear(), now.getMonth(), 1)
      : new Date(now.getFullYear(), now.getMonth(), now.getDate() - ((now.getDay() + 6) % 7));
  const completed = jobs.filter(
    (job) =>
      job.status === "Concluído" &&
      new Date(job.completedAt ?? job.createdAt).getTime() >= start.getTime(),
  );
  const gross = completed.reduce((sum, job) => sum + job.price, 0);
  const net = gross * (1 - PRO_COMMISSION);
  return (
    <div className="servix-workspace min-w-0">
      <PageTitle
        title="Ganhos e repasses"
        subtitle="Tenha uma visão clara dos serviços concluídos e dos repasses registrados."
        action={
          <Link to="/pro/agenda" className={secondaryActionClass}>
            <CalendarDays className="h-4 w-4" /> Consultar serviços
          </Link>
        }
      />
      <WorkspaceIntro
        title="Seus resultados, sem perder os detalhes."
        description="Compare o valor dos trabalhos concluídos e a estimativa após a taxa da plataforma. Os repasses aparecem quando houver confirmação de pagamento."
      />
      <PanelTabs
        value={period}
        onChange={(value) => {
          setPeriod(value);
          setPage(1);
        }}
        label="Período dos resultados"
        items={[
          { value: "semana", label: "Esta semana" },
          { value: "mes", label: "Este mês" },
        ]}
      />
      <section className="mb-6 grid min-w-0 gap-3 sm:grid-cols-3">
        <MetricCard
          icon={Banknote}
          label="Valor dos serviços concluídos"
          value={brl(gross)}
          note={`${completed.length} trabalhos no período selecionado`}
          emphasis
        />
        <MetricCard
          icon={Wallet}
          label="Estimativa após a taxa"
          value={brl(net)}
          note={`Taxa da plataforma: ${Math.round(PRO_COMMISSION * 100)}%. Não representa saldo liberado.`}
        />
        <MetricCard
          icon={CalendarDays}
          label="Repasses registrados"
          value={brl(payouts.reduce((sum, payout) => sum + payout.amount, 0))}
          note="Transferências confirmadas no histórico"
        />
      </section>
      <section className="mb-7">
        <div className="mb-4 border-b pb-4">
          <h2 className="text-xl font-bold">Serviços do período</h2>
          <p className="mt-1 text-sm text-muted-foreground">
            Valores vinculados aos trabalhos concluídos.
          </p>
        </div>
        {completed.length ? (
          <div className="divide-y overflow-hidden rounded-xl border bg-card">
            {completed.slice((page - 1) * 10, page * 10).map((job) => (
              <div
                key={job.id}
                className="flex min-w-0 flex-wrap items-center justify-between gap-3 p-5"
              >
                <div className="min-w-0">
                  <p className="break-words text-sm font-semibold">{job.title}</p>
                  <p className="mt-1 text-xs text-muted-foreground">
                    {job.id} · {job.dateLabel}
                  </p>
                </div>
                <span className="text-lg font-bold">{brl(job.price)}</span>
              </div>
            ))}
          </div>
        ) : (
          <EmptyState
            icon={Wallet}
            title="Seus resultados vão aparecer aqui"
            description="Quando um serviço for concluído, você poderá acompanhar o valor registrado neste painel."
          />
        )}
        <div className="mt-4">
          <Pagination
            currentPage={page}
            totalItems={completed.length}
            pageSize={10}
            onPageChange={setPage}
            label="serviços"
          />
        </div>
      </section>
      <section className="rounded-xl border bg-card p-5 sm:p-6">
        <h2 className="text-lg font-bold">Histórico de repasses</h2>
        <p className="mt-1 text-sm text-muted-foreground">
          O histórico mostra apenas transferências registradas.
        </p>
        {payouts.length ? (
          <div className="mt-4 divide-y">
            {payouts.map((payout) => (
              <div key={payout.date} className="flex flex-wrap justify-between gap-3 py-4 text-sm">
                <span>
                  {payout.date} · {payout.status}
                </span>
                <strong>{brl(payout.amount)}</strong>
              </div>
            ))}
          </div>
        ) : (
          <div className="mt-5 flex items-start gap-3 rounded-lg bg-muted/50 p-4">
            <Banknote className="mt-0.5 h-5 w-5 shrink-0 text-muted-foreground" />
            <div>
              <p className="text-sm font-semibold">Nenhum repasse registrado</p>
              <p className="mt-1 text-xs leading-relaxed text-muted-foreground">
                Pagamentos e saques estarão disponíveis quando o processamento financeiro estiver
                conectado à plataforma.
              </p>
            </div>
          </div>
        )}
      </section>
    </div>
  );
}
