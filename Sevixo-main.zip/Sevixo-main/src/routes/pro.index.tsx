import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  ArrowRight,
  CalendarDays,
  Megaphone,
  Plus,
  Star,
  Wrench,
  BriefcaseBusiness,
} from "lucide-react";
import { PageTitle } from "@/components/app/ui-bits";
import {
  EmptyState,
  MetricCard,
  WorkspaceIntro,
  actionClass,
  secondaryActionClass,
} from "@/components/app/workspace-ui";
import { proMe, readQuoteRequests, subscribeToQuoteRequests } from "@/lib/demo-data";
import {
  fallbackProfile,
  getClientFacingProfessional,
  readAdvertisedServices,
  readProfessionalCategories,
  readProfessionalProfile,
  saveProfessionalProfile,
  subscribeToProfessionalProfile,
} from "@/lib/professional-store";
import { readSession } from "@/lib/auth-store";
import {
  readProfessionalJobs,
  subscribeToProfessionalJobs,
  type ProfessionalJob,
} from "@/lib/professional-jobs";

export const Route = createFileRoute("/pro/")({
  head: () => ({ meta: [{ title: "Painel profissional — ServiX" }] }),
  component: ProfessionalHome,
});
function ProfessionalHome() {
  const [profile, setProfile] = useState(fallbackProfile);
  const [quotes, setQuotes] = useState<ReturnType<typeof readQuoteRequests>>([]);
  const [jobs, setJobs] = useState<ProfessionalJob[]>([]);
  const [services, setServices] = useState<ReturnType<typeof readAdvertisedServices>>([]);
  useEffect(() => {
    const refresh = () => {
      setProfile(readProfessionalProfile());
      setServices(readAdvertisedServices());
    };
    refresh();
    return subscribeToProfessionalProfile(refresh);
  }, []);
  useEffect(() => {
    const refresh = () => setQuotes([...readQuoteRequests()]);
    refresh();
    return subscribeToQuoteRequests(refresh);
  }, []);
  useEffect(() => {
    const refresh = () => setJobs(readProfessionalJobs());
    refresh();
    return subscribeToProfessionalJobs(refresh);
  }, []);
  const offered = readProfessionalCategories();
  const ownEmail = readSession()?.email.toLocaleLowerCase("pt-BR");
  const available = quotes.filter(
    (request) =>
      request.status === "Aguardando propostas" &&
      offered.includes(request.category as typeof profile.category) &&
      (!request.targetProId || request.targetProId === proMe.id) &&
      request.ownerEmail?.toLocaleLowerCase("pt-BR") !== ownEmail &&
      !request.proposals.some((proposal) => proposal.proId === proMe.id),
  );
  const activeJobs = jobs.filter((job) => job.status !== "Concluído");
  const pro = profile.name ? getClientFacingProfessional() : { reviews: 0, rating: 0 };
  const fields = [
    profile.name,
    profile.phone,
    profile.email,
    profile.neighborhood,
    profile.bio,
    services.some((service) => service.active),
  ];
  const completion = Math.round((fields.filter(Boolean).length / fields.length) * 100);
  return (
    <div className="servix-workspace min-w-0 space-y-6">
      <PageTitle
        title="Painel profissional"
        subtitle="Seu trabalho, seus anúncios e seus próximos compromissos em um só lugar."
        action={
          <Link to="/pro/servicos" className={actionClass}>
            <Plus className="h-4 w-4" /> Gerenciar anúncios
          </Link>
        }
      />
      <WorkspaceIntro
        title={
          profile.name
            ? `Olá, ${profile.name.split(" ")[0]}. Vamos organizar seu dia?`
            : "Seu próximo trabalho começa aqui."
        }
        description="Mantenha os serviços atualizados, consulte as vagas e acompanhe o andamento de cada trabalho."
      >
        <button
          type="button"
          aria-pressed={profile.online}
          onClick={() => saveProfessionalProfile({ ...profile, online: !profile.online })}
          className="inline-flex items-center gap-2 rounded-md border border-white/30 px-4 py-3 text-sm font-semibold"
        >
          <span className={`h-2 w-2 rounded-full ${profile.online ? "bg-brand" : "bg-white/40"}`} />
          {profile.online ? "Disponível para contatos" : "Disponibilidade pausada"}
        </button>
      </WorkspaceIntro>
      <section className="grid min-w-0 gap-3 sm:grid-cols-2 xl:grid-cols-4">
        <MetricCard
          icon={BriefcaseBusiness}
          label="Vagas compatíveis"
          value={available.length}
          note="Pedidos abertos de clientes"
          emphasis
        />
        <MetricCard
          icon={CalendarDays}
          label="Trabalhos em andamento"
          value={activeJobs.length}
          note="Compromissos na sua agenda"
        />
        <MetricCard
          icon={Wrench}
          label="Anúncios publicados"
          value={services.filter((service) => service.active).length}
          note="Serviços disponíveis no seu perfil"
        />
        <MetricCard
          icon={Star}
          label="Avaliações dos clientes"
          value={
            pro.reviews > 0 ? pro.rating.toLocaleString("pt-BR", { minimumFractionDigits: 1 }) : "—"
          }
          note={pro.reviews > 0 ? `${pro.reviews} avaliações recebidas` : "Ainda sem avaliações"}
        />
      </section>
      <Link
        to="/pro/divulgacao"
        className="flex min-w-0 flex-wrap items-center gap-4 rounded-xl border bg-secondary/40 p-5 sm:p-6"
      >
        <Megaphone className="h-6 w-6 shrink-0 text-primary" />
        <span className="min-w-0 flex-1">
          <span className="block text-base font-bold">Leve seu trabalho a mais clientes.</span>
          <span className="mt-1 block text-sm text-muted-foreground">
            Escolha onde e por quanto tempo deseja divulgar seus serviços.
          </span>
        </span>
        <span className="inline-flex items-center gap-2 text-sm font-semibold text-primary">
          Impulsionar perfil <ArrowRight className="h-4 w-4" />
        </span>
      </Link>
      <div className="grid min-w-0 items-start gap-6 xl:grid-cols-[minmax(0,1fr)_20rem]">
        <section className="min-w-0">
          <div className="mb-4 flex items-center justify-between gap-3 border-b pb-4">
            <h2 className="text-xl font-bold">Vagas para você</h2>
            <Link to="/vagas" className="text-xs font-semibold text-primary hover:underline">
              Ver todas
            </Link>
          </div>
          {available.length ? (
            <div className="space-y-3">
              {available.slice(0, 3).map((request) => (
                <article key={request.id} className="rounded-xl border bg-card p-5">
                  <p className="text-xs text-muted-foreground">
                    {request.id} · {request.address || "Local a combinar"}
                  </p>
                  <h3 className="mt-2 break-words font-semibold">{request.description}</h3>
                  <Link
                    to="/vagas"
                    className="mt-4 inline-flex items-center gap-2 text-sm font-semibold text-primary"
                  >
                    Ver pedido e enviar proposta <ArrowRight className="h-4 w-4" />
                  </Link>
                </article>
              ))}
            </div>
          ) : (
            <EmptyState
              icon={BriefcaseBusiness}
              title="Novas vagas vão aparecer aqui"
              description="As publicações compatíveis com os serviços que você oferece serão reunidas neste painel."
            >
              <Link to="/vagas" className={secondaryActionClass}>
                Explorar vagas
              </Link>
            </EmptyState>
          )}
        </section>
        <aside className="space-y-5">
          <section className="rounded-xl border bg-card p-5">
            <div className="flex items-center justify-between gap-2">
              <h2 className="font-bold">Próximos compromissos</h2>
              <CalendarDays className="h-4 w-4 text-primary" />
            </div>
            {activeJobs.slice(0, 2).map((job) => (
              <div key={job.id} className="mt-4 border-t pt-4">
                <p className="break-words text-sm font-semibold">{job.title}</p>
                <p className="mt-1 text-xs text-muted-foreground">
                  {job.dateLabel} · {job.time}
                </p>
              </div>
            ))}
            {!activeJobs.length && (
              <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
                Nenhum compromisso em andamento.
              </p>
            )}
            <Link
              to="/pro/agenda"
              className="mt-5 inline-flex items-center gap-2 text-xs font-semibold text-primary"
            >
              Abrir agenda <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </section>
          <section className="rounded-xl border bg-card p-5">
            <h2 className="font-bold">Seu perfil profissional</h2>
            <div className="mt-4 flex items-center justify-between text-xs">
              <span className="text-muted-foreground">Informações preenchidas</span>
              <strong>{completion}%</strong>
            </div>
            <div className="mt-2 h-1.5 overflow-hidden rounded-full bg-muted">
              <div className="h-full bg-primary" style={{ width: `${completion}%` }} />
            </div>
            <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
              Um perfil completo ajuda o cliente a conhecer seu trabalho.
            </p>
            <Link
              to="/pro/perfil"
              className="mt-4 inline-flex items-center gap-2 text-xs font-semibold text-primary"
            >
              Revisar informações <ArrowRight className="h-3.5 w-3.5" />
            </Link>
          </section>
        </aside>
      </div>
    </div>
  );
}
