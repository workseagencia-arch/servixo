import { createFileRoute } from "@tanstack/react-router";
import { z } from "zod";
import { MessagesPage } from "@/components/app/messages-page";

export const Route = createFileRoute("/pro/mensagens")({
  validateSearch: (search) => z.object({ thread: z.string().optional() }).parse(search),
  head: () => ({ meta: [{ title: "Mensagens de clientes — ServiX Profissional" }] }),
  component: function ProfessionalMessages() {
    const { thread } = Route.useSearch();
    return <MessagesPage role="profissional" initialThread={thread} />;
  },
});
