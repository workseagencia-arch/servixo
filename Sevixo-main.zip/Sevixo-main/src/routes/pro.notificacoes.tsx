import { createFileRoute } from "@tanstack/react-router";
import { NotificationsPage } from "@/components/app/notifications-page";

export const Route = createFileRoute("/pro/notificacoes")({
  head: () => ({ meta: [{ title: "Notificações profissionais — ServiX" }] }),
  component: () => <NotificationsPage roles={["cliente", "profissional"]} />,
});
