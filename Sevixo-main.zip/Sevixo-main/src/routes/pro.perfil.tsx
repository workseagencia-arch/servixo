import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState, type ChangeEvent } from "react";
import { useForm } from "react-hook-form";
import {
  BadgeCheck,
  BriefcaseBusiness,
  Camera,
  Check,
  CircleUserRound,
  Eye,
  LocateFixed,
  LogOut,
  MapPin,
  Pencil,
  Save,
  ShieldCheck,
  Wrench,
} from "lucide-react";
import { toast } from "sonner";
import { Avatar, PageTitle, Rating, Verified } from "@/components/app/ui-bits";
import { categories, categoryName, proMe } from "@/lib/demo-data";
import { clearSession, readSession } from "@/lib/auth-store";
import {
  readAdvertisedServices,
  readProfessionalProfile,
  saveProfessionalProfile,
  type EditableProfessionalProfile,
} from "@/lib/professional-store";
import { readProfessionalOnboarding } from "@/lib/professional-onboarding-store";
import { readDeviceLocation, subscribeToLocation, watchDeviceLocation } from "@/lib/location-store";

export const Route = createFileRoute("/pro/perfil")({
  head: () => ({
    meta: [
      { title: "Perfil profissional — ServiX" },
      {
        name: "description",
        content: "Organize seus dados, sua apresentação e a região de atendimento.",
      },
    ],
  }),
  component: ProfessionalProfile,
});

const inputClass =
  "w-full rounded-xl border bg-background px-3.5 py-3 text-sm outline-none focus:ring-2 focus:ring-ring/20";
const initialProfile: EditableProfessionalProfile = {
  name: proMe.name,
  role: proMe.role,
  category: proMe.category,
  neighborhood: proMe.neighborhood,
  radiusKm: proMe.radiusKm,
  bio: proMe.bio,
  online: proMe.online,
  priceFrom: proMe.priceFrom,
  phone: "",
  email: "",
  photoUrl: "",
};

function ProfessionalProfile() {
  const navigate = useNavigate();
  const form = useForm<EditableProfessionalProfile>({ defaultValues: initialProfile });
  const [profile, setProfile] = useState(initialProfile);
  const [editing, setEditing] = useState(true);
  const [locationEnabled, setLocationEnabled] = useState(false);
  const locationWatch = useRef<(() => void) | null>(null);
  const values = form.watch();
  const services = readAdvertisedServices().filter((service) => service.active);
  const onboarding = readProfessionalOnboarding(readSession()?.email ?? "");

  useEffect(() => {
    const loaded = readProfessionalProfile();
    setProfile(loaded);
    form.reset(loaded);
  }, [form]);

  useEffect(() => () => locationWatch.current?.(), []);
  useEffect(() => setLocationEnabled(!!readDeviceLocation("profissional")), []);

  useEffect(
    () =>
      subscribeToLocation(() => {
        const current = readDeviceLocation("profissional");
        if (!current) return;
        setLocationEnabled(true);
        setProfile((existing) => {
          const next = { ...existing, latitude: current.latitude, longitude: current.longitude };
          saveProfessionalProfile(next);
          return next;
        });
      }),
    [],
  );

  const photoChanged = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    if (!file.type.startsWith("image/") || file.size > 3 * 1024 * 1024) {
      toast.error("Escolha uma foto de até 3 MB.");
      return;
    }
    const reader = new FileReader();
    reader.onload = () => form.setValue("photoUrl", String(reader.result), { shouldDirty: true });
    reader.readAsDataURL(file);
  };

  const enableLocation = () => {
    locationWatch.current?.();
    locationWatch.current = watchDeviceLocation("profissional", (message) => toast.error(message));
    const stored = readDeviceLocation("profissional");
    if (stored) {
      const next = { ...profile, latitude: stored.latitude, longitude: stored.longitude };
      setProfile(next);
      saveProfessionalProfile(next);
      setLocationEnabled(true);
    }
    toast.message("Aguardando localização precisa do aparelho…");
  };

  const completion = useMemo(() => {
    const checks = [
      values.name,
      values.role,
      values.neighborhood,
      values.bio,
      values.phone,
      values.email,
      services.length > 0,
    ];
    return Math.round((checks.filter(Boolean).length / checks.length) * 100);
  }, [values, services.length]);

  const save = form.handleSubmit((updated) => {
    const next = {
      ...updated,
      online: profile.online,
      ...(profile.latitude !== undefined ? { latitude: profile.latitude } : {}),
      ...(profile.longitude !== undefined ? { longitude: profile.longitude } : {}),
      priceFrom: services.find((service) => service.price !== null)?.price ?? profile.priceFrom,
    };
    saveProfessionalProfile(next);
    setProfile(next);
    setEditing(false);
    toast.success("Perfil profissional atualizado");
  });

  return (
    <div>
      <PageTitle
        eyebrow="Área profissional"
        title="Seu perfil"
        subtitle="Apresente seu trabalho com clareza para conquistar novos clientes."
        action={
          <div className="flex gap-2">
            <button
              type="button"
              onClick={() => setEditing((value) => !value)}
              className="inline-flex items-center gap-2 rounded-full border px-4 py-2.5 text-sm font-bold hover:bg-muted"
            >
              <Pencil className="h-4 w-4" />
              {editing ? "Visualizar" : "Editar perfil"}
            </button>
            <Link
              to="/pro/servicos"
              className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground hover:bg-primary/90"
            >
              <Wrench className="h-4 w-4" />
              Meus serviços
            </Link>
          </div>
        }
      />

      <div className="grid gap-5 xl:grid-cols-[minmax(0,1fr)_340px]">
        <form onSubmit={save} className="space-y-5">
          <section className="surface overflow-hidden">
            <div className="bg-hero h-24" />
            <div className="flex flex-wrap items-end gap-4 px-5 pb-5 sm:px-6">
              <div className="relative -mt-9">
                <Avatar
                  pro={{
                    initials: profile.name
                      .split(" ")
                      .map((part) => part[0])
                      .slice(0, 2)
                      .join("")
                      .toUpperCase(),
                    hue: proMe.hue,
                    online: profile.online,
                    photoUrl: values.photoUrl || profile.photoUrl,
                  }}
                  size="lg"
                  className="rounded-full ring-4 ring-card"
                />
                {editing && (
                  <label
                    className="absolute bottom-0 right-0 grid h-8 w-8 cursor-pointer place-items-center rounded-full border bg-card shadow-sm"
                    aria-label="Alterar foto de perfil"
                  >
                    <Camera className="h-4 w-4" />
                    <input
                      type="file"
                      accept="image/*"
                      className="sr-only"
                      onChange={photoChanged}
                    />
                  </label>
                )}
              </div>
              <div className="min-w-0 flex-1 pb-1">
                <div className="flex flex-wrap items-center gap-2">
                  <h2 className="font-display text-xl font-extrabold">
                    {values.name || profile.name}
                  </h2>
                  {onboarding ? (
                    <span className="inline-flex items-center gap-1.5 rounded-md bg-status-warning/15 px-2.5 py-1 text-xs font-bold text-status-warning-foreground">
                      <ShieldCheck className="h-3.5 w-3.5" /> Verificação oficial pendente
                    </span>
                  ) : (
                    <Verified />
                  )}
                </div>
                <p className="text-sm text-muted-foreground">
                  {values.role || profile.role} · {values.neighborhood || profile.neighborhood}
                </p>
              </div>
              <button
                type="button"
                onClick={() => {
                  const next = { ...profile, online: !profile.online };
                  setProfile(next);
                  saveProfessionalProfile(next);
                  toast.success(
                    next.online ? "Disponível neste aparelho" : "Você pausou a disponibilidade",
                  );
                }}
                className={`mb-1 rounded-full px-3 py-2 text-xs font-bold ${profile.online ? "bg-accent text-accent-foreground" : "bg-muted text-muted-foreground"}`}
              >
                <span className="mr-1.5 inline-block h-2 w-2 rounded-full bg-current" />
                {profile.online ? "Disponível" : "Indisponível"}
              </button>
            </div>
            <div className="flex flex-wrap items-center justify-between gap-3 border-t px-5 py-3 sm:px-6">
              <p className="text-xs text-muted-foreground">
                {locationEnabled
                  ? "Última localização salva neste aparelho"
                  : "Ative a localização para melhorar a distância exibida"}
              </p>
              <button
                type="button"
                onClick={enableLocation}
                className="inline-flex items-center gap-2 rounded-full border px-3 py-2 text-xs font-bold hover:bg-muted"
              >
                <LocateFixed className="h-4 w-4" />
                Ativar localização
              </button>
            </div>
          </section>

          <section className="surface p-5 sm:p-6">
            <div className="mb-4 flex items-center gap-2">
              <CircleUserRound className="h-5 w-5 text-primary" />
              <div>
                <h2 className="font-display font-bold">Apresentação profissional</h2>
                <p className="text-xs text-muted-foreground">
                  Esses dados aparecem para clientes antes da contratação.
                </p>
              </div>
            </div>
            <div className="grid gap-3 sm:grid-cols-2">
              <label className="space-y-1.5 text-sm font-semibold">
                Nome de exibição
                <input
                  readOnly={!editing}
                  {...form.register("name", { required: true, maxLength: 80 })}
                  className={inputClass}
                />
              </label>
              <label className="space-y-1.5 text-sm font-semibold">
                Especialidade
                <input
                  readOnly={!editing}
                  {...form.register("role", { required: true, maxLength: 80 })}
                  className={inputClass}
                />
              </label>
              <label className="space-y-1.5 text-sm font-semibold">
                Categoria principal
                <select disabled={!editing} {...form.register("category")} className={inputClass}>
                  {categories.map((category) => (
                    <option key={category.slug} value={category.slug}>
                      {category.name}
                    </option>
                  ))}
                </select>
              </label>
              <label className="space-y-1.5 text-sm font-semibold">
                Bairro e cidade
                <input
                  readOnly={!editing}
                  {...form.register("neighborhood", { required: true })}
                  className={inputClass}
                />
              </label>
              <label className="space-y-1.5 text-sm font-semibold">
                Raio de atendimento
                <input
                  readOnly={!editing}
                  type="number"
                  min="1"
                  max="100"
                  {...form.register("radiusKm", { valueAsNumber: true, min: 1, max: 100 })}
                  className={inputClass}
                />
              </label>
              <label className="space-y-1.5 text-sm font-semibold">
                Telefone de contato
                <input
                  readOnly={!editing}
                  {...form.register("phone", { required: true })}
                  className={inputClass}
                />
              </label>
              <label className="space-y-1.5 text-sm font-semibold sm:col-span-2">
                E-mail
                <input
                  readOnly={!editing}
                  type="email"
                  {...form.register("email", { required: true })}
                  className={inputClass}
                />
              </label>
              <label className="space-y-1.5 text-sm font-semibold sm:col-span-2">
                Sobre seu trabalho
                <textarea
                  readOnly={!editing}
                  rows={5}
                  maxLength={600}
                  {...form.register("bio", { required: true, maxLength: 600 })}
                  className={`${inputClass} resize-y`}
                />
                <span className="block text-right text-[10px] font-normal text-muted-foreground">
                  {values.bio?.length ?? 0}/600
                </span>
              </label>
            </div>
            {editing && (
              <button className="mt-4 inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground hover:bg-primary/90">
                <Save className="h-4 w-4" />
                Salvar alterações
              </button>
            )}
          </section>

          <section className="surface p-5 sm:p-6">
            <div className="mb-4 flex items-center justify-between gap-3">
              <div className="flex items-center gap-2">
                <BriefcaseBusiness className="h-5 w-5 text-primary" />
                <div>
                  <h2 className="font-display font-bold">Serviços oferecidos</h2>
                  <p className="text-xs text-muted-foreground">
                    Preços, duração e categoria de cada serviço.
                  </p>
                </div>
              </div>
              <Link to="/pro/servicos" className="text-xs font-bold text-primary hover:underline">
                Gerenciar
              </Link>
            </div>
            <div className="divide-y">
              {services.slice(0, 4).map((service) => (
                <div key={service.id} className="flex items-center justify-between gap-3 py-3">
                  <div className="min-w-0">
                    <p className="truncate text-sm font-semibold">{service.name}</p>
                    <p className="text-xs text-muted-foreground">
                      {categoryName(service.category ?? profile.category)} · {service.duration}
                    </p>
                  </div>
                  <p className="shrink-0 text-sm font-bold">
                    {service.price === null
                      ? "Sob consulta"
                      : service.price.toLocaleString("pt-BR", {
                          style: "currency",
                          currency: "BRL",
                          maximumFractionDigits: 0,
                        })}
                  </p>
                </div>
              ))}
            </div>
            {services.length === 0 && (
              <Link
                to="/pro/servicos"
                className="inline-flex items-center gap-2 rounded-full border px-4 py-2.5 text-sm font-bold hover:bg-muted"
              >
                <Wrench className="h-4 w-4" />
                Adicionar serviço
              </Link>
            )}
          </section>
        </form>

        <aside className="space-y-4 xl:sticky xl:top-24 xl:self-start">
          <section className="surface p-5">
            <div className="flex items-center justify-between">
              <h2 className="font-display font-bold">Perfil completo</h2>
              <span className="text-sm font-extrabold text-primary">{completion}%</span>
            </div>
            <div className="mt-3 h-2 overflow-hidden rounded-full bg-muted">
              <span
                className="block h-full rounded-full bg-brand transition-all"
                style={{ width: `${completion}%` }}
              />
            </div>
            <p className="mt-3 text-xs leading-relaxed text-muted-foreground">
              Perfis completos recebem mais visitas e ajudam os clientes a escolher com segurança.
            </p>
            <ul className="mt-4 space-y-2 text-xs">
              {[
                ["Apresentação", !!values.name && !!values.bio],
                ["Contato", !!values.phone && !!values.email],
                ["Região atendida", !!values.neighborhood],
                ["Ao menos um serviço", services.length > 0],
              ].map(([label, complete]) => (
                <li key={String(label)} className="flex items-center gap-2">
                  <Check
                    className={`h-3.5 w-3.5 ${complete ? "text-status-success" : "text-muted-foreground/40"}`}
                  />
                  {label}
                </li>
              ))}
            </ul>
          </section>
          <section className="surface p-5">
            <h2 className="font-display flex items-center gap-2 font-bold">
              <Eye className="h-4 w-4" />
              Prévia para clientes
            </h2>
            <div className="mt-4 flex items-center gap-3">
              <Avatar
                pro={{
                  initials: profile.name
                    .split(" ")
                    .map((part) => part[0])
                    .slice(0, 2)
                    .join("")
                    .toUpperCase(),
                  hue: proMe.hue,
                  online: profile.online,
                  photoUrl: values.photoUrl || profile.photoUrl,
                }}
                size="sm"
              />
              <div className="min-w-0">
                <p className="truncate text-sm font-bold">{values.name || profile.name}</p>
                <p className="truncate text-xs text-muted-foreground">
                  {values.role || profile.role}
                </p>
              </div>
            </div>
            <div className="mt-3 flex items-center justify-between">
              <Rating value={proMe.rating} count={proMe.reviews} className="text-xs" />
              <span className="text-xs text-muted-foreground">
                {values.neighborhood || profile.neighborhood}
              </span>
            </div>
            <p className="mt-3 line-clamp-4 text-xs leading-relaxed text-muted-foreground">
              {values.bio || profile.bio}
            </p>
            <Link
              to="/buscar"
              className="mt-4 flex items-center justify-center gap-2 rounded-full border py-2.5 text-sm font-bold hover:bg-muted"
            >
              <SearchIcon />
              Ver como cliente
            </Link>
          </section>
          <section className="surface divide-y">
            <Link
              to="/pro/servicos"
              className="flex items-center gap-3 p-4 text-sm font-semibold hover:bg-muted"
            >
              <Wrench className="h-4 w-4 text-primary" />
              Anúncios e serviços
            </Link>
            <button
              onClick={() =>
                toast(
                  onboarding
                    ? "As etapas locais foram concluídas. A verificação oficial precisa ser conectada a um provedor seguro."
                    : "Sua verificação está atualizada.",
                )
              }
              className="flex w-full items-center gap-3 p-4 text-left text-sm font-semibold hover:bg-muted"
            >
              <ShieldCheck className="h-4 w-4 text-primary" />
              Segurança e verificação
              {onboarding ? (
                <span className="ml-auto text-[10px] font-bold text-status-warning-foreground">
                  Pendente
                </span>
              ) : (
                <BadgeCheck className="ml-auto h-4 w-4 text-status-success" />
              )}
            </button>
            <button
              onClick={() => {
                clearSession();
                navigate({ to: "/entrar", search: { perfil: "profissional" } });
              }}
              className="flex w-full items-center gap-3 p-4 text-left text-sm font-semibold text-muted-foreground hover:bg-muted"
            >
              <LogOut className="h-4 w-4" />
              Sair da conta
            </button>
          </section>
        </aside>
      </div>
    </div>
  );
}

function SearchIcon() {
  return <MapPin className="h-4 w-4" />;
}
