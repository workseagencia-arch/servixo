import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import { Clock, Eye, EyeOff, Megaphone, Pencil, Plus, Trash2, Wrench } from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { PageTitle } from "@/components/app/ui-bits";
import {
  EmptyState,
  FilterInput,
  MetricCard,
  PanelTabs,
  WorkspaceIntro,
  actionClass,
  secondaryActionClass,
} from "@/components/app/workspace-ui";
import { normalizeSearch } from "@/lib/search";
import { Pagination } from "@/components/app/pagination";
import { brl, categories, categoryName, type CategorySlug } from "@/lib/demo-data";
import {
  readAdvertisedServices,
  readProfessionalProfile,
  saveAdvertisedServices,
  subscribeToProfessionalProfile,
  type AdvertisedService,
} from "@/lib/professional-store";

export const Route = createFileRoute("/pro/servicos")({
  head: () => ({ meta: [{ title: "Meus anúncios — ServiX" }] }),
  component: Services,
});
const inputClass =
  "mt-2 w-full rounded-md border bg-background px-3 py-3 text-sm outline-none focus:border-primary focus:ring-2 focus:ring-primary/10";
function Services() {
  const [services, setServices] = useState<AdvertisedService[]>([]);
  const [page, setPage] = useState(1);
  const [query, setQuery] = useState("");
  const [filter, setFilter] = useState<"todos" | "ativos" | "pausados">("todos");
  const [open, setOpen] = useState(false);
  const [editing, setEditing] = useState<string | null>(null);
  const [name, setName] = useState("");
  const [price, setPrice] = useState("");
  const [duration, setDuration] = useState("");
  const [description, setDescription] = useState("");
  const [category, setCategory] = useState<CategorySlug>("outros");
  useEffect(() => {
    const refresh = () => setServices(readAdvertisedServices());
    refresh();
    return subscribeToProfessionalProfile(refresh);
  }, []);
  useEffect(() => setPage(1), [query, filter]);
  const startEditing = (service?: AdvertisedService) => {
    setEditing(service?.id ?? null);
    setName(service?.name ?? "");
    setPrice(service?.price == null ? "" : String(service.price));
    setDuration(service?.duration ?? "");
    setDescription(service?.description ?? "");
    setCategory(service?.category ?? readProfessionalProfile().category);
    setOpen(true);
  };
  const publish = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!name.trim() || !description.trim()) {
      toast.error("Informe o título e a descrição do serviço.");
      return;
    }
    const numericPrice = price.trim() ? Number(price) : null;
    if (numericPrice !== null && (!Number.isFinite(numericPrice) || numericPrice <= 0)) {
      toast.error("Informe um valor maior que zero ou deixe o preço sob consulta.");
      return;
    }
    const current = readAdvertisedServices();
    const service: AdvertisedService = {
      id: editing ?? `service-${crypto.randomUUID()}`,
      name: name.trim(),
      category,
      price: numericPrice,
      duration: duration.trim(),
      description: description.trim(),
      active: editing ? (current.find((item) => item.id === editing)?.active ?? true) : true,
    };
    saveAdvertisedServices(
      editing
        ? current.map((item) => (item.id === editing ? service : item))
        : [service, ...current],
    );
    setOpen(false);
    toast.success(editing ? "Anúncio atualizado" : "Serviço publicado no seu perfil");
  };
  const remove = (service: AdvertisedService) => {
    saveAdvertisedServices(readAdvertisedServices().filter((item) => item.id !== service.id));
    toast("Anúncio removido", {
      action: {
        label: "Desfazer",
        onClick: () => {
          const current = readAdvertisedServices();
          if (!current.some((item) => item.id === service.id))
            saveAdvertisedServices([service, ...current]);
        },
      },
    });
  };
  const active = services.filter((item) => item.active).length;
  const filtered = services.filter(
    (service) =>
      (filter === "todos" || (filter === "ativos" ? service.active : !service.active)) &&
      normalizeSearch(
        `${service.name} ${service.description} ${categoryName(service.category ?? "outros")}`,
      ).includes(normalizeSearch(query)),
  );
  return (
    <div className="servix-workspace">
      <PageTitle
        title="Meus anúncios"
        subtitle="Apresente seus serviços com informações claras e mantenha tudo atualizado."
        action={
          <button onClick={() => startEditing()} className={actionClass}>
            <Plus className="h-4 w-4" /> Criar anúncio
          </button>
        }
      />
      <WorkspaceIntro
        title="Mostre tudo o que você sabe fazer."
        description="Cadastre um anúncio para cada serviço. Você pode oferecer diferentes especialidades, editar os detalhes e pausar as publicações quando precisar."
      >
        <Link
          to="/pro/divulgacao"
          className="inline-flex items-center gap-2 rounded-md bg-brand px-4 py-3 text-sm font-semibold text-brand-foreground"
        >
          <Megaphone className="h-4 w-4" /> Impulsionar perfil
        </Link>
      </WorkspaceIntro>
      <section className="mb-6 grid gap-3 sm:grid-cols-3">
        <MetricCard label="Publicados" value={active} icon={Eye} emphasis />
        <MetricCard label="Pausados" value={services.length - active} icon={EyeOff} />
        <MetricCard
          label="Especialidades anunciadas"
          value={new Set(services.filter((item) => item.active).map((item) => item.category)).size}
          icon={Wrench}
        />
      </section>
      <FilterInput
        label="Buscar meus anúncios"
        placeholder="Busque pelo nome, descrição ou categoria"
        value={query}
        onChange={setQuery}
      />
      <PanelTabs
        label="Status dos anúncios"
        value={filter}
        onChange={setFilter}
        items={[
          { value: "todos", label: "Todos", count: services.length },
          { value: "ativos", label: "Publicados", count: active },
          { value: "pausados", label: "Pausados", count: services.length - active },
        ]}
      />
      <div className="grid min-w-0 gap-4 lg:grid-cols-2">
        {filtered.slice((page - 1) * 10, page * 10).map((service) => (
          <article
            key={service.id}
            className="flex min-w-0 flex-col rounded-xl border bg-card p-5 sm:p-6"
          >
            <div className="flex flex-wrap items-center justify-between gap-2">
              <span className="text-xs font-semibold text-muted-foreground">
                {categoryName(service.category ?? "outros")}
              </span>
              <span
                className={`rounded-md px-2 py-1 text-[11px] font-semibold ${service.active ? "bg-secondary text-primary" : "bg-muted text-muted-foreground"}`}
              >
                {service.active ? "Publicado" : "Pausado"}
              </span>
            </div>
            <h2 className="mt-3 text-lg font-bold">{service.name}</h2>
            <p className="mt-2 flex-1 text-sm leading-relaxed text-muted-foreground">
              {service.description || "Adicione uma descrição para apresentar melhor este serviço."}
            </p>
            {service.duration && (
              <p className="mt-4 inline-flex items-center gap-2 text-xs text-muted-foreground">
                <Clock className="h-3.5 w-3.5" />
                {service.duration}
              </p>
            )}
            <div className="mt-5 flex flex-wrap items-center justify-between gap-3 border-t pt-4">
              <strong className="text-lg">
                {service.price == null ? "Sob consulta" : brl(service.price)}
              </strong>
              <div className="flex items-center gap-1">
                <button
                  aria-label={`Editar ${service.name}`}
                  title="Editar anúncio"
                  className="rounded-md p-2.5 hover:bg-muted"
                  onClick={() => startEditing(service)}
                >
                  <Pencil className="h-4 w-4" />
                </button>
                <button
                  aria-label={`${service.active ? "Pausar" : "Publicar"} ${service.name}`}
                  title={service.active ? "Pausar anúncio" : "Publicar anúncio"}
                  className="rounded-md p-2.5 hover:bg-muted"
                  onClick={() =>
                    saveAdvertisedServices(
                      readAdvertisedServices().map((item) =>
                        item.id === service.id ? { ...item, active: !item.active } : item,
                      ),
                    )
                  }
                >
                  {service.active ? <EyeOff className="h-4 w-4" /> : <Eye className="h-4 w-4" />}
                </button>
                <button
                  aria-label={`Remover ${service.name}`}
                  title="Remover anúncio"
                  onClick={() => remove(service)}
                  className="rounded-md p-2.5 text-destructive hover:bg-destructive/10"
                >
                  <Trash2 className="h-4 w-4" />
                </button>
              </div>
            </div>
          </article>
        ))}
      </div>
      {!filtered.length && (
        <EmptyState
          icon={Wrench}
          title={
            query || filter !== "todos"
              ? "Nenhum anúncio encontrado"
              : "Seu primeiro anúncio começa aqui"
          }
          description={
            query || filter !== "todos"
              ? "Revise os filtros para consultar suas publicações."
              : "Descreva o que você oferece, escolha uma categoria e informe o valor ou deixe sob consulta."
          }
        >
          <button onClick={() => startEditing()} className={actionClass}>
            <Plus className="h-4 w-4" /> Criar anúncio
          </button>
        </EmptyState>
      )}
      <div className="mt-5">
        <Pagination
          currentPage={page}
          totalItems={filtered.length}
          pageSize={10}
          onPageChange={setPage}
          label="anúncios"
        />
      </div>
      <Dialog open={open} onOpenChange={setOpen}>
        <DialogContent className="max-h-[90dvh] overflow-y-auto rounded-xl sm:max-w-xl">
          <DialogHeader className="text-left">
            <DialogTitle>{editing ? "Editar anúncio" : "Criar anúncio de serviço"}</DialogTitle>
            <DialogDescription>
              Informações completas ajudam o cliente a escolher o serviço certo.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={publish} className="mt-3 space-y-4">
            <label className="block text-sm font-semibold">
              Nome do serviço
              <input
                required
                maxLength={100}
                className={inputClass}
                value={name}
                onChange={(event) => setName(event.target.value)}
                placeholder="Ex.: Instalação de luminária"
              />
            </label>
            <label className="block text-sm font-semibold">
              Categoria
              <select
                aria-label="Categoria"
                className={inputClass}
                value={category}
                onChange={(event) => setCategory(event.target.value as CategorySlug)}
              >
                {categories.map((item) => (
                  <option key={item.slug} value={item.slug}>
                    {item.name}
                  </option>
                ))}
              </select>
            </label>
            <label className="block text-sm font-semibold">
              Descrição
              <textarea
                required
                maxLength={1200}
                rows={4}
                className={inputClass}
                value={description}
                onChange={(event) => setDescription(event.target.value)}
                placeholder="Explique o que está incluído e como você realiza o trabalho."
              />
            </label>
            <div className="grid gap-4 sm:grid-cols-2">
              <label className="block text-sm font-semibold">
                Valor (R$)
                <input
                  type="number"
                  min="0.01"
                  step="0.01"
                  className={inputClass}
                  value={price}
                  onChange={(event) => setPrice(event.target.value)}
                  placeholder="Sob consulta"
                />
              </label>
              <label className="block text-sm font-semibold">
                Duração estimada
                <input
                  maxLength={60}
                  className={inputClass}
                  value={duration}
                  onChange={(event) => setDuration(event.target.value)}
                  placeholder="Ex.: 1 a 2 horas"
                />
              </label>
            </div>
            <div className="flex flex-wrap justify-end gap-2 border-t pt-4">
              <button type="button" onClick={() => setOpen(false)} className={secondaryActionClass}>
                Cancelar
              </button>
              <button className={actionClass} type="submit">
                {editing ? "Salvar alterações" : "Publicar serviço"}
              </button>
            </div>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}
