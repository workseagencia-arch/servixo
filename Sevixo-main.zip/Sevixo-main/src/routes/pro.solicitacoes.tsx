import { createFileRoute, Link } from "@tanstack/react-router";
import { useEffect, useMemo, useState, type FormEvent } from "react";
import { BriefcaseBusiness, CalendarDays, Check, Clock, FileText, MapPin, MessageCircle, Send, X } from "lucide-react";
import { toast } from "sonner";
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { PageTitle } from "@/components/app/ui-bits";
import { Pagination } from "@/components/app/pagination";
import { brl, categoryName, proMe, proRequests, quoteWhenLabel, readQuoteRequests, sendQuoteProposal, subscribeToQuoteRequests, type QuoteRequest } from "@/lib/demo-data";
import { addNotification } from "@/lib/notification-store";
import { readRequestDecisions, saveRequestDecision, type RequestDecision } from "@/lib/pro-workspace-store";
import { readProfessionalCategories, readProfessionalProfile } from "@/lib/professional-store";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/pro/solicitacoes")({
  validateSearch: (search: Record<string, unknown>): { tab?: RequestTab } =>
    ["novos", "orcamentos", "enviadas", "aceitos", "dispensados"].includes(String(search["tab"])) ? { tab: search["tab"] as RequestTab } : {},
  head: () => ({ meta: [{ title: "Oportunidades de clientes — ServiX Profissional" }, { name: "description", content: "Veja solicitações publicadas por clientes e envie propostas de serviço." }] }),
  component: Requests,
});

type RequestTab = "novos" | "orcamentos" | "enviadas" | "aceitos" | "dispensados";

function Requests() {
  const search = Route.useSearch();
  const [decisions, setDecisions] = useState<Partial<Record<string, RequestDecision>>>({});
  const [tab, setTab] = useState<RequestTab>(search.tab ?? "orcamentos");
  const [page, setPage] = useState(1);
  const pageSize = 10;
  const [quotes, setQuotes] = useState<ReturnType<typeof readQuoteRequests>>([]);
  const [proposalFor, setProposalFor] = useState<QuoteRequest | null>(null);
  const [price, setPrice] = useState("");
  const [days, setDays] = useState("");
  const [note, setNote] = useState("");
  const profile = readProfessionalProfile();
  const offeredCategories = readProfessionalCategories();

  useEffect(() => {
    const refresh = () => setDecisions(readRequestDecisions());
    refresh();
    window.addEventListener("servix:request-change", refresh);
    return () => window.removeEventListener("servix:request-change", refresh);
  }, []);
  useEffect(() => setPage(1), [tab]);
  useEffect(() => {
    const refresh = () => setQuotes([...readQuoteRequests()]);
    refresh();
    return subscribeToQuoteRequests(refresh);
  }, []);

  const availableQuotes = quotes.filter((request) => request.status === "Aguardando propostas"
    && offeredCategories.includes(request.category as typeof profile.category)
    && request.ownerEmail?.toLocaleLowerCase("pt-BR") !== profile.email.toLocaleLowerCase("pt-BR")
    && (!request.targetProId || request.targetProId === proMe.id)
    && !request.proposals.some((proposal) => proposal.proId === proMe.id));
  const sentQuotes = quotes.filter((request) => request.proposals.some((proposal) => proposal.proId === proMe.id));
  const counts = useMemo(() => ({
    novos: proRequests.filter((request) => offeredCategories.includes(request.category) && !decisions[request.id]).length,
    orcamentos: availableQuotes.length,
    enviadas: sentQuotes.length,
    aceitos: proRequests.filter((request) => offeredCategories.includes(request.category) && decisions[request.id] === "aceito").length,
    dispensados: proRequests.filter((request) => offeredCategories.includes(request.category) && decisions[request.id] === "dispensado").length,
  }), [decisions, availableQuotes.length, sentQuotes.length, offeredCategories]);
  const visible = proRequests.filter((request) => offeredCategories.includes(request.category) && (tab === "novos"
    ? !decisions[request.id]
    : decisions[request.id] === (tab === "aceitos" ? "aceito" : "dispensado")));
  const activeQuotes = tab === "orcamentos" ? availableQuotes : sentQuotes;
  const activeDirectRequests = visible;
  const activeTotal = tab === "orcamentos" || tab === "enviadas" ? activeQuotes.length : activeDirectRequests.length;
  const visiblePage = activeQuotes.slice((page - 1) * pageSize, page * pageSize);
  const visibleDirectPage = activeDirectRequests.slice((page - 1) * pageSize, page * pageSize);

  const decide = (id: string, decision: RequestDecision) => {
    saveRequestDecision(id, decision);
    setDecisions(readRequestDecisions());
    if (decision === "aceito") {
      addNotification({ role: "profissional", title: "Pedido aceito", detail: "O cliente foi avisado. Confira os dados para combinar os próximos passos.", href: "/pro/agenda" });
      toast.success("Pedido aceito e adicionado aos seus compromissos");
    } else toast("Pedido removido da sua lista de oportunidades");
  };

  const submitProposal = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!proposalFor || !Number(price) || !days.trim()) return;
    const updated = sendQuoteProposal(proposalFor.id, { proId: proMe.id, price: Number(price), days: days.trim(), note: note.trim() || "Proposta enviada pelo profissional." });
    if (!updated) { toast.error("Não foi possível enviar. Talvez você já tenha respondido a este pedido."); return; }
    setQuotes([...readQuoteRequests()]);
    setProposalFor(null); setPrice(""); setDays(""); setNote("");
    setTab("enviadas");
    toast.success("Proposta enviada ao cliente");
  };

  return <div>
    <PageTitle eyebrow="Área profissional" title="Oportunidades de clientes" subtitle="Encontre serviços publicados pelos clientes, demonstre interesse e acompanhe as propostas enviadas." action={<Link to="/pro/agenda" className="rounded-full border px-4 py-2.5 text-sm font-bold hover:bg-muted">Organizar meus serviços</Link>} />
    <div className="mb-5 flex flex-wrap gap-2">{(["orcamentos", "enviadas", "novos", "aceitos", "dispensados"] as const).map((value) => <button key={value} onClick={() => setTab(value)} className={cn("rounded-full border px-4 py-2 text-sm font-semibold transition", tab === value ? "border-primary bg-primary text-primary-foreground" : "bg-card text-muted-foreground hover:bg-muted")}><span>{value === "novos" ? "Pedidos diretos" : value === "orcamentos" ? "Pedidos dos clientes" : value === "enviadas" ? "Propostas enviadas" : value === "aceitos" ? "Aceitos" : "Dispensados"}</span><span className="ml-2 rounded-full bg-foreground/10 px-2 py-0.5 text-xs">{counts[value]}</span></button>)}</div>

    {tab === "orcamentos" || tab === "enviadas" ? <div className="grid gap-4 lg:grid-cols-2">
      {visiblePage.map((request) => {
        const ownProposal = request.proposals.find((proposal) => proposal.proId === proMe.id);
        const accepted = ownProposal && request.acceptedProposalId === ownProposal.id;
        return <article key={request.id} className="surface p-5 sm:p-6">
        <div className="flex items-start justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">{request.id} · {categoryName(request.category)}</p><h2 className="font-display mt-1 text-xl font-bold">{tab === "enviadas" ? request.description : "Pedido de serviço do cliente"}</h2></div><span className={cn("rounded-full px-3 py-1.5 text-xs font-bold", tab === "enviadas" ? accepted ? "bg-status-success/15 text-status-success" : "bg-status-info/15 text-status-info" : "bg-status-warning/20 text-status-warning-foreground")}>{tab === "enviadas" ? accepted ? "Proposta aceita" : request.status === "Aceito" ? "Cliente escolheu outra proposta" : "Aguardando resposta" : "Aberto para propostas"}</span></div>
        <p className="mt-4 whitespace-pre-wrap text-sm leading-relaxed">{request.description}</p>
        {request.referencePrice !== undefined && <div className="mt-3 inline-flex flex-wrap items-center gap-2 rounded-sm bg-accent px-3 py-2 text-xs font-semibold text-accent-foreground"><span>{request.sourceService ?? "Preço fechado selecionado"}</span><span aria-hidden="true">·</span><span>Referência: {brl(request.referencePrice)}</span></div>}
        <div className="mt-4 grid gap-3 rounded-2xl bg-muted p-4 sm:grid-cols-2"><div><p className="text-[10px] font-bold uppercase text-muted-foreground">Quando</p><p className="mt-1 text-sm font-semibold">{quoteWhenLabel(request)}</p></div><div><p className="text-[10px] font-bold uppercase text-muted-foreground">Região aproximada</p><p className="mt-1 flex items-center gap-1.5 text-sm font-semibold"><MapPin className="h-3.5 w-3.5" />CEP {request.cep.slice(0, 2)}***</p></div></div>
        {request.photos.length > 0 && <div className="mt-3 flex gap-2">{request.photos.map((image, index) => <img key={image} src={image} alt={`Referência ${index + 1}`} className="h-16 w-16 rounded-xl object-cover" loading="lazy" />)}</div>}
        {tab === "enviadas" && ownProposal ? <div className="mt-4 rounded-2xl bg-muted p-4"><p className="text-xs font-bold uppercase text-muted-foreground">Sua proposta</p><p className="mt-1 font-display text-xl font-extrabold">{brl(ownProposal.price)} · {ownProposal.days}</p><p className="mt-1 text-sm text-muted-foreground">{ownProposal.note || "Sem mensagem adicional."}</p></div> : <button onClick={() => { setProposalFor(request); setPrice(request.referencePrice ? String(request.referencePrice) : ""); setDays(""); setNote(""); }} className="mt-5 inline-flex items-center gap-2 rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground"><Send className="h-4 w-4" />Enviar proposta ao cliente</button>}
      </article>;
      })}
      {!(tab === "orcamentos" ? availableQuotes : sentQuotes).length && <div className="surface col-span-full grid min-h-60 place-items-center p-8 text-center"><div><FileText className="mx-auto h-8 w-8 text-muted-foreground" /><h2 className="font-display mt-3 font-bold">{tab === "enviadas" ? "Nenhuma proposta enviada" : "Nenhum pedido compatível por enquanto"}</h2><p className="mt-1 text-sm text-muted-foreground">{tab === "enviadas" ? "Quando você enviar uma proposta, ela aparecerá aqui para acompanhamento." : `Solicitações abertas da categoria ${categoryName(profile.category)} aparecerão nesta aba.`}</p></div></div>}
    </div> : <div className="grid gap-4 lg:grid-cols-2">
      {visibleDirectPage.map((request) => <article key={request.id} className="surface p-5 sm:p-6">
        <div className="flex flex-wrap items-start justify-between gap-3"><div><p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">{request.id} · {request.clientType}</p><h2 className="font-display mt-1 text-xl font-bold">{request.title}</h2></div><span className={cn("rounded-full px-3 py-1.5 text-sm font-bold", request.kind === "fixo" ? "bg-accent text-accent-foreground" : "bg-secondary text-secondary-foreground")}>{request.kind === "fixo" ? brl(request.price!) : "Enviar proposta"}</span></div>
        <div className="mt-4 grid gap-3 rounded-2xl bg-muted p-4 sm:grid-cols-2"><div><p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">Cliente</p><p className="mt-1 text-sm font-semibold">{request.client}</p><p className="text-xs text-muted-foreground">{request.clientType}</p></div><div><p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">Prazo desejado</p><p className="mt-1 flex items-center gap-1.5 text-sm font-semibold"><CalendarDays className="h-3.5 w-3.5" />{request.when}</p></div><div><p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">Distância</p><p className="mt-1 flex items-center gap-1.5 text-sm font-semibold"><MapPin className="h-3.5 w-3.5" />{request.distanceKm.toString().replace(".", ",")} km · sua região de atendimento</p></div><div><p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">Endereço aproximado</p><p className="mt-1 text-sm font-semibold">{request.address}</p></div></div>
        <p className="mt-4 flex items-center gap-2 text-xs text-muted-foreground"><Clock className="h-3.5 w-3.5" />{request.kind === "fixo" ? "Valor combinado com o cliente. Você confirma disponibilidade ao aceitar." : "O cliente espera uma estimativa e prazo para execução."}</p>
        {tab === "novos" ? <div className="mt-5 flex flex-wrap gap-2"><button onClick={() => decide(request.id, "aceito")} className="inline-flex items-center gap-1.5 rounded-full bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground hover:bg-primary/90"><Check className="h-4 w-4" />{request.kind === "fixo" ? "Aceitar pedido" : "Tenho interesse"}</button><button onClick={() => decide(request.id, "dispensado")} className="inline-flex items-center gap-1.5 rounded-full border px-4 py-2.5 text-sm font-bold hover:bg-muted"><X className="h-4 w-4" />Dispensar</button><button onClick={() => toast("O chat será liberado após o cliente confirmar o serviço.")} className="ml-auto inline-flex items-center gap-1.5 rounded-full px-3 py-2.5 text-sm font-bold text-muted-foreground hover:bg-muted"><MessageCircle className="h-4 w-4" />Conversar</button></div> : <div className="mt-5 flex items-center gap-2 rounded-xl bg-muted px-4 py-3 text-sm font-semibold"><BriefcaseBusiness className="h-4 w-4 text-primary" />{tab === "aceitos" ? "Pedido aceito · combine os detalhes com o cliente" : "Pedido dispensado"}</div>}
      </article>)}
      {!visible.length && <div className="surface col-span-full grid min-h-60 place-items-center p-8 text-center"><div><BriefcaseBusiness className="mx-auto h-8 w-8 text-muted-foreground" /><h2 className="font-display mt-3 font-bold">{tab === "novos" ? "Sem pedidos diretos novos" : `Nenhum pedido ${tab}`}</h2><p className="mt-1 text-sm text-muted-foreground">Novas oportunidades compatíveis aparecerão aqui.</p></div></div>}
    </div>}

    <Pagination currentPage={page} totalItems={activeTotal} pageSize={pageSize} onPageChange={setPage} label={tab === "novos" || tab === "aceitos" || tab === "dispensados" ? "pedidos" : "solicitações"} />

    <Dialog open={!!proposalFor} onOpenChange={(open) => !open && setProposalFor(null)}><DialogContent className="max-w-lg rounded-3xl"><DialogHeader><DialogTitle className="font-display text-2xl">Enviar proposta</DialogTitle><DialogDescription>O cliente verá sua proposta na aba Orçamentos em Meus serviços.</DialogDescription></DialogHeader><form onSubmit={submitProposal} className="space-y-3"><div className="rounded-xl bg-muted p-3 text-sm"><b>{proposalFor?.id}</b> · {proposalFor?.description}{proposalFor?.referencePrice !== undefined && <p className="mt-1 text-xs font-semibold text-primary">Valor de referência: {brl(proposalFor.referencePrice)}</p>}</div><label className="block space-y-1.5 text-sm font-semibold">Valor total<input required min="1" step="1" type="number" value={price} onChange={(event) => setPrice(event.target.value)} placeholder={proposalFor?.referencePrice ? String(proposalFor.referencePrice) : "Ex.: 350"} className="w-full rounded-xl border bg-background px-3.5 py-3 outline-none" /></label><label className="block space-y-1.5 text-sm font-semibold">Prazo estimado<input required value={days} onChange={(event) => setDays(event.target.value)} placeholder="Ex.: 2 dias" className="w-full rounded-xl border bg-background px-3.5 py-3 outline-none" /></label><label className="block space-y-1.5 text-sm font-semibold">Mensagem ao cliente<textarea rows={3} maxLength={500} value={note} onChange={(event) => setNote(event.target.value)} placeholder="Explique o que está incluído e as condições do serviço" className="w-full resize-y rounded-xl border bg-background px-3.5 py-3 outline-none" /></label><button className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary py-3 font-bold text-primary-foreground"><Send className="h-4 w-4" />Enviar ao cliente</button></form></DialogContent></Dialog>
  </div>;
}
