import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { z } from "zod";
import { MapPin, ArrowRight, UserRound } from "lucide-react";
import { PageTitle, ProCard } from "@/components/app/ui-bits";
import { Pagination } from "@/components/app/pagination";
import { AdPlacement } from "@/components/app/ad-placement";
import { CatalogSearch } from "@/components/app/catalog-search";
import { normalizeSearch } from "@/lib/search";
import { EmptyState, actionClass, secondaryActionClass } from "@/components/app/workspace-ui";
import { categories, type Professional } from "@/lib/demo-data";
import {
  getClientFacingProfessionals,
  subscribeToProfessionalProfile,
} from "@/lib/professional-store";
import { subscribeToSession } from "@/lib/auth-store";
import {
  distanceBetweenKm,
  readDeviceLocation,
  subscribeToLocation,
  type DeviceLocation,
} from "@/lib/location-store";

const searchSchema = z.object({ q: z.string().optional(), cat: z.string().optional() });
export const Route = createFileRoute("/profissionais")({
  validateSearch: (search) => searchSchema.parse(search),
  head: () => ({ meta: [{ title: "Profissionais — ServiX" }] }),
  component: ProfessionalsPage,
});

function ProfessionalsPage() {
  const { q, cat } = Route.useSearch();
  const navigate = useNavigate({ from: "/profissionais" });
  const [text, setText] = useState(q ?? "");
  const [pros, setPros] = useState<Professional[]>([]);
  const [location, setLocation] = useState<DeviceLocation | null>(null);
  const [sort, setSort] = useState("rating");
  const [page, setPage] = useState(1);
  useEffect(() => {
    const refresh = () => setPros(getClientFacingProfessionals());
    refresh();
    const a = subscribeToProfessionalProfile(refresh);
    const b = subscribeToSession(refresh);
    return () => {
      a();
      b();
    };
  }, []);
  useEffect(() => {
    const refresh = () => setLocation(readDeviceLocation("cliente"));
    refresh();
    return subscribeToLocation(refresh);
  }, []);
  useEffect(() => setText(q ?? ""), [q]);
  useEffect(() => setPage(1), [text, cat, sort]);
  const selected = categories.find((item) => item.slug === cat);
  const list = useMemo(() => {
    const terms = normalizeSearch(text).split(/\s+/).filter(Boolean);
    return pros
      .map((pro) => ({
        ...pro,
        distanceKm:
          location && pro.latitude !== undefined && pro.longitude !== undefined
            ? Math.round(
                distanceBetweenKm(location, { latitude: pro.latitude, longitude: pro.longitude }) *
                  10,
              ) / 10
            : pro.distanceKm,
      }))
      .filter(
        (pro) =>
          (!cat ||
            pro.category === cat ||
            pro.services.some((service) => (service.category ?? pro.category) === cat)) &&
          terms.every((term) =>
            normalizeSearch(
              [
                pro.name,
                pro.role,
                pro.neighborhood,
                pro.bio,
                ...pro.services.map((service) => service.name),
              ].join(" "),
            ).includes(term),
          ),
      )
      .sort((a, b) =>
        sort === "name"
          ? a.name.localeCompare(b.name, "pt-BR")
          : sort === "distance"
            ? (Number.isFinite(a.distanceKm) ? a.distanceKm : Infinity) -
              (Number.isFinite(b.distanceKm) ? b.distanceKm : Infinity)
            : b.rating - a.rating || b.reviews - a.reviews,
      );
  }, [pros, text, cat, location, sort]);
  const clear = () => {
    setText("");
    void navigate({ search: {} });
  };
  return (
    <div className="servix-workspace min-w-0 space-y-7">
      <PageTitle
        title="Profissionais"
        subtitle="Conheça quem faz, confira as especialidades e escolha com mais informação."
        action={
          <Link to="/buscar" className={secondaryActionClass}>
            <MapPin className="h-4 w-4" /> Ver no mapa
          </Link>
        }
      />
      <CatalogSearch
        title="Encontre quem entende do assunto."
        description="Explore os perfis, os serviços oferecidos e as avaliações dos clientes."
        label="Pesquisar profissionais"
        placeholder="Nome, especialidade ou região"
        value={text}
        onChange={setText}
        category={selected?.slug}
        onCategory={(slug) => {
          void navigate({ search: { q: text.trim() || undefined, cat: slug } });
        }}
        onSubmit={(event) => {
          event.preventDefault();
          void navigate({ search: { q: text.trim() || undefined, cat } });
        }}
      />
      <AdPlacement channel="profissionais" compact />
      <div className="grid min-w-0 items-start gap-7 xl:grid-cols-[minmax(0,1fr)_17rem]">
        <section className="min-w-0 space-y-5">
          <div className="flex flex-wrap items-center justify-between gap-3 border-b pb-4">
            <div>
              <h2 className="text-xl font-bold">{selected?.name ?? "Conheça os profissionais"}</h2>
              <p role="status" className="mt-1 text-xs text-muted-foreground">
                {list.length} {list.length === 1 ? "perfil encontrado" : "perfis encontrados"}
              </p>
            </div>
            <select
              aria-label="Ordenar profissionais"
              value={sort}
              onChange={(event) => setSort(event.target.value)}
              className="rounded-md border bg-card px-3 py-2.5 text-xs font-semibold"
            >
              <option value="rating">Melhor avaliação</option>
              <option value="distance">Mais próximos</option>
              <option value="name">Nome: A a Z</option>
            </select>
          </div>
          {(text.trim() || cat) && (
            <div className="flex flex-wrap items-center gap-3 text-xs text-muted-foreground">
              <span>
                {selected?.name}
                {selected && text.trim() ? " · " : ""}
                {text.trim()}
              </span>
              <button
                type="button"
                onClick={clear}
                className="font-semibold text-primary underline underline-offset-4"
              >
                Limpar filtros
              </button>
            </div>
          )}
          {list.length ? (
            <div className="grid min-w-0 gap-4 md:grid-cols-2">
              {list.slice((page - 1) * 10, page * 10).map((pro) => (
                <ProCard key={pro.id} pro={pro} />
              ))}
            </div>
          ) : (
            <EmptyState
              icon={UserRound}
              title={
                text.trim() || cat
                  ? "Nenhum perfil para esta busca"
                  : "Novos profissionais vão aparecer aqui"
              }
              description={
                text.trim() || cat
                  ? "Tente outra especialidade ou ajuste o termo pesquisado."
                  : "Os perfis ficam disponíveis quando os profissionais publicam seus serviços."
              }
            >
              {text.trim() || cat ? (
                <button onClick={clear} className={actionClass}>
                  Ver todos os profissionais
                </button>
              ) : (
                <Link to="/vagas" className={actionClass}>
                  Publicar o que preciso <ArrowRight className="h-4 w-4" />
                </Link>
              )}
            </EmptyState>
          )}
          <Pagination
            currentPage={page}
            totalItems={list.length}
            pageSize={10}
            onPageChange={setPage}
            label="profissionais"
          />
        </section>
        <aside className="rounded-xl border bg-secondary/40 p-6">
          <MapPin className="mb-4 h-6 w-6 text-primary" />
          <h2 className="text-lg font-bold">O atendimento começa perto.</h2>
          <p className="mt-3 text-sm leading-relaxed text-muted-foreground">
            {location
              ? "Sua localização está ativa. Você pode ordenar os perfis pela distância ou explorar o mapa."
              : "Defina sua localização no topo da página para comparar profissionais que atendem na sua região."}
          </p>
          <Link to="/buscar" className={`${secondaryActionClass} mt-5 w-full`}>
            Explorar o mapa <ArrowRight className="h-4 w-4" />
          </Link>
        </aside>
      </div>
    </div>
  );
}
