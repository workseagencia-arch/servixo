import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState } from "react";
import {
  ArrowLeft,
  MapPin,
  Briefcase,
  Clock,
  MessageCircle,
  Radar,
  CalendarCheck,
  Flag,
} from "lucide-react";
import { toast } from "sonner";
import { findPro, brl, categoryName } from "@/lib/demo-data";
import { Avatar, Rating, Verified, portfolioImages } from "@/components/app/ui-bits";
import { HireDialog, QuoteDialog } from "@/components/app/booking-dialogs";
import {
  getClientFacingProfessionalById,
  subscribeToProfessionalProfile,
} from "@/lib/professional-store";
import { createModerationReport } from "@/lib/security-store";
import { readSession } from "@/lib/auth-store";
import { startProfessionalChat } from "@/lib/message-store";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export const Route = createFileRoute("/profissional/$id")({
  loader: ({ params }) => {
    const pro = findPro(params.id);
    return { pro: pro ?? null };
  },
  head: ({ loaderData }) => {
    if (!loaderData?.pro) return { meta: [{ title: "Perfil profissional — ServiX" }] };
    const { pro } = loaderData;
    const t = `${pro.name}, ${pro.role} — ServiX`;
    return {
      meta: [
        { title: t },
        { name: "description", content: pro.bio },
        { property: "og:title", content: t },
        { property: "og:description", content: pro.bio },
      ],
    };
  },
  notFoundComponent: () => (
    <p className="py-20 text-center">
      Profissional não encontrado.{" "}
      <Link to="/buscar" className="underline">
        Voltar à busca
      </Link>
    </p>
  ),
  component: ProfilePage,
});

function ProfilePage() {
  const { id } = Route.useParams();
  const { pro: initialPro } = Route.useLoaderData();
  const [ready, setReady] = useState(false);
  const [pro, setPro] = useState(initialPro);
  const [hire, setHire] = useState<{ name: string; price: number; duration: string } | null>(null);
  const [quote, setQuote] = useState(false);
  const [reportOpen, setReportOpen] = useState(false);
  const [reportReason, setReportReason] = useState("Informações do perfil parecem incorretas");
  const [reportDetail, setReportDetail] = useState("");
  const [unavailable, setUnavailable] = useState(false);
  const navigate = useNavigate();
  useEffect(() => {
    const refresh = () => {
      const latest = getClientFacingProfessionalById(id) ?? findPro(id);
      setUnavailable(!latest);
      if (latest) setPro(latest);
      setReady(true);
    };
    refresh();
    return subscribeToProfessionalProfile(refresh);
  }, [id]);
  if (!ready)
    return (
      <p role="status" className="py-16 text-center text-sm text-muted-foreground">
        Carregando o perfil profissional…
      </p>
    );
  if (!pro)
    return (
      <div className="surface mx-auto max-w-xl p-8 text-center">
        <h1 className="text-xl font-bold">Perfil indisponível</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Este profissional não está disponível no momento.
        </p>
        <Link
          to="/profissionais"
          className="mt-5 inline-flex rounded-md bg-primary px-5 py-2.5 text-sm font-semibold text-primary-foreground"
        >
          Consultar profissionais
        </Link>
      </div>
    );
  const cheapest = pro.services
    .filter((service) => service.price !== null)
    .sort((a, b) => a.price! - b.price!)[0];
  const displayPrice = cheapest ? brl(cheapest.price!) : "Sob consulta";
  const quickHire = () =>
    cheapest
      ? setHire({ name: cheapest.name, price: cheapest.price!, duration: cheapest.duration })
      : setQuote(true);
  const openConversation = () => {
    const session = readSession();
    if (!session) {
      void navigate({ to: "/entrar", search: { perfil: "cliente" } });
      return;
    }
    const sender = session?.role === "profissional" ? "profissional" : "cliente";
    const service = cheapest?.name ?? `Consulta ao perfil de ${pro.name}`;
    const thread = startProfessionalChat({
      proId: pro.id,
      service,
      clientName: session?.name ?? "Cliente",
      professionalName: pro.name,
      ...(pro.photoUrl ? { professionalPhotoUrl: pro.photoUrl } : {}),
      ...(cheapest ? { price: cheapest.price, duration: cheapest.duration } : {}),
      sender,
    });
    toast.success("Conversa aberta. Escreva sua mensagem quando quiser.");
    void navigate({
      to: sender === "profissional" ? "/pro/mensagens" : "/mensagens",
      search: { thread: thread.id },
    });
  };

  if (unavailable)
    return (
      <div className="surface mx-auto max-w-xl p-8 text-center">
        <ShieldCheckFallback />
        <h1 className="mt-3 font-display text-xl font-bold">Perfil indisponível</h1>
        <p className="mt-2 text-sm text-muted-foreground">
          Este perfil está temporariamente fora da plataforma.
        </p>
        <Link
          to="/buscar"
          className="mt-5 inline-flex rounded-full bg-primary px-5 py-2.5 text-sm font-bold text-primary-foreground"
        >
          Voltar à busca
        </Link>
      </div>
    );

  return (
    <div className="servix-workspace min-w-0 pb-36 md:pb-0">
      <Link
        to="/buscar"
        className="mb-4 inline-flex items-center gap-1.5 text-sm font-semibold text-muted-foreground hover:text-foreground"
      >
        <ArrowLeft className="h-4 w-4" />
        Voltar
      </Link>

      <div className="grid min-w-0 gap-6 lg:grid-cols-[minmax(0,1fr)_20rem]">
        <div className="min-w-0 space-y-6">
          <section className="surface overflow-hidden">
            <div className="bg-hero h-28 md:h-36" />
            <div className="px-5 pb-6 md:px-7">
              <Avatar pro={pro} size="xl" className="-mt-14 w-fit rounded-full ring-4 ring-card" />
              <div className="mt-3 flex flex-wrap items-center gap-2">
                <h1 className="font-display text-3xl font-extrabold">{pro.name}</h1>
                {pro.verified && <Verified />}
              </div>
              <p className="text-muted-foreground">{pro.role}</p>
              <div className="mt-4 grid grid-cols-3 gap-2 rounded-2xl bg-muted p-3 text-center">
                <div>
                  <Rating value={pro.rating} className="justify-center text-base" />
                  <p className="text-xs text-muted-foreground">{pro.reviews} avaliações</p>
                </div>
                <div>
                  <p className="font-display text-lg font-bold">{pro.jobs}</p>
                  <p className="text-xs text-muted-foreground">serviços</p>
                </div>
                <div>
                  <p className="font-display text-lg font-bold">{pro.years} anos</p>
                  <p className="text-xs text-muted-foreground">experiência</p>
                </div>
              </div>
              <p className="mt-5 leading-relaxed">{pro.bio}</p>
              <div className="mt-4 flex flex-wrap gap-x-5 gap-y-2 text-sm text-muted-foreground">
                <span className="flex items-center gap-1.5">
                  <MapPin className="h-4 w-4" />
                  {pro.neighborhood || "Região a combinar"}
                  {Number.isFinite(pro.distanceKm)
                    ? ` · ${pro.distanceKm.toLocaleString("pt-BR")} km`
                    : ""}
                </span>
                <span className="flex items-center gap-1.5">
                  <Radar className="h-4 w-4" />
                  Atende até {pro.radiusKm} km
                </span>
                <span className="flex items-center gap-1.5">
                  <Clock className="h-4 w-4" />
                  {pro.availability}
                </span>
              </div>
            </div>
          </section>

          <section className="surface p-5 md:p-7">
            <h2 className="font-display mb-4 text-xl font-bold">Serviços oferecidos</h2>
            <div className="divide-y">
              {!pro.services.length && (
                <p className="py-3 text-sm text-muted-foreground">
                  Este profissional está atualizando os serviços disponíveis. Peça um orçamento para
                  conversar.
                </p>
              )}
              {pro.services.map((s) => (
                <div
                  key={s.name}
                  className="flex min-w-0 flex-wrap items-center justify-between gap-3 py-3.5"
                >
                  <div className="min-w-0">
                    <p className="font-semibold">{s.name}</p>
                    <p className="flex items-center gap-1 text-xs text-muted-foreground">
                      <Briefcase className="h-3 w-3" />
                      {s.duration}
                      {s.category && s.category !== pro.category && (
                        <> · {categoryName(s.category)}</>
                      )}
                    </p>
                  </div>
                  {s.price !== null ? (
                    <div className="flex flex-wrap items-center gap-3">
                      <span className="font-display text-lg font-bold">{brl(s.price)}</span>
                      <button
                        onClick={() =>
                          setHire({ name: s.name, price: s.price!, duration: s.duration })
                        }
                        className="rounded-full bg-primary px-4 py-2 text-sm font-bold text-primary-foreground"
                      >
                        Contratar
                      </button>
                    </div>
                  ) : (
                    <button
                      onClick={() => setQuote(true)}
                      className="rounded-full border px-4 py-2 text-sm font-bold hover:bg-muted"
                    >
                      Orçamento
                    </button>
                  )}
                </div>
              ))}
            </div>
          </section>

          <section className="surface p-5 md:p-7">
            <h2 className="font-display mb-4 text-xl font-bold">Portfólio</h2>
            <div className="grid grid-cols-3 gap-2">
              {pro.portfolio.map((i, idx) => (
                <img
                  key={idx}
                  src={portfolioImages[i]}
                  alt={`Trabalho ${idx + 1} de ${pro.name}`}
                  loading="lazy"
                  width={816}
                  height={816}
                  className="aspect-square w-full rounded-xl object-cover"
                />
              ))}
            </div>
          </section>

          <section className="surface p-5 md:p-7">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="font-display text-xl font-bold">Avaliações</h2>
              <Rating value={pro.rating} count={pro.reviews} />
            </div>
            <div className="space-y-4">
              {pro.reviewList.map((r) => (
                <div key={r.author + r.date} className="rounded-2xl bg-muted p-4">
                  <div className="flex items-center justify-between">
                    <p className="font-semibold">{r.author}</p>
                    <span className="text-xs text-muted-foreground">{r.date}</span>
                  </div>
                  <p className="text-sm text-status-warning">
                    {"★".repeat(r.rating)}
                    <span className="text-border">{"★".repeat(5 - r.rating)}</span>{" "}
                    <span className="text-xs text-muted-foreground">· {r.service}</span>
                    {r.verifiedPurchase && (
                      <span className="ml-2 rounded-full bg-accent px-2 py-0.5 text-[10px] font-bold text-accent-foreground">
                        Contratação verificada
                      </span>
                    )}
                  </p>
                  <p className="mt-1.5 text-sm">{r.text}</p>
                </div>
              ))}
            </div>
          </section>
        </div>

        <aside className="min-w-0 space-y-4 lg:sticky lg:top-24 lg:self-start">
          <div className="surface p-5">
            <p className="text-xs uppercase tracking-wide text-muted-foreground">
              {cheapest ? "a partir de" : "preço"}
            </p>
            <p className="font-display text-3xl font-extrabold">{displayPrice}</p>
            <button
              onClick={quickHire}
              className="mt-4 w-full rounded-full bg-primary py-3.5 font-bold text-primary-foreground"
            >
              {cheapest ? `Contratar ${pro.online ? "agora" : ""}` : "Solicitar orçamento"}
            </button>
            <button
              onClick={() => setQuote(true)}
              className="mt-2 w-full rounded-full border py-3.5 font-bold hover:bg-muted"
            >
              Solicitar orçamento
            </button>
            <button
              onClick={openConversation}
              className="mt-2 flex w-full items-center justify-center gap-2 rounded-full py-3 text-sm font-bold hover:bg-muted"
            >
              <MessageCircle className="h-4 w-4" />
              Conversar
            </button>
          </div>
          <div className="surface p-5">
            <p className="mb-3 flex items-center gap-2 font-bold">
              <CalendarCheck className="h-4 w-4" />
              Disponibilidade
            </p>
            <p className="text-sm font-semibold">
              {pro.online ? "Disponível para contato" : "Consulte a disponibilidade"}
            </p>
            <p className="mt-2 text-xs leading-relaxed text-muted-foreground">
              Combine os dias e horários de atendimento diretamente com o profissional.
            </p>
          </div>
          <button
            onClick={() => setReportOpen(true)}
            className="flex w-full items-center justify-center gap-2 rounded-2xl border px-4 py-3 text-sm font-semibold text-muted-foreground hover:bg-muted"
          >
            <Flag className="h-4 w-4" />
            Denunciar este perfil
          </button>
        </aside>
      </div>

      {/* Mobile sticky CTA */}
      <div className="fixed inset-x-0 bottom-[calc(4.75rem+env(safe-area-inset-bottom))] z-30 border-t bg-card/95 p-3 backdrop-blur md:hidden">
        <div className="flex flex-wrap items-center gap-2">
          <div className="w-full min-w-0">
            <p className="text-[11px] text-muted-foreground">
              {cheapest ? "a partir de" : "preço"}
            </p>
            <p className="font-display text-xl font-bold">{displayPrice}</p>
          </div>
          <button
            onClick={() => setQuote(true)}
            className="flex-1 rounded-md border px-3 py-2.5 text-sm font-semibold"
          >
            Orçamento
          </button>
          <button
            onClick={quickHire}
            className="flex-1 rounded-md bg-primary px-3 py-2.5 text-sm font-semibold text-primary-foreground"
          >
            {cheapest ? "Contratar" : "Orçamento"}
          </button>
        </div>
      </div>

      <HireDialog
        pro={pro}
        service={hire}
        open={!!hire}
        onOpenChange={(o) => !o && setHire(null)}
      />
      <QuoteDialog pro={pro} open={quote} onOpenChange={setQuote} />
      <Dialog open={reportOpen} onOpenChange={setReportOpen}>
        <DialogContent className="max-h-[90dvh] overflow-y-auto rounded-3xl sm:max-w-lg">
          <DialogHeader>
            <DialogTitle>Denunciar perfil</DialogTitle>
            <DialogDescription>
              Ajude a equipe ServiX a revisar informações que possam afetar a segurança ou a
              confiança de outros clientes.
            </DialogDescription>
          </DialogHeader>
          <label className="space-y-1.5 text-sm font-semibold">
            Motivo
            <select
              value={reportReason}
              onChange={(event) => setReportReason(event.target.value)}
              className="w-full rounded-xl border bg-background px-3.5 py-3 text-sm font-normal"
            >
              <option>Informações do perfil parecem incorretas</option>
              <option>Comportamento inadequado</option>
              <option>Suspeita de fraude</option>
              <option>Conteúdo impróprio</option>
              <option>Outro motivo</option>
            </select>
          </label>
          <label className="space-y-1.5 text-sm font-semibold">
            Detalhes
            <textarea
              rows={4}
              maxLength={500}
              value={reportDetail}
              onChange={(event) => setReportDetail(event.target.value)}
              placeholder="Descreva o que a equipe deve revisar."
              className="w-full rounded-xl border bg-background p-3 text-sm font-normal"
            />
          </label>
          <button
            onClick={() => {
              createModerationReport({
                subjectType: "profissional",
                subjectId: pro.id,
                subjectName: pro.name,
                reason: reportReason,
                detail: reportDetail.trim() || "Cliente solicitou revisão deste perfil.",
              });
              setReportOpen(false);
              setReportDetail("");
              toast.success("Relato enviado à equipe de segurança.");
            }}
            className="w-full rounded-full bg-primary py-3 font-bold text-primary-foreground"
          >
            Enviar relato
          </button>
          <p className="text-center text-[10px] text-muted-foreground">
            Demonstração local: o envio ficará visível no painel da equipe neste navegador.
          </p>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function ShieldCheckFallback() {
  return (
    <span className="mx-auto grid h-11 w-11 place-items-center rounded-2xl bg-accent text-accent-foreground">
      <Flag className="h-5 w-5" />
    </span>
  );
}
