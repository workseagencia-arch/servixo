import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type FormEvent } from "react";
import {
  BriefcaseBusiness,
  CalendarDays,
  Check,
  CheckCircle2,
  FileText,
  MapPin,
  Send,
  UserRoundPlus,
  X,
} from "lucide-react";
import { toast } from "sonner";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import { PageTitle } from "@/components/app/ui-bits";
import { Pagination } from "@/components/app/pagination";
import { QuoteDialog } from "@/components/app/booking-dialogs";
import { AdPlacement } from "@/components/app/ad-placement";
import {
  brl,
  categories,
  categoryName,
  proMe,
  proRequests,
  quoteWhenLabel,
  readQuoteRequests,
  sendQuoteProposal,
  subscribeToQuoteRequests,
  type QuoteRequest,
} from "@/lib/demo-data";
import { addNotification } from "@/lib/notification-store";
import {
  readRequestDecisions,
  saveRequestDecision,
  type RequestDecision,
} from "@/lib/pro-workspace-store";
import {
  hasProfessionalAccess,
  readSession,
  subscribeToSession,
  type AuthSession,
} from "@/lib/auth-store";
import { readProfessionalCategories } from "@/lib/professional-store";
import {
  distanceBetweenKm,
  readDeviceLocation,
  subscribeToLocation,
  type DeviceLocation,
} from "@/lib/location-store";
import { cn } from "@/lib/utils";
import { CatalogSearch } from "@/components/app/catalog-search";
import { normalizeSearch } from "@/lib/search";
import { PanelTabs } from "@/components/app/workspace-ui";
import type { CategorySlug } from "@/lib/demo-data";

export const Route = createFileRoute("/vagas")({
  head: () => ({
    meta: [
      { title: "Vagas e pedidos de serviço — ServiX" },
      {
        name: "description",
        content:
          "Publique um serviço que procura ou envie propostas para vagas compatíveis com sua especialidade.",
      },
    ],
  }),
  component: JobsPage,
});

type JobsTab = "minhas" | "proximas" | "enviadas";
const inputClass =
  "w-full rounded-xl border bg-background px-3.5 py-3 text-sm outline-none focus:ring-2 focus:ring-ring/20";

function JobsPage() {
  const navigate = useNavigate();
  const [session, setSession] = useState<AuthSession | null>(null);
  const [requests, setRequests] = useState<QuoteRequest[]>([]);
  const [decisions, setDecisions] = useState<ReturnType<typeof readRequestDecisions>>({});
  const [location, setLocation] = useState<DeviceLocation | null>(null);
  const [query, setQuery] = useState("");
  const [category, setCategory] = useState<CategorySlug>();
  const [tab, setTab] = useState<JobsTab>("minhas");
  const [page, setPage] = useState(1);
  const pageSize = 10;
  const [quoteOpen, setQuoteOpen] = useState(false);
  const [proposalFor, setProposalFor] = useState<QuoteRequest | null>(null);
  const [price, setPrice] = useState("");
  const [days, setDays] = useState("");
  const [note, setNote] = useState("");

  useEffect(() => {
    const refresh = () => setSession(readSession());
    refresh();
    return subscribeToSession(refresh);
  }, []);
  useEffect(() => setPage(1), [tab, query, category]);
  useEffect(() => {
    const refresh = () => setDecisions(readRequestDecisions());
    refresh();
    window.addEventListener("servix:request-change", refresh);
    return () => window.removeEventListener("servix:request-change", refresh);
  }, []);
  useEffect(() => {
    const refresh = () => setRequests([...readQuoteRequests()]);
    refresh();
    return subscribeToQuoteRequests(refresh);
  }, []);
  useEffect(() => {
    const refresh = () => setLocation(readDeviceLocation("profissional"));
    refresh();
    return subscribeToLocation(refresh);
  }, []);

  const professional = hasProfessionalAccess(session);
  const categoriesOffered = professional ? readProfessionalCategories() : [];
  const ownerEmail = session?.email.toLocaleLowerCase("pt-BR");
  const matches = (request: QuoteRequest) =>
    (!category || request.category === category) &&
    normalizeSearch(
      `${request.description} ${request.address} ${request.sourceService ?? ""} ${categoryName(request.category)}`,
    ).includes(normalizeSearch(query));
  const filteredRequests = requests.filter(matches);
  const ownRequests = filteredRequests.filter(
    (request) => !!ownerEmail && request.ownerEmail?.toLocaleLowerCase("pt-BR") === ownerEmail,
  );
  const sentQuotes = filteredRequests.flatMap((request) => {
    const proposal = request.proposals.find((item) => item.proId === proMe.id);
    return proposal ? [{ request, proposal }] : [];
  });
  const categorySet = new Set(categoriesOffered);
  const openRequests = filteredRequests
    .filter(
      (request) =>
        request.status === "Aguardando propostas" &&
        categorySet.has(request.category as (typeof categoriesOffered)[number]) &&
        (!request.targetProId || request.targetProId === proMe.id) &&
        request.ownerEmail?.toLocaleLowerCase("pt-BR") !== ownerEmail &&
        !request.proposals.some((proposal) => proposal.proId === proMe.id),
    )
    .map((request) => ({
      request,
      distance:
        location && request.latitude !== undefined && request.longitude !== undefined
          ? distanceBetweenKm(location, {
              latitude: request.latitude,
              longitude: request.longitude,
            })
          : undefined,
    }))
    .sort(
      (a, b) => (a.distance ?? Number.POSITIVE_INFINITY) - (b.distance ?? Number.POSITIVE_INFINITY),
    );
  const openDirectRequests = professional
    ? proRequests.filter(
        (request) =>
          categorySet.has(request.category) &&
          !decisions[request.id] &&
          (!category || request.category === category) &&
          normalizeSearch(`${request.title} ${request.address}`).includes(normalizeSearch(query)),
      )
    : [];
  const pageStart = (page - 1) * pageSize;
  const visibleOwnRequests = ownRequests.slice(pageStart, pageStart + pageSize);
  const visibleSentQuotes = sentQuotes.slice(pageStart, pageStart + pageSize);
  const openRequestCount = openDirectRequests.length + openRequests.length;
  const visibleDirectRequests = openDirectRequests.slice(pageStart, pageStart + pageSize);
  const quotePageStart = Math.max(0, pageStart - openDirectRequests.length);
  const quotePageEnd = Math.max(0, pageStart + pageSize - openDirectRequests.length);
  const visibleOpenRequests = openRequests.slice(quotePageStart, quotePageEnd);

  const publish = () => {
    if (!session) {
      navigate({ to: "/entrar", search: { perfil: "cliente" } });
      return;
    }
    setQuoteOpen(true);
  };

  const enableProfessional = () => {
    if (!session) {
      navigate({ to: "/entrar", search: { perfil: "cliente" } });
      return;
    }
    navigate({ to: "/ativar-profissional" });
  };

  const decideDirectRequest = (id: string, decision: RequestDecision) => {
    saveRequestDecision(id, decision);
    setDecisions(readRequestDecisions());
    if (decision === "aceito") {
      addNotification({
        role: "profissional",
        title: "Pedido aceito",
        detail: "O cliente foi avisado. Confira a agenda para combinar os próximos passos.",
        href: "/pro/agenda",
      });
      toast.success("Pedido aceito e adicionado aos seus compromissos");
    } else {
      toast("Vaga removida da sua lista");
    }
  };

  const submitProposal = (event: FormEvent<HTMLFormElement>) => {
    event.preventDefault();
    if (!proposalFor || !Number.isFinite(Number(price)) || Number(price) <= 0 || !days.trim())
      return;
    const updated = sendQuoteProposal(proposalFor.id, {
      proId: proMe.id,
      price: Number(price),
      days: days.trim(),
      note: note.trim() || "Proposta enviada pelo profissional.",
    });
    if (!updated) {
      toast.error("Não foi possível enviar esta proposta. Atualize a página e tente novamente.");
      return;
    }
    setRequests([...readQuoteRequests()]);
    setProposalFor(null);
    setPrice("");
    setDays("");
    setNote("");
    toast.success("Proposta enviada. Você poderá acompanhá-la na área profissional.");
  };

  return (
    <div className="servix-workspace min-w-0 space-y-6">
      <PageTitle
        eyebrow="Pedidos da comunidade"
        title="Vagas"
        subtitle="Clientes publicam o que precisam; profissionais compatíveis avaliam o pedido e enviam uma proposta. Uma conta pode fazer as duas coisas."
        action={
          <button
            onClick={publish}
            className="inline-flex items-center gap-2 rounded-full bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground hover:bg-primary/90"
          >
            <FileText className="h-4 w-4" />
            Publicar uma vaga
          </button>
        }
      />
      <AdPlacement channel="vagas" compact />

      <CatalogSearch
        title="O serviço que você procura. A oportunidade que você espera."
        description="Publique um pedido, acompanhe as propostas ou encontre trabalhos nas suas especialidades."
        value={query}
        onChange={setQuery}
        onSubmit={(event) => event.preventDefault()}
        category={category}
        onCategory={setCategory}
        placeholder="Busque por serviço, descrição ou região"
        label="Buscar vagas"
      />
      <PanelTabs
        value={tab}
        onChange={setTab}
        label="Minhas vagas e propostas"
        items={[
          { value: "minhas", label: "Minhas publicações", count: ownRequests.length },
          {
            value: "proximas",
            label: "Vagas compatíveis",
            ...(professional ? { count: openRequestCount } : {}),
          },
          ...(professional
            ? [
                {
                  value: "enviadas" as const,
                  label: "Propostas enviadas",
                  count: sentQuotes.length,
                },
              ]
            : []),
        ]}
      />

      {tab === "minhas" ? (
        <section className="space-y-3">
          <div className="flex flex-wrap items-end justify-between gap-2">
            <div>
              <h2 className="font-display text-xl font-bold">Minhas publicações</h2>
              <p className="mt-1 text-sm text-muted-foreground">
                As solicitações ficam vinculadas à sua conta e recebem propostas por aqui.
              </p>
            </div>
            <button
              onClick={publish}
              className="rounded-full border px-4 py-2 text-sm font-bold hover:bg-muted"
            >
              Nova vaga
            </button>
          </div>
          {ownRequests.length ? (
            visibleOwnRequests.map((request) => (
              <OwnRequestCard
                key={request.id}
                request={request}
                onOpenProfile={() =>
                  navigate({ to: "/meus-servicos", search: { tab: "Orçamentos" } })
                }
              />
            ))
          ) : (
            <div className="surface grid min-h-52 place-items-center p-8 text-center">
              <div>
                <FileText className="mx-auto h-8 w-8 text-muted-foreground" />
                <h3 className="mt-3 font-display font-bold">Você ainda não publicou uma vaga</h3>
                <p className="mt-1 text-sm text-muted-foreground">
                  Descreva o serviço, a região e o prazo. Profissionais compatíveis poderão enviar
                  propostas.
                </p>
                <button
                  onClick={publish}
                  className="mt-4 rounded-full bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground"
                >
                  Publicar um serviço que procuro
                </button>
              </div>
            </div>
          )}
          <Pagination
            currentPage={page}
            totalItems={ownRequests.length}
            pageSize={pageSize}
            onPageChange={setPage}
            label="vagas"
          />
        </section>
      ) : tab === "proximas" ? (
        <section className="space-y-3">
          <div className="flex flex-wrap items-end justify-between gap-2">
            <div>
              <h2 className="font-display text-xl font-bold">
                Vagas próximas às suas especialidades
              </h2>
              <p className="mt-1 text-sm text-muted-foreground">
                Vagas e pedidos compatíveis aparecem juntos nesta área.
              </p>
            </div>
            {professional && (
              <Link
                to="/pro/servicos"
                className="rounded-full border px-4 py-2 text-sm font-bold hover:bg-muted"
              >
                Atualizar especialidades
              </Link>
            )}
          </div>
          {!professional ? (
            <div className="surface grid min-h-52 place-items-center p-8 text-center">
              <div>
                <UserRoundPlus className="mx-auto h-8 w-8 text-muted-foreground" />
                <h3 className="mt-3 font-display font-bold">Ative seu perfil profissional</h3>
                <p className="mt-1 max-w-md text-sm text-muted-foreground">
                  A mesma conta pode continuar publicando vagas e também responder a pedidos quando
                  você cadastrar suas especialidades.
                </p>
                <button
                  onClick={enableProfessional}
                  className="mt-4 rounded-full bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground"
                >
                  {session ? "Ativar perfil profissional" : "Entrar ou criar conta"}
                </button>
              </div>
            </div>
          ) : openRequests.length || openDirectRequests.length ? (
            <div className="grid gap-3 lg:grid-cols-2">
              {visibleDirectRequests.map((request) => (
                <article key={request.id} className="surface flex flex-col p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
                        {request.id} · {categoryName(request.category)}
                      </p>
                      <h3 className="mt-1 font-display text-lg font-bold">{request.title}</h3>
                    </div>
                    <span className="rounded-md bg-status-warning/20 px-3 py-1.5 text-[11px] font-bold text-status-warning-foreground">
                      {request.kind === "fixo" ? brl(request.price!) : "Orçamento"}
                    </span>
                  </div>
                  <div className="mt-4 grid gap-3 rounded-lg bg-muted p-4 sm:grid-cols-2">
                    <div>
                      <p className="text-[10px] font-bold uppercase text-muted-foreground">
                        Cliente
                      </p>
                      <p className="mt-1 text-sm font-semibold">{request.client}</p>
                      <p className="text-xs text-muted-foreground">{request.clientType}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-bold uppercase text-muted-foreground">
                        Prazo e região
                      </p>
                      <p className="mt-1 text-sm font-semibold">{request.when}</p>
                      <p className="text-xs text-muted-foreground">
                        {request.distanceKm.toString().replace(".", ",")} km · {request.address}
                      </p>
                    </div>
                  </div>
                  <div className="mt-auto flex flex-wrap gap-2 pt-4">
                    <button
                      onClick={() => decideDirectRequest(request.id, "aceito")}
                      className="inline-flex items-center gap-1.5 rounded-md bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground hover:bg-primary/90"
                    >
                      <Check className="h-4 w-4" />{" "}
                      {request.kind === "fixo" ? "Aceitar pedido" : "Tenho interesse"}
                    </button>
                    <button
                      onClick={() => decideDirectRequest(request.id, "dispensado")}
                      className="inline-flex items-center gap-1.5 rounded-md border px-4 py-2.5 text-sm font-semibold hover:bg-muted"
                    >
                      <X className="h-4 w-4" /> Dispensar
                    </button>
                  </div>
                </article>
              ))}
              {visibleOpenRequests.map(({ request, distance }) => (
                <article key={request.id} className="surface flex flex-col p-5">
                  <div className="flex items-start justify-between gap-3">
                    <div>
                      <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
                        {request.id} · {categoryName(request.category)}
                      </p>
                      <h3 className="mt-1 font-display text-lg font-bold">Pedido de serviço</h3>
                    </div>
                    <span className="rounded-full bg-status-warning/20 px-3 py-1.5 text-[11px] font-bold text-status-warning-foreground">
                      Aberto
                    </span>
                  </div>
                  <p className="mt-3 whitespace-pre-wrap text-sm leading-relaxed">
                    {request.description}
                  </p>
                  {request.referencePrice !== undefined && (
                    <div className="mt-3 inline-flex flex-wrap items-center gap-2 rounded-sm bg-accent px-3 py-2 text-xs font-semibold text-accent-foreground">
                      <span>{request.sourceService ?? "Preço fechado selecionado"}</span>
                      <span aria-hidden="true">·</span>
                      <span>Referência: {brl(request.referencePrice)}</span>
                    </div>
                  )}
                  {request.photos.length > 0 && (
                    <div className="mt-3 flex gap-2">
                      {request.photos.map((image, index) => (
                        <img
                          key={image}
                          src={image}
                          alt={`Referência ${index + 1}`}
                          className="h-14 w-14 rounded-xl object-cover"
                          loading="lazy"
                        />
                      ))}
                    </div>
                  )}
                  <div className="mt-4 grid gap-3 rounded-2xl bg-muted p-4 sm:grid-cols-2">
                    <div>
                      <p className="text-[10px] font-bold uppercase text-muted-foreground">
                        Prazo desejado
                      </p>
                      <p className="mt-1 flex items-center gap-1.5 text-sm font-semibold">
                        <CalendarDays className="h-3.5 w-3.5" />
                        {quoteWhenLabel(request)}
                      </p>
                    </div>
                    <div>
                      <p className="text-[10px] font-bold uppercase text-muted-foreground">
                        Região
                      </p>
                      <p className="mt-1 flex items-center gap-1.5 text-sm font-semibold">
                        <MapPin className="h-3.5 w-3.5" />
                        {distance !== undefined
                          ? `Aprox. ${distance.toFixed(1).replace(".", ",")} km de você`
                          : `CEP ${request.cep.slice(0, 2)}*** · endereço aproximado`}
                      </p>
                    </div>
                  </div>
                  {request.photos.length > 0 && (
                    <p className="mt-2 text-xs text-muted-foreground">
                      Imagens de referência anexadas pelo cliente.
                    </p>
                  )}
                  <button
                    onClick={() => {
                      setProposalFor(request);
                      setPrice(request.referencePrice ? String(request.referencePrice) : "");
                      setDays("");
                      setNote("");
                    }}
                    className="mt-4 inline-flex items-center justify-center gap-2 rounded-full bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground"
                  >
                    <Send className="h-4 w-4" />
                    Enviar proposta
                  </button>
                </article>
              ))}
            </div>
          ) : (
            <div className="surface p-9 text-center">
              <BriefcaseBusiness className="mx-auto h-8 w-8 text-muted-foreground" />
              <h3 className="mt-3 font-display font-bold">Nenhuma vaga compatível por enquanto</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Novas vagas aparecem quando clientes procuram as categorias dos seus serviços.
              </p>
            </div>
          )}
          <Pagination
            currentPage={page}
            totalItems={openRequestCount}
            pageSize={pageSize}
            onPageChange={setPage}
            label="vagas compatíveis"
          />
        </section>
      ) : (
        <section className="space-y-3">
          <div>
            <h2 className="font-display text-xl font-bold">Minhas propostas</h2>
            <p className="mt-1 text-sm text-muted-foreground">
              Acompanhe valores enviados e a resposta dos clientes.
            </p>
          </div>
          {sentQuotes.length ? (
            <div className="grid gap-3 lg:grid-cols-2">
              {visibleSentQuotes.map(({ request, proposal }) => {
                const accepted = request.acceptedProposalId === proposal.id;
                return (
                  <article key={request.id} className="surface p-5">
                    <div className="flex items-start justify-between gap-3">
                      <div>
                        <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
                          {request.id} · {categoryName(request.category)}
                        </p>
                        <h3 className="mt-1 line-clamp-2 font-display font-bold">
                          {request.description}
                        </h3>
                      </div>
                      <span
                        className={cn(
                          "rounded-full px-3 py-1.5 text-[11px] font-bold",
                          accepted
                            ? "bg-accent text-accent-foreground"
                            : request.status === "Aceito"
                              ? "bg-muted text-muted-foreground"
                              : "bg-status-warning/20 text-status-warning-foreground",
                        )}
                      >
                        {accepted
                          ? "Proposta aceita"
                          : request.status === "Aceito"
                            ? "Cliente escolheu outra proposta"
                            : "Aguardando cliente"}
                      </span>
                    </div>
                    <div className="mt-4 rounded-2xl bg-muted p-4">
                      <p className="text-[10px] font-bold uppercase tracking-wide text-muted-foreground">
                        Sua proposta
                      </p>
                      <p className="mt-1 font-display text-xl font-extrabold">
                        {brl(proposal.price)} · {proposal.days}
                      </p>
                      <p className="mt-1 text-sm text-muted-foreground">
                        {proposal.note || "Sem mensagem adicional."}
                      </p>
                    </div>
                  </article>
                );
              })}
            </div>
          ) : (
            <div className="surface p-9 text-center">
              <Send className="mx-auto h-8 w-8 text-muted-foreground" />
              <h3 className="mt-3 font-display font-bold">Você ainda não enviou propostas</h3>
              <p className="mt-1 text-sm text-muted-foreground">
                Veja as vagas compatíveis e responda aos pedidos de clientes.
              </p>
              <button
                onClick={() => setTab("proximas")}
                className="mt-4 rounded-full bg-primary px-4 py-2.5 text-sm font-bold text-primary-foreground"
              >
                Ver vagas abertas
              </button>
            </div>
          )}
          <Pagination
            currentPage={page}
            totalItems={sentQuotes.length}
            pageSize={pageSize}
            onPageChange={setPage}
            label="propostas"
          />
        </section>
      )}

      <QuoteDialog open={quoteOpen} onOpenChange={setQuoteOpen} returnTo="/vagas" />
      <Dialog open={!!proposalFor} onOpenChange={(open) => !open && setProposalFor(null)}>
        <DialogContent className="max-w-lg rounded-3xl">
          <DialogHeader>
            <DialogTitle className="font-display text-2xl">Enviar proposta ao cliente</DialogTitle>
            <DialogDescription>
              Informe o valor total, prazo estimado e o que está incluído.
            </DialogDescription>
          </DialogHeader>
          <form onSubmit={submitProposal} className="space-y-3">
            <div className="rounded-xl bg-muted p-3 text-sm">
              <b>{proposalFor && categoryName(proposalFor.category)}</b>
              {proposalFor?.referencePrice !== undefined && (
                <p className="mt-1 text-xs font-semibold text-primary">
                  Valor de referência: {brl(proposalFor.referencePrice)}
                </p>
              )}
              <p className="mt-1 line-clamp-3 text-muted-foreground">{proposalFor?.description}</p>
            </div>
            <label className="block space-y-1.5 text-sm font-semibold">
              Valor total
              <input
                required
                min="1"
                step="1"
                type="number"
                value={price}
                onChange={(event) => setPrice(event.target.value)}
                placeholder={
                  proposalFor?.referencePrice ? String(proposalFor.referencePrice) : "Ex.: 350"
                }
                className={inputClass}
              />
            </label>
            <label className="block space-y-1.5 text-sm font-semibold">
              Prazo estimado
              <input
                required
                maxLength={50}
                value={days}
                onChange={(event) => setDays(event.target.value)}
                placeholder="Ex.: 2 dias"
                className={inputClass}
              />
            </label>
            <label className="block space-y-1.5 text-sm font-semibold">
              Mensagem ao cliente
              <textarea
                rows={3}
                maxLength={500}
                value={note}
                onChange={(event) => setNote(event.target.value)}
                placeholder="Explique as etapas, materiais e condições."
                className={inputClass}
              />
            </label>
            <button className="inline-flex w-full items-center justify-center gap-2 rounded-full bg-primary py-3 font-bold text-primary-foreground">
              <Send className="h-4 w-4" />
              Enviar proposta
            </button>
          </form>
        </DialogContent>
      </Dialog>
    </div>
  );
}

function OwnRequestCard({
  request,
  onOpenProfile,
}: {
  request: QuoteRequest;
  onOpenProfile: () => void;
}) {
  return (
    <article className="surface p-5 sm:p-6">
      <div className="flex flex-wrap items-start justify-between gap-3">
        <div>
          <p className="text-xs font-bold uppercase tracking-wide text-muted-foreground">
            {request.id} · {categoryName(request.category)} · {quoteWhenLabel(request)}
          </p>
          <h3 className="mt-1 font-display text-lg font-bold">{request.description}</h3>
          <p className="mt-1 text-xs text-muted-foreground">
            Local do serviço: {request.address}, {request.number}
            {request.complement ? ` · ${request.complement}` : ""}
          </p>
        </div>
        <span
          className={cn(
            "rounded-full px-3 py-1.5 text-xs font-bold",
            request.status === "Aceito"
              ? "bg-accent text-accent-foreground"
              : "bg-status-warning/20 text-status-warning-foreground",
          )}
        >
          {request.status}
        </span>
      </div>
      <div className="mt-4 flex flex-wrap items-center justify-between gap-2 border-t pt-4">
        <p className="inline-flex items-center gap-1.5 text-sm font-semibold">
          <CheckCircle2 className="h-4 w-4 text-primary" />
          {request.proposals.length}{" "}
          {request.proposals.length === 1 ? "proposta recebida" : "propostas recebidas"}
        </p>
        <button
          onClick={onOpenProfile}
          className="rounded-full bg-primary px-4 py-2 text-sm font-bold text-primary-foreground"
        >
          Ver propostas e contratar
        </button>
      </div>
    </article>
  );
}
