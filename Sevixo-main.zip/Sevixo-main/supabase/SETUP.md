# Conectar o projeto ServiX ao Supabase e Vercel

## O que está preparado

[`schema.sql`](./schema.sql) cria tabelas para contas e perfis, perfis profissionais e vários serviços por profissional, vagas e propostas, contratações, conversas e mensagens, avaliações, anúncios pagos/moderação, notificações, denúncias, papéis administrativos e buckets de mídia. Ele ativa RLS para restringir registros por usuário e separa dados pessoais do perfil público.

**Atenção:** o frontend atual ainda persiste dados em `localStorage`. Executar o SQL e adicionar as variáveis na Vercel prepara o banco, mas não faz login, anúncios ou mensagens passarem a usar o banco. Também será necessário integrar o SDK Supabase e substituir os stores locais por operações autenticadas. Não use a versão atual como operação real com dados de clientes até essa integração ser concluída e testada.

## 1. Criar o projeto Supabase

1. Crie um projeto em [Supabase](https://supabase.com/dashboard/projects), escolha a região mais próxima dos clientes e guarde a senha do banco em local seguro.
2. Abra **SQL Editor → New query**, copie o conteúdo inteiro de [`schema.sql`](./schema.sql), cole e execute uma vez.
3. Em **Project Settings → API Keys** (ou **Connect**), copie a Project URL e a chave **Publishable** (`sb_publishable_...`). A chave é pública e só é segura porque as tabelas usam RLS.
4. Em **Authentication → URL Configuration**, configure a URL de produção da Vercel como Site URL e adicione também os domínios Preview que você usar em Redirect URLs. Configure também o endereço de redirecionamento de e-mail conforme o fluxo de autenticação escolhido.
5. Crie sua conta normal em **Authentication → Users**. Depois de o usuário existir, volte ao SQL Editor e execute o comando comentado no fim de `schema.sql`, substituindo `SEU_EMAIL_ADMIN` pelo e-mail exato. Isso concede o primeiro papel de administrador; não permita que o navegador conceda esse papel.

## 2. Adicionar as variáveis na Vercel

1. Abra o projeto no Dashboard da Vercel e vá a **Settings → Environment Variables**.
2. Adicione estas variáveis com os valores copiados do Supabase:

   | Nome | Valor | Ambientes |
   | --- | --- | --- |
   | `VITE_SUPABASE_URL` | Project URL do Supabase | Production, Preview e Development |
   | `VITE_SUPABASE_PUBLISHABLE_KEY` | chave `sb_publishable_...` | Production, Preview e Development |

3. Salve as variáveis e faça um **novo deployment** (ou um novo commit). Variáveis adicionadas não alteram deployments já publicados.
4. Para desenvolvimento local, coloque os mesmos nomes/valores em `.env.local` na raiz do projeto. Não envie esse arquivo ao GitHub; ele já é ignorado pelo `.gitignore`.

Não adicione `sb_secret_...`, `service_role` nem senha do banco em variáveis com prefixo `VITE_`, no frontend ou no GitHub. Essas credenciais ignoram RLS e só devem existir no servidor quando houver uma necessidade específica. O Supabase recomenda a chave Publishable para código que vai ao navegador.

## 3. Validar a preparação

- No Supabase, confira em **Table Editor** se as tabelas foram criadas e em **Storage** se existem `profile-media`, `service-media`, `ad-media` e `private-documents`.
- Confira em **Authentication → Users** se a conta aparece e em `public.profiles` se o trigger criou seu perfil.
- Confira em `public.user_roles` se seu usuário recebeu `admin`.
- Revise o **Security Advisor** do Supabase após qualquer mudança nas policies.

Essas verificações confirmam a preparação do backend. Para confirmar a integração real, a aplicação ainda precisa inicializar o cliente Supabase, trocar o login demonstrativo pela autenticação Supabase e migrar cada store de `src/lib` do `localStorage` para consultas com sessão, além de testar as policies com contas cliente, profissional e administrador.

## Estrutura que o SQL cria

- **Conta e publicação:** `profiles`, `professional_profiles`, `professional_services`.
- **Marketplace:** `job_requests`, `job_proposals`, `bookings`.
- **Relacionamento:** `conversations`, `messages`, `reviews`, `notifications`.
- **Receita e moderação:** `ad_campaigns`, `moderation_reports`, `user_roles`, `admin_audit_log`.
- **Arquivos:** buckets do Supabase Storage para fotos, criativos e documentos privados.

O script deve ser aplicado uma única vez em um projeto Supabase vazio. Se já houver tabelas de produção, faça backup e transforme-o em migração revisada antes de executar; o script não tenta apagar tabelas existentes.
