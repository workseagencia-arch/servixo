-- ServiX Supabase foundation. Run once in Dashboard > SQL Editor.
-- The current UI still uses localStorage: schema creation alone does not integrate it.

create extension if not exists pgcrypto with schema extensions;

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text not null default '', phone text, birth_date date, tax_id text,
  address_line text, address_number text, address_complement text,
  postal_code text, city text, state_code char(2), avatar_url text,
  account_status text not null default 'active' check (account_status in ('active','suspended','deleted')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

-- Keep private identity/address data separate from public professional profile.
create table public.professional_profiles (
  user_id uuid primary key references public.profiles(id) on delete cascade,
  display_name text not null, headline text not null default '', bio text not null default '',
  years_experience integer not null default 0 check (years_experience >= 0),
  service_radius_km numeric(7,2) not null default 0 check (service_radius_km >= 0),
  city text, state_code char(2),
  latitude numeric(9,6) check (latitude between -90 and 90),
  longitude numeric(9,6) check (longitude between -180 and 180),
  photo_url text, availability_text text,
  verification_status text not null default 'pending' check (verification_status in ('pending','in_review','verified','rejected')),
  publication_status text not null default 'draft' check (publication_status in ('draft','published','paused','suspended')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.professional_services (
  id uuid primary key default gen_random_uuid(),
  professional_id uuid not null references public.professional_profiles(user_id) on delete cascade,
  title text not null, category text not null, description text not null default '',
  pricing_mode text not null default 'quote' check (pricing_mode in ('fixed','quote')),
  price numeric(12,2) check (price is null or price >= 0), duration_text text not null default '',
  cover_image_url text, is_active boolean not null default true,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  check (pricing_mode <> 'fixed' or price is not null)
);

create table public.job_requests (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles(id) on delete cascade,
  title text not null, description text not null, category text not null,
  budget_min numeric(12,2) check (budget_min is null or budget_min >= 0),
  budget_max numeric(12,2) check (budget_max is null or budget_max >= 0),
  desired_date date, schedule_flexible boolean not null default true,
  -- Keep exact address out of open requests; collect it privately after matching.
  city text, state_code char(2),
  status text not null default 'open' check (status in ('open','in_negotiation','accepted','completed','cancelled','closed')),
  accepted_professional_id uuid references public.professional_profiles(user_id) on delete set null,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  check (budget_min is null or budget_max is null or budget_max >= budget_min)
);
create table public.job_proposals (
  id uuid primary key default gen_random_uuid(),
  job_id uuid not null references public.job_requests(id) on delete cascade,
  professional_id uuid not null references public.professional_profiles(user_id) on delete cascade,
  price numeric(12,2) not null check (price >= 0),
  estimated_days integer check (estimated_days is null or estimated_days >= 0),
  note text not null default '',
  status text not null default 'sent' check (status in ('sent','accepted','declined','withdrawn')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  unique (job_id, professional_id)
);

-- Full address and reference images are visible only to the requester and
-- the professional selected for the job, not everyone browsing open jobs.
create table public.job_private_details (
  job_id uuid primary key references public.job_requests(id) on delete cascade,
  client_id uuid not null references public.profiles(id) on delete cascade,
  postal_code text, address_line text, address_number text, address_complement text,
  latitude numeric(9,6) check (latitude between -90 and 90),
  longitude numeric(9,6) check (longitude between -180 and 180),
  reference_photo_urls text[] not null default '{}',
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);

create table public.bookings (
  id uuid primary key default gen_random_uuid(), public_code text unique,
  client_id uuid not null references public.profiles(id) on delete restrict,
  professional_id uuid not null references public.professional_profiles(user_id) on delete restrict,
  service_id uuid references public.professional_services(id) on delete set null,
  job_id uuid references public.job_requests(id) on delete set null,
  service_title text not null, service_kind text not null default 'quote' check (service_kind in ('fixed','quote')),
  status text not null default 'requested' check (status in ('requested','confirmed','on_the_way','in_progress','completed','cancelled','disputed')),
  agreed_price numeric(12,2) check (agreed_price is null or agreed_price >= 0), scheduled_at timestamptz,
  service_address text, client_confirmed boolean not null default false, professional_confirmed boolean not null default false,
  platform_fee numeric(12,2) not null default 0 check (platform_fee >= 0),
  professional_fee numeric(12,2) not null default 0 check (professional_fee >= 0),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  check (service_id is not null or job_id is not null)
);
create table public.conversations (
  id uuid primary key default gen_random_uuid(),
  client_id uuid not null references public.profiles(id) on delete cascade,
  professional_id uuid not null references public.professional_profiles(user_id) on delete cascade,
  booking_id uuid references public.bookings(id) on delete set null,
  job_id uuid references public.job_requests(id) on delete set null,
  last_message_at timestamptz not null default now(), created_at timestamptz not null default now(),
  check (booking_id is not null or job_id is not null)
);
create table public.messages (
  id uuid primary key default gen_random_uuid(),
  conversation_id uuid not null references public.conversations(id) on delete cascade,
  sender_id uuid not null references public.profiles(id) on delete cascade,
  body text not null default '', attachment_url text, attachment_name text, attachment_type text,
  read_at timestamptz, created_at timestamptz not null default now(),
  check (length(trim(body)) > 0 or attachment_url is not null)
);

create table public.reviews (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null unique references public.bookings(id) on delete cascade,
  client_id uuid not null references public.profiles(id) on delete cascade,
  professional_id uuid not null references public.professional_profiles(user_id) on delete cascade,
  rating smallint not null check (rating between 1 and 5), body text not null default '',
  moderation_status text not null default 'published' check (moderation_status in ('published','hidden','under_review')),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.ad_campaigns (
  id uuid primary key default gen_random_uuid(),
  owner_id uuid not null references public.profiles(id) on delete cascade,
  advertiser_type text not null check (advertiser_type in ('professional','company')), advertiser_name text not null,
  format text not null check (format in ('featured_professional','company_banner','featured_banner')),
  headline text not null, description text not null default '', image_url text not null, destination_url text not null,
  channels text[] not null default '{}', category text, region text,
  latitude numeric(9,6) check (latitude between -90 and 90), longitude numeric(9,6) check (longitude between -180 and 180),
  radius_km numeric(7,2) not null default 0 check (radius_km >= 0), amount numeric(12,2) not null check (amount >= 0),
  starts_at timestamptz not null, ends_at timestamptz not null,
  status text not null default 'in_review' check (status in ('in_review','active','paused','rejected','ended')),
  payment_status text not null default 'pending' check (payment_status in ('pending','paid','failed','refunded')),
  impressions bigint not null default 0 check (impressions >= 0), clicks bigint not null default 0 check (clicks >= 0),
  created_at timestamptz not null default now(), updated_at timestamptz not null default now(),
  check (ends_at > starts_at)
);
create table public.notifications (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references public.profiles(id) on delete cascade,
  title text not null, detail text not null default '', href text, read_at timestamptz, created_at timestamptz not null default now()
);
create table public.user_roles (
  user_id uuid not null references public.profiles(id) on delete cascade,
  role text not null check (role in ('moderator','admin','ceo')), created_at timestamptz not null default now(),
  primary key (user_id,role)
);
create table public.moderation_reports (
  id uuid primary key default gen_random_uuid(),
  reporter_id uuid references public.profiles(id) on delete set null,
  subject_type text not null check (subject_type in ('professional','service','campaign','job','review','account')),
  subject_id uuid not null, reason text not null, detail text not null default '',
  status text not null default 'open' check (status in ('open','in_review','resolved','archived')),
  moderator_id uuid references public.profiles(id) on delete set null,
  created_at timestamptz not null default now(), updated_at timestamptz not null default now()
);
create table public.admin_audit_log (
  id bigint generated always as identity primary key, actor_id uuid references public.profiles(id) on delete set null,
  action text not null, subject_type text, subject_id uuid, detail jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

create index professional_services_owner_active_idx on public.professional_services(professional_id,is_active);
create index professional_services_category_idx on public.professional_services(category) where is_active;
create index job_requests_open_category_idx on public.job_requests(category,created_at desc) where status='open';
create index job_proposals_job_idx on public.job_proposals(job_id,created_at desc);
create index bookings_client_idx on public.bookings(client_id,created_at desc);
create index bookings_professional_idx on public.bookings(professional_id,created_at desc);
create index messages_conversation_idx on public.messages(conversation_id,created_at);
create index notifications_user_idx on public.notifications(user_id,created_at desc);
create index campaigns_active_idx on public.ad_campaigns(starts_at,ends_at) where status='active' and payment_status='paid';
create index job_private_details_client_idx on public.job_private_details(client_id);

create function public.set_updated_at() returns trigger language plpgsql set search_path = '' as $$
begin new.updated_at := now(); return new; end; $$;
create function public.has_role(required_role text) returns boolean language sql stable security definer set search_path = '' as $$
  select exists(select 1 from public.user_roles where user_id=(select auth.uid()) and role=required_role);
$$;
create function public.is_conversation_member(target_id uuid) returns boolean language sql stable security definer set search_path = '' as $$
  select exists(select 1 from public.conversations c where c.id=target_id and ((select auth.uid())=c.client_id or (select auth.uid())=c.professional_id));
$$;
create function public.create_profile_for_new_user() returns trigger language plpgsql security definer set search_path = '' as $$
begin
  insert into public.profiles(id,display_name)
  values(new.id,coalesce(nullif(new.raw_user_meta_data->>'full_name',''),nullif(new.raw_user_meta_data->>'name',''),'')) on conflict(id) do nothing;
  return new;
end; $$;
create trigger on_auth_user_created_servix after insert on auth.users for each row execute function public.create_profile_for_new_user();
do $$
declare t text;
begin
  foreach t in array array['profiles','professional_profiles','professional_services','job_requests','job_proposals','job_private_details','bookings','reviews','ad_campaigns','moderation_reports'] loop
    execute format('create trigger set_updated_at before update on public.%I for each row execute function public.set_updated_at()',t);
  end loop;
end $$;

create policy profile_read_self_or_staff on public.profiles for select to authenticated using (id=(select auth.uid()) or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy profile_update_self on public.profiles for update to authenticated using (id=(select auth.uid())) with check (id=(select auth.uid()));
create policy professional_public_or_owner on public.professional_profiles for select to anon,authenticated using (publication_status='published' or user_id=(select auth.uid()) or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy professional_manage_self on public.professional_profiles for all to authenticated using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));
create policy service_public_or_owner on public.professional_services for select to anon,authenticated using (
  (is_active and exists(select 1 from public.professional_profiles p where p.user_id=professional_id and p.publication_status='published'))
  or professional_id=(select auth.uid()) or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy service_manage_self on public.professional_services for all to authenticated using (professional_id=(select auth.uid())) with check (professional_id=(select auth.uid()));

create policy job_read_open_or_party on public.job_requests for select to authenticated using (status='open' or client_id=(select auth.uid()) or accepted_professional_id=(select auth.uid()) or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy job_create_self on public.job_requests for insert to authenticated with check (client_id=(select auth.uid()));
create policy job_update_owner on public.job_requests for update to authenticated using (client_id=(select auth.uid()) or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo')) with check (client_id=(select auth.uid()) or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy proposal_read_parties on public.job_proposals for select to authenticated using (
  professional_id=(select auth.uid()) or exists(select 1 from public.job_requests j where j.id=job_id and j.client_id=(select auth.uid())) or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy proposal_create_professional on public.job_proposals for insert to authenticated with check (
  professional_id=(select auth.uid()) and exists(select 1 from public.professional_profiles p where p.user_id=professional_id and p.publication_status='published')
  and exists(select 1 from public.job_requests j where j.id=job_id and j.status='open' and j.client_id<>(select auth.uid())));
create policy proposal_update_parties on public.job_proposals for update to authenticated using (
  professional_id=(select auth.uid()) or exists(select 1 from public.job_requests j where j.id=job_id and j.client_id=(select auth.uid())))
  with check (professional_id=(select auth.uid()) or exists(select 1 from public.job_requests j where j.id=job_id and j.client_id=(select auth.uid())));
create policy job_private_read_owner_or_selected_pro on public.job_private_details for select to authenticated using (
  client_id=(select auth.uid()) or exists(select 1 from public.job_requests j where j.id=job_id and j.accepted_professional_id=(select auth.uid()))
  or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy job_private_manage_owner on public.job_private_details for all to authenticated
  using (client_id=(select auth.uid())) with check (client_id=(select auth.uid()));

create policy booking_read_parties on public.bookings for select to authenticated using (
  client_id=(select auth.uid()) or professional_id=(select auth.uid()) or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy booking_create_client on public.bookings for insert to authenticated with check (client_id=(select auth.uid()));
create policy booking_update_parties on public.bookings for update to authenticated using (
  client_id=(select auth.uid()) or professional_id=(select auth.uid()) or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'))
  with check (client_id=(select auth.uid()) or professional_id=(select auth.uid()) or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy conversation_read_parties on public.conversations for select to authenticated using (
  client_id=(select auth.uid()) or professional_id=(select auth.uid()) or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy conversation_create_parties on public.conversations for insert to authenticated with check (
  (client_id=(select auth.uid()) or professional_id=(select auth.uid())) and exists(select 1 from public.professional_profiles p where p.user_id=professional_id));
create policy message_read_parties on public.messages for select to authenticated using (
  public.is_conversation_member(conversation_id) or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy message_send_as_self on public.messages for insert to authenticated with check (
  sender_id=(select auth.uid()) and public.is_conversation_member(conversation_id));

create policy review_public_or_party on public.reviews for select to anon,authenticated using (
  moderation_status='published' or client_id=(select auth.uid()) or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy review_completed_booking_only on public.reviews for insert to authenticated with check (
  client_id=(select auth.uid()) and exists(select 1 from public.bookings b where b.id=booking_id and b.client_id=(select auth.uid()) and b.professional_id=professional_id and b.status='completed'));
create policy campaign_public_paid_or_owner on public.ad_campaigns for select to anon,authenticated using (
  (status='active' and payment_status='paid' and starts_at<=now() and ends_at>now()) or owner_id=(select auth.uid()) or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy campaign_submit_for_review on public.ad_campaigns for insert to authenticated with check (
  owner_id=(select auth.uid()) and status='in_review' and payment_status='pending' and impressions=0 and clicks=0);
create policy campaign_edit_pending_only on public.ad_campaigns for update to authenticated using (
  owner_id=(select auth.uid()) and status='in_review' and payment_status='pending')
  with check (owner_id=(select auth.uid()) and status='in_review' and payment_status='pending' and impressions=0 and clicks=0);
create policy campaign_moderator_update on public.ad_campaigns for update to authenticated using (
  public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'))
  with check (public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));

create policy notification_read_self on public.notifications for select to authenticated using (user_id=(select auth.uid()) or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy notification_update_self on public.notifications for update to authenticated using (user_id=(select auth.uid())) with check (user_id=(select auth.uid()));
create policy notification_delete_self on public.notifications for delete to authenticated using (user_id=(select auth.uid()));
create policy notification_insert_staff on public.notifications for insert to authenticated with check (public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy roles_read_self_or_admin on public.user_roles for select to authenticated using (user_id=(select auth.uid()) or public.has_role('admin') or public.has_role('ceo'));
create policy report_create_self on public.moderation_reports for insert to authenticated with check (reporter_id=(select auth.uid()));
create policy report_read_parties on public.moderation_reports for select to authenticated using (reporter_id=(select auth.uid()) or public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy report_update_staff on public.moderation_reports for update to authenticated using (public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo')) with check (public.has_role('moderator') or public.has_role('admin') or public.has_role('ceo'));
create policy audit_read_admin on public.admin_audit_log for select to authenticated using (public.has_role('admin') or public.has_role('ceo'));

alter table public.profiles enable row level security;
alter table public.professional_profiles enable row level security;
alter table public.professional_services enable row level security;
alter table public.job_requests enable row level security;
alter table public.job_proposals enable row level security;
alter table public.job_private_details enable row level security;
alter table public.bookings enable row level security;
alter table public.conversations enable row level security;
alter table public.messages enable row level security;
alter table public.reviews enable row level security;
alter table public.ad_campaigns enable row level security;
alter table public.notifications enable row level security;
alter table public.user_roles enable row level security;
alter table public.moderation_reports enable row level security;
alter table public.admin_audit_log enable row level security;

grant select,update on public.profiles to authenticated;
grant select,insert,update,delete on public.professional_profiles,public.professional_services to authenticated;
grant select,insert,update on public.job_requests,public.job_proposals,public.bookings to authenticated;
grant select,insert,update on public.job_private_details to authenticated;
grant select,insert on public.conversations,public.messages,public.reviews to authenticated;
grant select,insert,update on public.ad_campaigns to authenticated;
grant select,update,delete on public.notifications to authenticated;
grant select on public.user_roles,public.admin_audit_log to authenticated;
grant select,insert,update on public.moderation_reports to authenticated;
grant select on public.professional_profiles,public.professional_services,public.reviews,public.ad_campaigns to anon;

insert into storage.buckets(id,name,public) values
  ('profile-media','profile-media',true),('service-media','service-media',true),('ad-media','ad-media',true),('private-documents','private-documents',false)
on conflict(id) do nothing;
create policy public_media_read on storage.objects for select to anon,authenticated using (bucket_id in ('profile-media','service-media','ad-media'));
create policy user_upload_media on storage.objects for insert to authenticated with check (
  bucket_id in ('profile-media','service-media','ad-media') and (storage.foldername(name))[1]=(select auth.uid())::text);
create policy user_update_media on storage.objects for update to authenticated
  using (bucket_id in ('profile-media','service-media','ad-media') and (storage.foldername(name))[1]=(select auth.uid())::text)
  with check (bucket_id in ('profile-media','service-media','ad-media') and (storage.foldername(name))[1]=(select auth.uid())::text);
create policy user_delete_media on storage.objects for delete to authenticated using (
  bucket_id in ('profile-media','service-media','ad-media') and (storage.foldername(name))[1]=(select auth.uid())::text);
create policy user_private_documents on storage.objects for all to authenticated
  using (bucket_id='private-documents' and (storage.foldername(name))[1]=(select auth.uid())::text)
  with check (bucket_id='private-documents' and (storage.foldername(name))[1]=(select auth.uid())::text);

-- After creating your account in Supabase Auth, manually grant the first admin:
-- insert into public.user_roles(user_id,role) select id,'admin' from auth.users where email='SEU_EMAIL_ADMIN';
-- Never expose a secret/service_role key in browser code, GitHub, or VITE_ variables.


